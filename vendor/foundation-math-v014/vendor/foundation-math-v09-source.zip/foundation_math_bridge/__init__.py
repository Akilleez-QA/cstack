"""A bounded local JSON-RPC math bridge, not an MCP server."""

__version__ = "0.9.0-dev"
