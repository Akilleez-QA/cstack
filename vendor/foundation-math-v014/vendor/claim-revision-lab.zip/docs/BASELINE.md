# Source context

The implementation was newly written after reading the local v0.10 README,
`methods/claim-contracts.md`, `methods/failure-modes.md`, and
`foundation_math/orchestrator.py`. Those sources motivate exact revision binding,
separation of logical and evidence status, explicit dependencies and proof-versus-
refutation distinctions. Their code is not vendored or imported here.

The existing runtime owns its existing calculator acceptance decisions. This lab
neither changes nor calls them and cannot mark any runtime goal accepted. A future
integration needs separate review, append-only interfaces, regression tests and an
explicit trust/authorization policy. No assertion of such integration is made here.

The baseline input hashes are recorded in BASELINE-READ-HASHES.json. They identify
what was read, not a runtime dependency or authentication of an upstream release.
