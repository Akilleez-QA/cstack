"""Verify a manifest-only ZIP and run fresh validation from a clean extraction."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
from manifest import entries


def reproduce(path):
    if Path(path).stat().st_size > 4194304:
        raise ValueError("Archive byte budget exceeded")
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)) or len(names) > 129 or sum(info.file_size for info in infos) > 4194304:
            raise ValueError("Archive membership or size budget failure")
        if any(info.flag_bits & 1 or info.compress_type != zipfile.ZIP_STORED for info in infos):
            raise ValueError("Only plain stored ZIP entries are supported")
        manifest = json.loads(archive.read("SOURCE-MANIFEST.json"))
        rows = entries(manifest)
        if set(names) != {"SOURCE-MANIFEST.json", *(r["path"] for r in rows)}:
            raise ValueError("Archive must contain exactly manifest plus listed files")
        for row in rows:
            raw = archive.read(row["path"])
            if len(raw) != row["bytes"] or hashlib.sha256(raw).hexdigest() != row["sha256"]:
                raise ValueError(f"Archive hash mismatch: {row['path']}")
        with tempfile.TemporaryDirectory(prefix="claim-ledger-replay-") as temp:
            root = Path(temp)
            for name in names:
                target = root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
            env = {key: value for key, value in os.environ.items() if key not in ("PYTHONPATH", "PYTHONHOME")}
            env["PYTHONDONTWRITEBYTECODE"] = "1"
            run = subprocess.run([sys.executable, "-B", "tools/validate.py"], cwd=root, env=env, capture_output=True, text=True, timeout=180)
            if run.returncode != 0:
                raise RuntimeError(f"Fresh extraction validation failed\n{run.stdout}\n{run.stderr}")
            return {"archive_sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(), "manifest_only": True, "fresh_validation": json.loads(run.stdout)}


if __name__ == "__main__":
    if len(sys.argv) != 2: raise SystemExit("Usage: python -B tools/reproduce.py ARCHIVE.zip")
    print(json.dumps(reproduce(sys.argv[1]), indent=2, sort_keys=True))
