"""Single offline aggregate. Never use saved validation output as evidence."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from claim_revision import LedgerError, replay
from build_fixtures import fixture_documents, rejection_documents
from manifest import verify
from run_mutations import run as run_mutations


def main():
    manifest = verify(ROOT)
    env = {key: value for key, value in os.environ.items() if key not in ("PYTHONPATH", "PYTHONHOME")}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    suites = []
    for mode in ([], ["-O"]):
        process = subprocess.run([sys.executable, "-B", *mode, "-m", "unittest", "discover", "-s", "tests", "-v"], cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)
        match = re.search(r"Ran (\d+) tests", process.stderr)
        if process.returncode != 0 or match is None or not process.stderr.rstrip().endswith("OK"):
            raise RuntimeError(f"Suite failed: {mode}\n{process.stdout}\n{process.stderr}")
        suites.append({"mode": "optimized" if mode else "normal", "tests": int(match.group(1)), "passed": True})
    fixture_hashes = {}
    for name, doc in fixture_documents().items():
        for suffix, data in (("ledger", doc), ("expected", replay(doc))):
            raw = (json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()
            path = ROOT / "fixtures" / f"{name}.{suffix}.json"
            if raw != path.read_bytes(): raise RuntimeError(f"Fixture reproduction mismatch: {path.name}")
            fixture_hashes[path.name] = hashlib.sha256(raw).hexdigest()
    for name, (doc, rejection) in rejection_documents().items():
        for suffix, data in (("input", doc), ("rejection", rejection)):
            raw = (json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()
            path = ROOT / "fixtures" / f"{name}.{suffix}.json"
            if raw != path.read_bytes(): raise RuntimeError(f"Rejection fixture reproduction mismatch: {path.name}")
            fixture_hashes[path.name] = hashlib.sha256(raw).hexdigest()
    mutations = run_mutations()
    return {"status": "passed", "scope": "Local structured-data dependency accounting only; no theorem proof or runtime acceptance", "manifest_files": len(manifest["files"]), "suites": suites,
            "fixture_reproduction": fixture_hashes, "generated_dag_oracle_cases_per_mode": 100, "exhaustive_four_node_dag_states_per_mode": 1024, "mutations": mutations,
            "external_models": "not_used", "network": "not_used", "lean": "not_run", "runtime_integration": "not_done"}


if __name__ == "__main__": print(json.dumps(main(), indent=2, sort_keys=True))
