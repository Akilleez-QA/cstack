"""Create a deterministic manifest-only ZIP after checking all listed file hashes."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile
from manifest import verify

ROOT = Path(__file__).resolve().parents[1]


def package(output):
    manifest = verify(ROOT)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED) as archive:
        for name in ["SOURCE-MANIFEST.json"] + [row["path"] for row in manifest["files"]]:
            info = zipfile.ZipInfo(name, (2000, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, (ROOT / name).read_bytes())
    raw = Path(output).read_bytes()
    return {"zip": str(output), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "entries": 1 + len(manifest["files"])}


if __name__ == "__main__":
    if len(sys.argv) != 2: raise SystemExit("Usage: python -B tools/package.py OUTPUT.zip")
    print(json.dumps(package(sys.argv[1]), sort_keys=True))
