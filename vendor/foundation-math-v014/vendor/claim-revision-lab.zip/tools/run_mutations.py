"""Execute targeted source mutants in isolated copies, normally and under -O."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MUTANTS = [
    ("skip_unicode_key_validation", '                    key.encode("utf-8")', '                    pass', "test_surrogate_keys_and_values_are_structured_rejections"),
    ("skip_content_hash", 'if digest(value["content"]) != value["content_sha256"]:', 'if False:', "test_hashes_bind_content_and_dependency_body"),
    ("skip_revision_hash", 'if digest(body) != value["revision_sha256"]:', 'if False:', "test_hashes_bind_content_and_dependency_body"),
    ("ignore_exact_pins", 'if target != pin(record):', 'if False:', "test_malformed_and_missing_pins"),
    ("allow_revision_cycles", 'if len(order) != len(current):', 'if False:', "test_revision_cycle_rejected"),
    ("allow_duplicate_ids", 'if record["id"] in current:', 'if False:', "test_duplicate_ids_and_edges"),
    ("ignore_withdrawal", 'for event in life.get((rid, record["revision"]), []):', 'for event in []:', "test_boundary_regression"),
    ("drop_transitive_propagation", 'for r in reasons_by_id[dep["id"]]:', 'for r in []:', "test_boundary_regression"),
    ("silently_rebind_revision", 'if dep != actual:', 'if dep != actual and False:', "test_revision_change_invalidates_exactly_downstream"),
    ("promote_authored_status", '"proof_accepted": False, "reasons": ordered', '"proof_accepted": True, "reasons": ordered', "test_authored_status_never_accepts_or_refutes"),
    ("accept_boolean_revision", 'if type(value) is not int or not 1 <= value <= 1000000:', 'if not isinstance(value, int) or not 1 <= value <= 1000000:', "test_revision_is_strict_integer"),
    ("invent_alternative_dependency", 'for r in reasons_by_id[dep["id"]]:', 'for r in (reasons_by_id[dep["id"]] if len(record["dependencies"]) == 1 else []):', "test_all_required_not_any"),
    ("conflate_withdrawal_and_refutation", 'code = "revision_withdrawn" if event["kind"] == "withdraw" else "refutation_reported_unchecked"', 'code = "refutation_reported_unchecked"', "test_withdrawal_is_not_theorem_refutation"),
    ("ignore_record_budget", 'not 1 <= len(records) <= MAX_RECORDS:', 'not 1 <= len(records) <= 1000:', "test_input_and_graph_budgets"),
]


def run():
    source = (ROOT / "claim_revision/core.py").read_text()
    rows = []
    env = {key: value for key, value in os.environ.items() if key not in ("PYTHONPATH", "PYTHONHOME")}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    for name, before, after, test in MUTANTS:
        if source.count(before) != 1:
            raise RuntimeError(f"Mutation anchor is not unique: {name}")
        with tempfile.TemporaryDirectory(prefix="claim-ledger-mutation-") as temp:
            temp = Path(temp)
            for directory in ("claim_revision", "tests", "fixtures"):
                shutil.copytree(ROOT / directory, temp / directory, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            (temp / "claim_revision/core.py").write_text(source.replace(before, after))
            for mode in ([], ["-O"]):
                command = [sys.executable, "-B", *mode, "-m", "unittest", f"tests.test_ledger.LedgerTests.{test}"]
                completed = subprocess.run(command, cwd=temp, env=env, capture_output=True, text=True, timeout=30)
                # A crash/import error is a harness failure, never a killed mutant.
                killed = completed.returncode == 1 and "FAILED (failures=" in completed.stderr and "ERROR:" not in completed.stderr
                rows.append({"mutant": name, "mode": "optimized" if mode else "normal", "test": test, "killed_by_assertion": killed})
                if not killed:
                    raise RuntimeError(f"Mutant not killed by the selected assertion: {name} {mode}\n{completed.stdout}\n{completed.stderr}")
    return {"source_mutants": len(MUTANTS), "executed_mutant_runs": len(rows), "all_killed_by_assertion": True, "runs": rows}


if __name__ == "__main__": print(json.dumps(run(), indent=2, sort_keys=True))
