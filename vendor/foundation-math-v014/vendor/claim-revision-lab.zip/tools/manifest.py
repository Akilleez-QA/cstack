"""Small exact allowlist manifest helpers. No recursive discovery at package time."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def safe_name(name):
    if type(name) is not str or not name or "\\" in name:
        raise ValueError("Invalid manifest path")
    p = PurePosixPath(name)
    if p.is_absolute() or any(part in ("", ".", "..") for part in name.split("/")):
        raise ValueError("Unsafe manifest path")
    return name


def entries(manifest):
    if type(manifest) is not dict or set(manifest) != {"schema", "files"} or manifest["schema"] != "foundation-math-claim-revision/source-manifest/1":
        raise ValueError("Invalid source manifest")
    if type(manifest["files"]) is not list or not 1 <= len(manifest["files"]) <= 128:
        raise ValueError("Invalid manifest file count")
    seen = set()
    for row in manifest["files"]:
        if type(row) is not dict or set(row) != {"path", "sha256", "bytes"}:
            raise ValueError("Invalid manifest entry")
        name = safe_name(row["path"])
        if name == "SOURCE-MANIFEST.json" or name in seen:
            raise ValueError("Duplicate or recursive manifest entry")
        seen.add(name)
        if type(row["bytes"]) is not int or not 0 <= row["bytes"] <= 1048576:
            raise ValueError("Invalid manifest size")
        if type(row["sha256"]) is not str or len(row["sha256"]) != 64 or any(c not in "0123456789abcdef" for c in row["sha256"]):
            raise ValueError("Invalid manifest digest")
    if [r["path"] for r in manifest["files"]] != sorted(seen):
        raise ValueError("Manifest paths must be sorted")
    return manifest["files"]


def verify(root):
    root = Path(root).resolve()
    data = json.loads((root / "SOURCE-MANIFEST.json").read_bytes())
    for row in entries(data):
        path = root / row["path"]
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
            raise ValueError(f"Not an ordinary in-tree file: {row['path']}")
        raw = path.read_bytes()
        if len(raw) != row["bytes"] or hashlib.sha256(raw).hexdigest() != row["sha256"]:
            raise ValueError(f"Manifest mismatch: {row['path']}")
    return data
