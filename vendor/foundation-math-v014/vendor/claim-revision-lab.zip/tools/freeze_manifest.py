"""Developer action: refresh hashes for the explicit RELEASE-FILES.json allowlist."""
import hashlib
import json
from pathlib import Path
from manifest import safe_name

ROOT = Path(__file__).resolve().parents[1]
if __name__ == "__main__":
    names = json.loads((ROOT / "RELEASE-FILES.json").read_text())
    if type(names) is not list or len(names) != len(set(names)):
        raise ValueError("Release allowlist must contain unique names")
    rows = []
    for name in sorted(names):
        path = ROOT / safe_name(name)
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(ROOT):
            raise ValueError(f"Invalid source file: {name}")
        raw = path.read_bytes()
        rows.append({"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    (ROOT / "SOURCE-MANIFEST.json").write_text(json.dumps({"schema": "foundation-math-claim-revision/source-manifest/1", "files": rows}, indent=2, sort_keys=True) + "\n")
