"""Deterministically regenerate original synthetic fixtures and replay goldens."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from claim_revision import pin, replay
from tests.helpers import boundary_case, document, event, node, reseal


def fixture_documents():
    source = node("synthetic_lemma")
    obligation = node("synthetic_review", "obligation", [source])
    conclusion = node("synthetic_conclusion", deps=[obligation])
    source2 = node("synthetic_lemma", revision=2, text="A revised synthetic statement with a retained extra hypothesis.")
    review2 = node("synthetic_review", "obligation", [source2], revision=2)
    conclusion2 = node("synthetic_conclusion", deps=[review2], revision=2)
    revise = event("revise", source, "revise_lemma", replacement=source2)
    counter = node("synthetic_counterexample", "evidence")
    counter["content"]["evidence_type"] = "counterexample_report"
    counter = reseal(counter)
    diamond_root = node("diamond_root")
    left = node("diamond_left", deps=[diamond_root])
    right = node("diamond_right", deps=[diamond_root])
    diamond_tip = node("diamond_tip", "obligation", [right, left])
    unrelated = node("replacement_only_premise")
    replacement_with_new_dependency = node("synthetic_lemma", deps=[unrelated], revision=2)
    return {
        "boundary-withdrawal": boundary_case(),
        "diamond-shortest-path": document([diamond_root, left, right, diamond_tip], [event("withdraw", diamond_root)]),
        "historical-objection": document([source, obligation, counter], [event("record_refutation_report", source, "report_old_objection", evidence=pin(counter)), event("withdraw", source, "withdraw_old_revision"), revise]),
        "stale-edge-isolation": document([source, obligation, unrelated], [event("withdraw", unrelated, "withdraw_new_premise"), event("revise", source, "revise_with_new_premise", replacement=replacement_with_new_dependency)]),
        "revision-change": document([source, obligation, conclusion], [revise]),
        "explicit-repair": document([source, obligation, conclusion], [revise, event("revise", obligation, "revise_review", replacement=review2), event("revise", conclusion, "revise_conclusion", replacement=conclusion2)]),
        "unchecked-refutation": document([source, obligation, conclusion, counter], [event("record_refutation_report", source, "record_objection", evidence=pin(counter))]),
        "authored-status-is-not-proof": document([node("authored_status_only", status="claimed_established")]),
    }


def rejection_documents():
    first = node("cycle_first")
    second = node("cycle_second", deps=[first])
    first2 = node("cycle_first", deps=[second], revision=2)
    return {"stale-stable-id-cycle": (document([first, second], [event("revise", first, replacement=first2)]), {"code": "cycle", "path": "records"})}


def main():
    for name, doc in sorted(fixture_documents().items()):
        for suffix, value in (("ledger", doc), ("expected", replay(doc))):
            (ROOT / "fixtures" / f"{name}.{suffix}.json").write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    for name, (doc, rejection) in sorted(rejection_documents().items()):
        for suffix, value in (("input", doc), ("rejection", rejection)):
            (ROOT / "fixtures" / f"{name}.{suffix}.json").write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


if __name__ == "__main__": main()
