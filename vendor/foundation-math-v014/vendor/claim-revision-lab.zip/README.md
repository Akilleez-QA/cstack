# Foundation Math: claim revision ledger lab

A standalone, bounded capability for an agentic mathematician: when a proof argument
is withdrawn or a cited revision changes, identify exactly which explicit downstream
obligations must be revisited. This is dependency applicability accounting, not
another calculator and not a theorem verifier.

The v0.10 source tree, orchestration, verification registry and runtime acceptance
are not modified or imported. This lab is not integrated, published, or a repository.
All examples are original synthetic data. Python 3.11+ standard library only.
No model calls, network, package installation, executable proof text, or Lean run.

## Run the entire validation

```sh
PYTHONDONTWRITEBYTECODE=1 python -B tools/validate.py
```

This one aggregate runs the full suite normally and under `-O`, replays all fixture
goldens, runs a separate reachability oracle over 100 generated DAGs and all 1,024
four-node DAG/withdrawal states, executes
source mutations in both modes, and checks deterministic process replay. It emits
fresh machine-readable results; it does not treat a saved report as a test run.

```sh
python -B -m claim_revision < fixtures/boundary-withdrawal.ledger.json
python -B tools/package.py /tmp/claim-revision-lab.zip
python -B tools/reproduce.py /tmp/claim-revision-lab.zip
```

The packager includes only `SOURCE-MANIFEST.json` and its explicit hashed file list.
The reproducer verifies the ZIP names and hashes, safely extracts into a temporary
directory, and executes the same aggregate there without sibling trees. The source
manifest is integrity metadata, not authorship, provenance authentication or proof.

## What it does

- Binds every dependency to an exact stable ID, revision and complete revision hash.
- Models claims, obligations and evidence as distinct records with all-required edges.
- Replays ordered withdrawals, revisions and explicit unchecked refutation reports.
- Computes transitive blockers with precise causes, exact pins and canonical witness paths.
- Preserves unaffected branches and historical revisions. New revisions never silently repin callers.
- Rejects duplicate IDs/keys, missing or mismatched pins, cycles, invalid types and resource overages.
- Keeps authored status, byte-integrity checking, current applicability, and mathematical truth separate.

The boundary fixture withdraws a faulty synthetic boundary-kernel argument. Its lemma
and draft exclusion branch become blocked, while independently supported span
constraints remain unchanged. “Unchanged” does not mean the engine proved them.

## Deliberate limits

A clean graph means only `no_recorded_dependency_blockers`. It never means proof
accepted, hypotheses discharged, an artifact checked, or a theorem true. Evidence
artifact hashes are identifiers; their bytes are not fetched. Claimed formal proofs
remain unchecked reports. A withdrawal is not a counterexample. An explicit
refutation report is an unresolved, unverified objection, not a derived false theorem.

Only all-required dependencies exist. Alternative proofs must be represented as
separate records outside this lab's acceptance logic; no implicit OR semantics,
automatic fallback, conditional edge, induction cycle or recursive proof device is supported.

Read [the contract](docs/CONTRACT.md), [schema](schemas/ledger.schema.json),
[test design](docs/VALIDATION.md) and [source context](docs/BASELINE.md).
