"""Original synthetic inputs. No application-specific coefficients or proof text."""
from copy import deepcopy
from claim_revision import VERSION, digest, pin, seal_record


def node(rid, kind="claim", deps=(), revision=1, status="draft", text=None):
    if kind == "claim":
        content = {"statement": text or f"Synthetic statement {rid}.", "scope": "conditional",
                   "assumptions": ["Synthetic declared hypotheses only."], "non_claims": ["No application theorem."], "authored_status": status}
    elif kind == "obligation":
        content = {"requirement": text or f"Review synthetic obligation {rid}.", "authored_status": status}
    else:
        content = {"description": text or f"Synthetic evidence {rid}.", "evidence_type": "informal_argument",
                   "artifact_sha256": digest({"synthetic_artifact": rid}), "authored_status": status}
    return seal_record({"id": rid, "revision": revision, "kind": kind, "content": content,
                        "dependencies": [pin(dep) for dep in deps]})


def document(records, events=()):
    return {"schema": VERSION, "records": list(records), "events": list(events)}


def event(kind, target, eid="event_one", **extra):
    return {"id": eid, "kind": kind, "target": pin(target), "reason": "Synthetic recorded correction.", **extra}


def reseal(record):
    return seal_record({key: deepcopy(value) for key, value in record.items() if key not in ("revision_sha256", "content_sha256")})


def boundary_case():
    argument = node("boundary_kernel_argument", "evidence", status="claimed_established")
    kernel = node("boundary_kernel_lemma", deps=[argument], status="claimed_established")
    obligation = node("draft_exclusion_obligation", "obligation", deps=[kernel])
    exclusion = node("draft_exclusion", deps=[obligation])
    aggregate = node("combined_exclusion_obligation", "obligation", deps=[exclusion])
    independent_proof = node("span_argument", "evidence", status="claimed_established")
    span_obligation = node("span_constraint_obligation", "obligation", deps=[independent_proof], status="claimed_established")
    span = node("span_constraints", deps=[span_obligation], status="claimed_established")
    return document([argument, kernel, obligation, exclusion, aggregate, independent_proof, span_obligation, span],
                    [event("withdraw", argument, "withdraw_boundary_argument")])
