from copy import deepcopy
import json
import os
import random
from pathlib import Path
import subprocess
import sys
import unittest

from claim_revision import LedgerError, canonical_bytes, digest, loads, pin, replay, seal_record
from claim_revision import core
from tests.helpers import boundary_case, document, event, node, reseal


class LedgerTests(unittest.TestCase):
    def reject(self, doc, code):
        with self.assertRaises(LedgerError) as raised:
            replay(doc)
        self.assertEqual(code, raised.exception.code)

    def by_id(self, result):
        return {r["pin"]["id"]: r for r in result["records"]}

    def test_boundary_regression(self):
        result = replay(boundary_case())
        self.assertEqual(["combined_exclusion_obligation", "draft_exclusion_obligation"], result["affected_obligations"])
        self.assertEqual(["boundary_kernel_lemma", "draft_exclusion"], result["affected_claims"])
        reports = self.by_id(result)
        self.assertEqual("blocked", reports["boundary_kernel_argument"]["applicability"])
        self.assertEqual("no_recorded_dependency_blockers", reports["span_constraints"]["applicability"])
        reasons = reports["combined_exclusion_obligation"]["reasons"]
        self.assertEqual(1, len(reasons))
        self.assertEqual("revision_withdrawn", reasons[0]["code"])
        self.assertEqual(["combined_exclusion_obligation", "draft_exclusion", "draft_exclusion_obligation", "boundary_kernel_lemma", "boundary_kernel_argument"], [p["id"] for p in reasons[0]["path"]])
        self.assertEqual("withdraw_boundary_argument", reasons[0]["event_id"])

    def test_withdrawal_is_not_theorem_refutation(self):
        result = replay(boundary_case())
        self.assertEqual("not_assessed", result["truth_assessment"])
        for r in result["records"]:
            self.assertEqual("not_assessed", r["truth_assessment"])
            self.assertFalse(r["proof_accepted"])
            self.assertTrue(all(reason["code"] != "refutation_reported_unchecked" for reason in r["reasons"]))

    def test_authored_status_never_accepts_or_refutes(self):
        for status in ("open", "draft", "claimed_established", "claimed_refuted"):
            record = node("status_example", status=status)
            result = replay(document([record]))
            self.assertFalse(result["proof_accepted"])
            self.assertFalse(result["records"][0]["proof_accepted"])
            self.assertEqual("not_assessed", result["records"][0]["truth_assessment"])
            self.assertEqual([], result["records"][0]["reasons"])
            self.assertFalse(result["integrity"]["artifact_bytes_checked"])
            self.assertFalse(result["integrity"]["authorship_verified"])

    def test_explicit_refutation_is_unchecked_report(self):
        claim = node("claim")
        counter = node("counterexample", "evidence")
        counter["content"]["evidence_type"] = "counterexample_report"
        counter = reseal(counter)
        obligation = node("obligation", "obligation", [claim])
        result = replay(document([claim, counter, obligation], [event("record_refutation_report", claim, evidence=pin(counter))]))
        reports = self.by_id(result)
        self.assertEqual("refutation_reported_unchecked", reports["claim"]["reasons"][0]["code"])
        self.assertEqual(pin(counter), reports["claim"]["reasons"][0]["reported_evidence"])
        self.assertEqual(["obligation"], result["affected_obligations"])
        self.assertEqual("not_assessed", reports["claim"]["truth_assessment"])

    def test_report_persists_when_counterexample_is_withdrawn(self):
        claim, counter = node("claim"), node("counter", "evidence")
        counter["content"]["evidence_type"] = "counterexample_report"
        counter = reseal(counter)
        result = replay(document([claim, counter], [event("record_refutation_report", claim, evidence=pin(counter)), event("withdraw", counter, "withdraw_counter")]))
        self.assertEqual("refutation_reported_unchecked", self.by_id(result)["claim"]["reasons"][0]["code"])
        self.assertEqual("blocked", self.by_id(result)["counter"]["applicability"])

    def test_refutation_target_and_evidence_are_typed(self):
        claim, evidence = node("claim"), node("evidence", "evidence")
        self.reject(document([claim, evidence], [event("record_refutation_report", claim, evidence=pin(evidence))]), "invalid_refutation_evidence")
        self.reject(document([claim, evidence], [event("record_refutation_report", evidence, evidence=pin(evidence))]), "invalid_refutation_target")

    def test_revision_change_invalidates_exactly_downstream(self):
        source = node("source", "evidence")
        obligation = node("obligation", "obligation", [source])
        claim = node("claim", deps=[obligation])
        other = node("other")
        replacement = node("source", "evidence", revision=2, text="Corrected argument.")
        doc = document([source, obligation, claim, other], [event("revise", source, replacement=replacement)])
        result = replay(doc)
        reports = self.by_id(result)
        self.assertEqual(["obligation"], result["affected_obligations"])
        self.assertEqual(["claim"], result["affected_claims"])
        reason = reports["claim"]["reasons"][0]
        self.assertEqual("dependency_revision_not_current", reason["code"])
        self.assertEqual(pin(source), reason["expected"])
        self.assertEqual(pin(replacement), reason["current"])
        self.assertEqual(["claim", "obligation", "source"], [p["id"] for p in reason["path"]])
        self.assertEqual("no_recorded_dependency_blockers", reports["other"]["applicability"])
        self.assertEqual("no_recorded_dependency_blockers", reports["source"]["applicability"])

    def test_identical_content_new_revision_still_invalidates(self):
        source, obligation = node("source"), None
        obligation = node("obligation", "obligation", [source])
        new = deepcopy(source)
        new["revision"] = 2
        new = reseal(new)
        self.assertEqual(source["content_sha256"], new["content_sha256"])
        self.assertNotEqual(source["revision_sha256"], new["revision_sha256"])
        result = replay(document([source, obligation], [event("revise", source, replacement=new)]))
        self.assertEqual(["obligation"], result["affected_obligations"])

    def test_explicit_downstream_revisions_repair_applicability_not_truth(self):
        a = node("source")
        b = node("obligation", "obligation", [a])
        c = node("claim", deps=[b])
        a2 = node("source", revision=2)
        b2 = node("obligation", "obligation", [a2], revision=2)
        c2 = node("claim", deps=[b2], revision=2)
        doc = document([a, b, c], [event("withdraw", a, "withdraw"), event("revise", a, "revise_a", replacement=a2), event("revise", b, "revise_b", replacement=b2), event("revise", c, "revise_c", replacement=c2)])
        result = replay(doc)
        self.assertEqual([], result["affected_obligations"])
        self.assertEqual([], result["affected_claims"])
        self.assertFalse(result["proof_accepted"])
        self.assertEqual(6, len(result["history"]))
        self.assertEqual(1, sum(bool(h["lifecycle_events"]) for h in result["history"]))

    def test_all_required_not_any(self):
        a, b = node("a"), node("b")
        c = node("c", "obligation", [a, b])
        result = replay(document([a, b, c], [event("withdraw", a)]))
        self.assertEqual(["c"], result["affected_obligations"])

    def test_two_causes_and_diamond_path_deduplication(self):
        root = node("root")
        left, right = node("left", deps=[root]), node("right", deps=[root])
        tip = node("tip", "obligation", [right, left])
        result = replay(document([root, left, right, tip], [event("withdraw", root)]))
        reasons = self.by_id(result)["tip"]["reasons"]
        self.assertEqual(1, len(reasons))
        self.assertEqual(["tip", "left", "root"], [p["id"] for p in reasons[0]["path"]])
        result2 = replay(document([root, left, right, tip], [event("withdraw", root), event("withdraw", right, "withdraw_right")]))
        self.assertEqual(2, len(self.by_id(result2)["tip"]["reasons"]))

    def test_shortest_path_is_used(self):
        a = node("a")
        b = node("b", deps=[a])
        c = node("c", deps=[b, a])
        result = replay(document([a, b, c], [event("withdraw", a)]))
        self.assertEqual(["c", "a"], [p["id"] for p in self.by_id(result)["c"]["reasons"][0]["path"]])

    def test_malformed_and_missing_pins(self):
        a = node("a")
        b = node("b", deps=[a])
        bad = deepcopy(b)
        del bad["dependencies"][0]["revision"]
        self.reject(document([a, bad]), "fields")
        bad = deepcopy(b)
        bad["dependencies"][0]["revision"] = 2
        bad = reseal(bad)
        self.reject(document([a, bad]), "pin_mismatch")
        bad = deepcopy(b)
        bad["dependencies"][0]["revision_sha256"] = "0" * 64
        self.reject(document([a, reseal(bad)]), "pin_mismatch")
        self.reject(document([b]), "missing_reference")

    def test_hashes_bind_content_and_dependency_body(self):
        a, other = node("a"), node("other")
        b = node("b", deps=[a])
        wrong = deepcopy(a)
        wrong["content"]["statement"] = "Tampered"
        self.reject(document([wrong]), "content_hash_mismatch")
        wrong["content_sha256"] = digest(wrong["content"])
        self.reject(document([wrong]), "revision_hash_mismatch")
        wrong = deepcopy(b)
        wrong["dependencies"] = [pin(other)]
        self.reject(document([a, other, wrong]), "revision_hash_mismatch")

    def test_duplicate_ids_and_edges(self):
        a = node("a")
        self.reject(document([a, a]), "duplicate_id")
        self.reject(document([a], [event("withdraw", a), event("withdraw", a)]), "duplicate_id")
        b = node("b", deps=[a])
        b["dependencies"].append(pin(a))
        self.reject(document([a, b]), "duplicate_dependency")

    def test_self_dependency(self):
        a = node("a")
        a["dependencies"] = [pin(a)]
        self.reject(document([a]), "cycle")

    def test_revision_cycle_rejected(self):
        a = node("a")
        b = node("b", deps=[a])
        a2 = node("a", deps=[b], revision=2)
        self.reject(document([a, b], [event("revise", a, replacement=a2)]), "cycle")

    def test_exact_current_event_target_and_revision(self):
        a = node("a")
        a2 = node("a", revision=2)
        e = event("revise", a, replacement=a2)
        self.reject(document([a], [e, event("withdraw", a, "old")]), "pin_mismatch")
        for revision in (1, 3):
            self.reject(document([a], [event("revise", a, replacement=node("a", revision=revision))]), "invalid_revision")
        self.reject(document([a], [event("revise", a, replacement=node("b", revision=2))]), "invalid_revision")
        self.reject(document([a], [event("revise", a, replacement=node("a", "evidence", revision=2))]), "invalid_revision")
        self.reject(document([a], [event("withdraw", a), event("withdraw", a, "second")]), "duplicate_transition")

    def test_replacement_must_pin_current_dependencies(self):
        a, b = node("a"), node("b")
        a2, b2 = node("a", revision=2), node("b", deps=[a], revision=2)
        self.reject(document([a, b], [event("revise", a, "ea", replacement=a2), event("revise", b, "eb", replacement=b2)]), "pin_mismatch")

    def test_revision_is_strict_integer(self):
        a = node("a")
        for bad in (True, False, "1", 1.0, None, 0, -1, 1000001, []):
            doc = document([deepcopy(a)])
            doc["records"][0]["revision"] = bad
            with self.assertRaises(LedgerError):
                replay(doc)
        with self.assertRaises(LedgerError):
            seal_record({"id": "a", "revision": True, "kind": "obligation", "content": {"requirement": "test", "authored_status": "open"}, "dependencies": []})

    def test_surrogate_keys_and_values_are_structured_rejections(self):
        for codepoint in (0xD800, 0xDFFF):
            raw_surrogate = chr(codepoint)
            values = [{raw_surrogate: 1}, {"nested": {raw_surrogate: 1}},
                      [{raw_surrogate: "value"}], {"value": raw_surrogate},
                      {"nested": [{"value": raw_surrogate}]}]
            for value in values:
                encoded = json.dumps(value, ensure_ascii=True)
                for operation in (lambda: loads(encoded), lambda: loads(encoded.encode("ascii")),
                                  lambda: replay(value), lambda: digest(value), lambda: seal_record(value)):
                    with self.assertRaises(LedgerError) as raised:
                        operation()
                    self.assertEqual("malformed_type", raised.exception.code)
                for mode in ([], ["-O"]):
                    run = subprocess.run([sys.executable, "-B", *mode, "-m", "claim_revision"], input=encoded.encode("ascii"), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
                    self.assertEqual(2, run.returncode, run.stderr.decode())
                    self.assertEqual(b"", run.stderr)
                    result = json.loads(run.stdout)
                    self.assertEqual("rejected", result["status"])
                    self.assertEqual("malformed_type", result["code"])
                    self.assertEqual("$", result["path"])
        # A correctly paired JSON escape becomes one valid Unicode scalar, not
        # an unpaired surrogate. Unicode normalization is deliberately absent.
        self.assertEqual({chr(0x1F600): "ok"}, loads(r'{"\ud83d\ude00":"ok"}'))

    def test_duplicate_refutation_reports_rejected_explicitly(self):
        claim, counter = node("claim"), node("counter", "evidence")
        counter["content"]["evidence_type"] = "counterexample_report"
        counter = reseal(counter)
        self.reject(document([claim, counter], [event("record_refutation_report", claim, "first_report", evidence=pin(counter)), event("record_refutation_report", claim, "second_report", evidence=pin(counter))]), "duplicate_transition")

    def test_strict_types_unknown_fields_no_executable_payload(self):
        a = node("a")
        for field, value in (("kind", []), ("id", 12), ("dependencies", {}), ("content", "bad")):
            doc = document([deepcopy(a)])
            doc["records"][0][field] = value
            with self.assertRaises(LedgerError):
                replay(doc)
        doc = document([a])
        doc["command"] = "anything"
        self.reject(doc, "fields")
        self.reject(document([a], [{"kind": [], "id": "x"}]), "malformed_type")
        self.reject(document([a], [{"kind": "accept_proof", "id": "x"}]), "malformed_type")
        class SubDict(dict): pass
        with self.assertRaises(LedgerError): replay(SubDict(document([a])))
        for raw in ('{"x":1,"x":2}', '{"x":NaN}', '{"x":Infinity}', '{"x":1.0}', b'\xff', '{', '{"x":"\\ud800"}'):
            with self.assertRaises(LedgerError): loads(raw)
        loop = []
        loop.append(loop)
        with self.assertRaises(LedgerError): replay(loop)

    def test_input_and_graph_budgets(self):
        self.reject(document([node(f"node{i}") for i in range(65)]), "budget_exceeded")
        a = node("a")
        self.reject(document([a], [event("withdraw", a, f"e{i}") for i in range(65)]), "budget_exceeded")
        with self.assertRaises(LedgerError): loads(" " * (core.MAX_INPUT_BYTES + 1))
        with self.assertRaises(LedgerError): loads("[" * 1100 + "]" * 1100)
        records = []
        for i in range(24):
            records.append(node(f"n{i}", deps=records))
        self.reject(document(records), "budget_exceeded")

    def test_budget_edges_exact_limit(self):
        records = [node(f"root{i}") for i in range(16)]
        for i in range(16):
            records.append(node(f"leaf{i}", deps=records[:16]))
        result = replay(document(records))
        self.assertEqual(32, len(result["records"]))

    def test_output_budgets_are_fail_closed(self):
        doc = boundary_case()
        for name, tiny in (("MAX_REASONS", 1), ("MAX_PATH_PINS", 1), ("MAX_OUTPUT_BYTES", 1)):
            original = getattr(core, name)
            try:
                setattr(core, name, tiny)
                self.reject(doc, "budget_exceeded")
            finally:
                setattr(core, name, original)

    def test_no_aliases_input_mutation_or_partial_result(self):
        doc = boundary_case()
        before = deepcopy(doc)
        result = replay(doc)
        self.assertEqual(before, doc)
        result["records"][0]["pin"]["id"] = "changed"
        self.assertEqual(before, doc)
        invalid = deepcopy(doc)
        invalid["events"].append(event("withdraw", node("absent"), "bad_event"))
        self.reject(invalid, "missing_reference")
        self.assertEqual(before, doc)
        self.assertEqual(replay(doc), replay(before))

    def test_record_order_and_process_hash_seed_determinism(self):
        doc = boundary_case()
        reversed_doc = {**doc, "records": list(reversed(doc["records"]))}
        self.assertEqual(replay(doc), replay(reversed_doc))
        outputs = []
        for mode, seed in (([], "1"), (["-O"], "987")):
            completed = subprocess.run([sys.executable, "-B", *mode, "-m", "claim_revision"], input=canonical_bytes(doc), stdout=subprocess.PIPE, stderr=subprocess.PIPE, env={**os.environ, "PYTHONHASHSEED": seed}, timeout=20)
            self.assertEqual(0, completed.returncode, completed.stderr.decode())
            outputs.append(completed.stdout)
        self.assertEqual(outputs[0], outputs[1])

    def test_cli_fail_closed(self):
        result = subprocess.run([sys.executable, "-B", "-m", "claim_revision"], input=b'{"schema":false}', stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        self.assertEqual(2, result.returncode)
        self.assertEqual("rejected", json.loads(result.stdout)["status"])

    def test_generated_dag_reachability_oracle(self):
        rng = random.Random(711932)
        for case in range(100):
            records = []
            children = {}
            for i in range(12):
                deps = [r for r in records if rng.randrange(5) == 0]
                record = node(f"n{i}", "obligation" if i % 2 else "claim", deps)
                records.append(record)
                children.setdefault(record["id"], [])
                for dep in deps:
                    children[dep["id"]].append(record["id"])
            withdrawn = [r for r in records if rng.randrange(6) == 0]
            expected = {r["id"] for r in withdrawn}
            todo = list(expected)
            while todo:
                for child in children[todo.pop()]:
                    if child not in expected:
                        expected.add(child)
                        todo.append(child)
            result = replay(document(records, [event("withdraw", r, f"e{i}") for i, r in enumerate(withdrawn)]))
            actual = {r["pin"]["id"] for r in result["records"] if r["applicability"] == "blocked"}
            self.assertEqual(expected, actual, case)

    def test_dependent_evidence_is_blocked_without_changing_its_authored_status(self):
        lemma = node("lemma")
        evidence = node("dependent_argument", "evidence", [lemma], status="claimed_established")
        obligation = node("review", "obligation", [evidence])
        result = self.by_id(replay(document([lemma, evidence, obligation], [event("withdraw", lemma)])))
        self.assertEqual("blocked", result["dependent_argument"]["applicability"])
        self.assertEqual("claimed_established", result["dependent_argument"]["authored_status"])
        self.assertEqual("not_assessed", result["dependent_argument"]["truth_assessment"])
        self.assertFalse(result["dependent_argument"]["proof_accepted"])
        self.assertEqual(["review", "dependent_argument", "lemma"], [p["id"] for p in result["review"]["reasons"][0]["path"]])

    def test_historical_objection_survives_revision_without_attaching_to_new_claim(self):
        from tools.build_fixtures import fixture_documents
        result = replay(fixture_documents()["historical-objection"])
        current = self.by_id(result)["synthetic_lemma"]
        self.assertEqual("no_recorded_dependency_blockers", current["applicability"])
        self.assertFalse(current["proof_accepted"])
        old = [entry for entry in result["history"] if entry["pin"]["id"] == "synthetic_lemma" and entry["pin"]["revision"] == 1][0]
        self.assertFalse(old["current"])
        self.assertEqual(["record_refutation_report", "withdraw"], [e["kind"] for e in old["lifecycle_events"]])
        self.assertEqual("dependency_revision_not_current", self.by_id(result)["synthetic_review"]["reasons"][0]["code"])

    def test_stale_edge_does_not_inherit_replacement_blockers(self):
        from tools.build_fixtures import fixture_documents
        result = self.by_id(replay(fixture_documents()["stale-edge-isolation"]))
        self.assertEqual(["revision_withdrawn"], [r["code"] for r in result["synthetic_lemma"]["reasons"]])
        self.assertEqual(["dependency_revision_not_current"], [r["code"] for r in result["synthetic_review"]["reasons"]])
        self.assertEqual("revise_with_new_premise", result["synthetic_review"]["reasons"][0]["event_id"])

    def test_actual_path_budget_overage(self):
        records = []
        for i in range(64):
            records.append(node(f"chain{i}", deps=records[-1:]))
        self.reject(document(records, [event("withdraw", r, f"event{i}") for i, r in enumerate(records)]), "budget_exceeded")

    def test_exhaustive_four_node_dag_reachability_oracle(self):
        edges = [(parent, child) for child in range(4) for parent in range(child)]
        cases = 0
        for graph_mask in range(64):
            chosen = [edge for bit, edge in enumerate(edges) if graph_mask & (1 << bit)]
            records = []
            for i in range(4):
                records.append(node(f"n{i}", "obligation", [records[parent] for parent, child in chosen if child == i]))
            for withdraw_mask in range(16):
                withdrawn = [i for i in range(4) if withdraw_mask & (1 << i)]
                expected = set(withdrawn)
                todo = list(withdrawn)
                while todo:
                    parent = todo.pop(0)
                    for upstream, child in chosen:
                        if upstream == parent and child not in expected:
                            expected.add(child)
                            todo.append(child)
                result = replay(document(records, [event("withdraw", records[i], f"event{i}") for i in withdrawn]))
                self.assertEqual([f"n{i}" for i in sorted(expected)], result["affected_obligations"], (graph_mask, withdraw_mask))
                cases += 1
        self.assertEqual(1024, cases)

    def test_rejection_fixtures(self):
        from tools.build_fixtures import rejection_documents
        root = Path(__file__).resolve().parents[1]
        for name, (doc, expected) in rejection_documents().items():
            self.assertEqual(doc, loads((root / "fixtures" / (name + ".input.json")).read_bytes()))
            self.assertEqual(expected, json.loads((root / "fixtures" / (name + ".rejection.json")).read_text()))
            with self.assertRaises(LedgerError) as raised:
                replay(doc)
            self.assertEqual(expected["code"], raised.exception.code)
            self.assertEqual(expected["path"], raised.exception.path)

    def test_fixture_goldens(self):
        root = Path(__file__).resolve().parents[1]
        paths = sorted((root / "fixtures").glob("*.ledger.json"))
        self.assertEqual(8, len(paths))
        for path in paths:
            expected = json.loads(path.with_name(path.name.replace(".ledger.json", ".expected.json")).read_text())
            self.assertEqual(expected, replay(loads(path.read_bytes())), path.name)


if __name__ == "__main__": unittest.main()
