# Foundation Math: typed hypothesis scope lab

A small **standalone local prototype**, not a Foundation Math release, repository,
proof checker, geometry engine, or new bridge tool.

It answers one bounded question:

> Do the explicitly bound, currently supplied, non-withdrawn authored facts
> have exactly the typed predicates required by this exact pinned rule?

A positive answer is **syntactic matching only**. It neither verifies a supplied
fact nor shows the rule is valid or sufficient. It never accepts a mathematical
claim, discharges a runtime goal, checks Lean, or establishes actual geometry.
An incorrect mathematical assertion can match perfectly.

## Try it

Python 3.10+ and the standard library are sufficient; validation was run with the
Python version recorded in the external author receipt. No installs, network,
model calls, credentials, or sibling checkout are needed.

```sh
python -B -m hypothesis_scope < fixtures/exact-full-kernel.json
python -B -m hypothesis_scope < fixtures/two-step-not-one-step.json
python -B tools/validate.py
python -B tools/package.py --output /tmp/hypothesis-scope-lab.zip
```

The first command reports `all_requirements_matched: true`. The second reports
`predicate_mismatch`, not a mathematical counterexample. Both exit zero because
the check completed. Malformed, unsupported, or over-budget input exits two with
a structured error. The CLI accepts stdin only, with no paths or options.

`tools/validate.py` is the single aggregate: verifies the frozen source selection,
runs normal and `-O` tests, and repeats both from a selected-only temporary copy.
The packaging command uses deterministic stored ZIP entries; the aggregate checks
byte-identical rebuilding. No historical release test suite is claimed to run.

## What is protected

- Generic sheaf equality is not coherent-sheaf equality.
- A selected subkernel is not the full kernel of a specified map.
- An abstract splitting is not the splitting of the actual embedded object/map.
- Saturated image is not coherent image; both retain map and inclusion provenance.
- Physical representation labels remain distinct: W/Wp, A/V, and catalog identity.
- Equal dimension or rank never identifies objects or maps.
- Vanishing after two maps is not vanishing after one. The constants object,
  its inclusion, every ordered map, and each endpoint are pinned.
- Original and induced torsion assertions retain their distinct role and maps.
- Revised records do not automatically rebind their users. Hashes and record
  revisions must match the supplied current snapshot exactly.

All matching is exact, including operand order. There is **no weakening relation**,
no symmetry/transitivity rule, no inferred composite-map equality, no variable
instantiation, no search for a different fact, and no natural-language entailment.
Even an explicit identity premise is not used as a rewrite instruction.

See [CONTRACT.md](docs/CONTRACT.md) for the normative shape and semantics,
[VALIDATION.md](docs/VALIDATION.md) for test claims and reproduction,
and [INTEGRATION-BOUNDARY.md](docs/INTEGRATION-BOUNDARY.md) for the existing ledger
and unchanged fifteen-tool runtime boundary. The structural JSON Schema is a
convenience; the pure core is authoritative.
