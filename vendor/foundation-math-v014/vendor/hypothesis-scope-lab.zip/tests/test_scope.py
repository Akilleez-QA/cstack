import copy
import itertools
import json
import os
import subprocess
import sys
import unittest
from hypothesis_scope import ScopeError, canonical_bytes, check, digest, loads, pin
from hypothesis_scope.core import PREDICATES, PHYSICAL_LABELS
from tests.support import document, fixture, record, reseal


class ScopeTests(unittest.TestCase):
    def test_all_18_predicates_and_ordered_pairs(self):
        _, _, samples = fixture()
        self.assertEqual(set(samples), set(PREDICATES))
        self.assertEqual(len(samples), 18)
        for required, supplied in itertools.product(samples.values(), repeat=2):
            with self.subTest(required=required["kind"], supplied=supplied["kind"]):
                result = check(document(required, supplied))
                self.assertEqual(result["all_requirements_matched"], required == supplied)
                for field in ("fact_truth_checked", "rule_soundness_checked", "geometry_checked", "runtime_acceptance", "lean_proof"):
                    self.assertIs(result[field], False)

    def test_two_step_does_not_imply_one_step_exhaustive_paths(self):
        _, maps, samples = fixture()
        cv = samples["constant_vanishing"]
        paths = [list(p) for length in range(1, 5) for p in itertools.product((pin(maps["loopS"]), pin(maps["loopAltS"])), repeat=length)]
        self.assertEqual(len(paths), 30)
        for needed, supplied in itertools.product(paths, repeat=2):
            result = check(document({**cv, "path": needed}, {**cv, "path": supplied}))
            self.assertEqual(result["all_requirements_matched"], needed == supplied)
        # Explicit ordinary composable two-step versus first-step and second-step trap.
        _, _, samples = fixture()
        pair = samples["constant_vanishing"]
        self.assertFalse(check(document({**pair, "path": [pair["path"][0]]}, pair))["all_requirements_matched"])

    def test_physical_labels_are_never_dimensions(self):
        _, _, samples = fixture()
        base = samples["physical_representation"]
        for need, have in itertools.product(PHYSICAL_LABELS, repeat=2):
            self.assertEqual(check(document({**base, "label": need}, {**base, "label": have}))["all_requirements_matched"], need == have)
        for label, value in (("W", 2), ("Wp", 2), ("A", 3), ("V", 3)):
            self.assertFalse(check(document({**base, "label": label}, {**samples["object_dimension"], "value": value}))["all_requirements_matched"])
        self.assertFalse(check(document(base, {**base, "catalog_sha256": "f" * 64}))["all_requirements_matched"])

    def test_original_induced_torsion_and_exact_map(self):
        _, maps, samples = fixture()
        variants = [{**samples["torsion_identification"], "role": role, "of_map": pin(maps[map_id])} for role in ("original", "induced") for map_id in ("fST", "fAltST")]
        for need, have in itertools.product(variants, repeat=2):
            self.assertEqual(check(document(need, have))["all_requirements_matched"], need == have)

    def test_same_rank_and_endpoint_do_not_identify_maps(self):
        objects, maps, samples = fixture()
        self.assertFalse(check(document(samples["map_zero"], {**samples["map_zero"], "map": pin(maps["fAltST"])}))["all_requirements_matched"])
        self.assertFalse(check(document(samples["object_rank"], {**samples["object_rank"], "object": pin(objects["T"])}))["all_requirements_matched"])
        # Even an explicit object-identity premise is not an automatic rewrite rule.
        d = document(samples["object_rank"], {**samples["object_rank"], "object": pin(objects["T"])})
        extra = record("Identity", {"predicate": {"kind": "object_identity", "left": pin(objects["S"]), "right": pin(objects["T"])}, "availability": "supplied", "provenance": d["facts"][0]["content"]["provenance"]})
        d["facts"].append(extra)
        self.assertFalse(check(d)["all_requirements_matched"])

    def test_missing_bindings_do_not_scan_other_facts(self):
        d = document()
        d["application"]["bindings"] = []
        self.assertEqual(check(d)["requirements"][0]["status"], "missing_binding")
        d["application"]["bindings"] = [{"requirement_id": "premise", "fact": {"id": "Absent", "revision": 1, "revision_sha256": "0" * 64}}]
        self.assertEqual(check(d)["requirements"][0]["status"], "fact_not_supplied")

    def test_stale_fact_and_rule_pins_never_rebind(self):
        for target in ("fact", "rule"):
            for field, new in (("revision", 2), ("revision_sha256", "0" * 64), ("id", "Absent")):
                d = document()
                ref = d["application"]["bindings"][0]["fact"] if target == "fact" else d["application"]["rule"]
                ref[field] = new
                result = check(d)
                self.assertFalse(result["all_requirements_matched"])
        d = document(availability="withdrawn")
        self.assertEqual(check(d)["requirements"][0]["status"], "fact_withdrawn")
        d = document()
        d["facts"][0]["revision"] = 2
        d["facts"][0] = reseal(d["facts"][0])
        self.assertEqual(check(d)["requirements"][0]["status"], "fact_pin_not_current")

    def test_resealed_object_revision_requires_every_map_and_premise_repin(self):
        d = document()
        d["objects"][0]["revision"] = 2
        d["objects"][0] = reseal(d["objects"][0])
        with self.assertRaisesRegex(ScopeError, "pin_mismatch"):
            check(d)

    def test_provenance_cannot_be_missing_and_hash_is_not_truth(self):
        d = document()
        del d["facts"][0]["content"]["provenance"]
        d["facts"][0] = reseal(d["facts"][0])
        with self.assertRaisesRegex(ScopeError, "fields"):
            check(d)
        d = document()
        d["facts"][0]["content"]["provenance"]["artifact_sha256"] = "0" * 64
        d["facts"][0] = reseal(d["facts"][0])
        d["application"]["bindings"][0]["fact"] = pin(d["facts"][0])
        result = check(d)
        self.assertTrue(result["all_requirements_matched"])
        self.assertFalse(result["fact_truth_checked"])

    def test_kernel_and_image_map_provenance_cannot_be_missing_or_swapped(self):
        _, maps, samples = fixture()
        for kind in ("full_kernel", "selected_subkernel", "coherent_image", "saturated_image"):
            for field in ("of_map", "inclusion"):
                required = dict(samples[kind])
                del required[field]
                with self.assertRaisesRegex(ScopeError, "fields"):
                    check(document(required))
            other = {**samples[kind], "of_map": pin(maps["fAltST"])}
            self.assertFalse(check(document(samples[kind], other))["all_requirements_matched"])
        with self.assertRaisesRegex(ScopeError, "map_endpoint"):
            check(document({**samples["full_kernel"], "inclusion": pin(maps["incIT"])}))

    def test_duplicate_unknown_keys_and_wrong_exact_types(self):
        with self.assertRaisesRegex(ScopeError, "duplicate_key"):
            loads('{"x":1,"x":2}')
        for raw in ('1.0', 'NaN', 'Infinity', '"\\ud800"', b'\xff', '{} trailing'):
            with self.assertRaises(ScopeError):
                loads(raw)
        for bad in (True, 1.0, "1", None, 0, 1000001):
            d = document()
            d["objects"][0]["revision"] = bad
            with self.assertRaises(ScopeError):
                check(d)
        d = document()
        d["accept_proof"] = True
        with self.assertRaisesRegex(ScopeError, "fields"):
            check(d)
        d = document()
        d["facts"][0]["content"]["predicate"]["kind"] = "infer_anything"
        d["facts"][0] = reseal(d["facts"][0])
        with self.assertRaisesRegex(ScopeError, "predicate_kind"):
            check(d)

    def test_record_content_is_integrity_bound(self):
        for field in ("objects", "maps", "facts"):
            d = document()
            d[field][0]["revision_sha256"] = "0" * 64
            with self.assertRaisesRegex(ScopeError, "record_hash_mismatch"):
                check(d)
        d = document()
        d["rule"]["content"]["purpose"] = "changed"
        with self.assertRaisesRegex(ScopeError, "record_hash_mismatch"):
            check(d)

    def test_namespace_collisions_and_duplicate_bindings(self):
        d = document()
        d["maps"][0]["id"] = d["objects"][0]["id"]
        d["maps"][0] = reseal(d["maps"][0])
        with self.assertRaisesRegex(ScopeError, "duplicate_id"):
            check(d)
        d = document()
        d["application"]["bindings"] *= 2
        with self.assertRaisesRegex(ScopeError, "duplicate_binding"):
            check(d)

    def test_all_required_no_optional_or_alternative_semantics(self):
        _, _, samples = fixture()
        d = document()
        d["rule"]["content"]["requirements"].append({"id": "extra", "predicate": samples["map_injective"]})
        d["rule"] = reseal(d["rule"])
        d["application"]["rule"] = pin(d["rule"])
        result = check(d)
        self.assertFalse(result["all_requirements_matched"])
        self.assertEqual({r["status"] for r in result["requirements"]}, {"exact_match", "missing_binding"})

    def test_input_order_no_mutation_and_determinism(self):
        d = document()
        original = copy.deepcopy(d)
        first = check(d)
        self.assertEqual(d, original)
        for field in ("objects", "maps", "facts"):
            d[field].reverse()
        self.assertEqual(first, check(d))
        self.assertEqual(first, check(loads(canonical_bytes(d))))

    def test_strict_python_types_cycles_depth_and_bytes(self):
        class D(dict):
            pass
        class I(int):
            pass
        for val in (D(), I(1), (1,), {1: "key"}):
            with self.assertRaises(ScopeError):
                check(val)
        cyclic = []
        cyclic.append(cyclic)
        with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
            check(cyclic)
        nested = 0
        for _ in range(17):
            nested = [nested]
        with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
            check(nested)
        with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
            loads(b" " * 262145)
        with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
            loads("[" + "1" * 1000 + "]")

    def test_cardinality_boundaries(self):
        d = document()
        d["objects"] = [record("Obj" + str(i), d["objects"][0]["content"]) for i in range(65)]
        with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
            check(d)
        d = document()
        d["rule"]["content"]["requirements"] = [{"id": "r" + str(i), "predicate": d["facts"][0]["content"]["predicate"]} for i in range(32)]
        d["rule"] = reseal(d["rule"])
        d["application"] = {"rule": pin(d["rule"]), "bindings": [{"requirement_id": "r" + str(i), "fact": pin(d["facts"][0])} for i in range(32)]}
        self.assertTrue(check(d)["all_requirements_matched"])
        d["rule"]["content"]["requirements"].append({"id": "extra", "predicate": d["facts"][0]["content"]["predicate"]})
        d["rule"] = reseal(d["rule"])
        with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
            check(d)

    def test_cli_exit_codes_and_stdin_only(self):
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        for data, args, code in ((canonical_bytes(document()), [], 0), (b"{}", [], 2), (b"{}", ["file.json"], 2)):
            p = subprocess.run([sys.executable, "-B", "-m", "hypothesis_scope", *args], input=data, capture_output=True, env=env, check=False)
            self.assertEqual(p.returncode, code, p.stderr)
            self.assertEqual(p.stderr, b"")
            self.assertIsInstance(json.loads(p.stdout), dict)
        d = document()
        d["application"]["bindings"] = []
        p = subprocess.run([sys.executable, "-B", "-m", "hypothesis_scope"], input=canonical_bytes(d), capture_output=True, env=env, check=False)
        self.assertEqual(p.returncode, 0)  # Successfully computed a blocked syntactic report.
        self.assertFalse(json.loads(p.stdout)["all_requirements_matched"])


if __name__ == "__main__":
    unittest.main()
