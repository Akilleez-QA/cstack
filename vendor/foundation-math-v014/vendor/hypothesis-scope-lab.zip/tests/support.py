"""Synthetic scope examples, not geometric computations or actual research instances."""
from hypothesis_scope import VERSION, digest, pin, seal


def record(rid, content, revision=1):
    return seal({"id": rid, "revision": revision, "content": content})


def fixture():
    context = digest({"synthetic_context": "scope-only-toy"})
    objects = {}
    for kind, names in (("coherent_sheaf", ("K", "S", "T", "I", "Z", "Q", "K2")), ("formal_splitting", ("D", "D2")), ("representation", ("R", "R2")), ("vector_space", ("V1", "V2")), ("locus", ("U", "U2"))):
        for name in names:
            objects[name] = record(name, {"object_type": kind, "context_sha256": context, "description": "Authored synthetic object " + name})
    maps = {}
    for name, source, target in (("incKS", "K", "S"), ("fST", "S", "T"), ("fAltST", "S", "T"), ("gTZ", "T", "Z"), ("incIT", "I", "T"), ("torsionKQ", "K", "Q"), ("torsionK2Q", "K2", "Q"), ("loopS", "S", "S"), ("loopAltS", "S", "S"), ("vectorMap", "V1", "V2")):
        maps[name] = record(name, {"source": pin(objects[source]), "target": pin(objects[target]), "description": "Authored synthetic map " + name})
    o = lambda name: pin(objects[name])
    m = lambda name: pin(maps[name])
    samples = {
        "generic_sheaf_equality": {"left": o("K"), "right": o("S"), "locus": o("U")},
        "coherent_sheaf_equality": {"left": o("K"), "right": o("S")},
        "selected_subkernel": {"kernel": o("K"), "inclusion": m("incKS"), "of_map": m("fST")},
        "full_kernel": {"kernel": o("K"), "inclusion": m("incKS"), "of_map": m("fST")},
        "abstract_splitting": {"object": o("S"), "splitting": o("D")},
        "embedded_splitting": {"object": o("S"), "splitting": o("D"), "inclusion": m("fST")},
        "coherent_image": {"image": o("I"), "inclusion": m("incIT"), "of_map": m("fST")},
        "saturated_image": {"image": o("I"), "inclusion": m("incIT"), "of_map": m("fST")},
        "physical_representation": {"object": o("R"), "catalog_sha256": digest({"synthetic_catalog": "label-only"}), "label": "W"},
        "object_rank": {"object": o("S"), "value": 2},
        "object_dimension": {"object": o("R"), "value": 2},
        "map_rank": {"map": m("fST"), "value": 2},
        "map_injective": {"map": m("fST")},
        "map_zero": {"map": m("fST")},
        "constant_vanishing": {"constants": o("K"), "inclusion": m("incKS"), "path": [m("fST"), m("gTZ")]},
        "torsion_identification": {"role": "original", "torsion": o("K"), "of_map": m("fST"), "identified_with": o("Q"), "identification": m("torsionKQ")},
        "object_identity": {"left": o("K"), "right": o("S")},
        "map_identity": {"left": m("fST"), "right": m("fAltST")},
    }
    samples = {k: {"kind": k, **v} for k, v in samples.items()}
    return objects, maps, samples


def document(required=None, supplied=None, fact_id="Fact", availability="supplied"):
    objects, maps, samples = fixture()
    required = samples["full_kernel"] if required is None else required
    supplied = required if supplied is None else supplied
    fact = record(fact_id, {"predicate": supplied, "availability": availability, "provenance": {"artifact_sha256": digest({"authored": "synthetic assertion, artifact not fetched"}), "description": "Caller-authored, unchecked synthetic assertion"}})
    rule = record("Rule", {"purpose": "Check only these supplied premises; no conclusion is proved", "requirements": [{"id": "premise", "predicate": required}]})
    return {"schema": VERSION, "objects": list(objects.values()), "maps": list(maps.values()), "facts": [fact], "rule": rule, "application": {"rule": pin(rule), "bindings": [{"requirement_id": "premise", "fact": pin(fact)}]}}


def reseal(rec):
    return seal({k: rec[k] for k in ("id", "revision", "content")})
