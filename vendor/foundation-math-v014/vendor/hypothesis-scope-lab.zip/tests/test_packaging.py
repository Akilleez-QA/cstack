import hashlib
import importlib.util
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("scope_packaging", ROOT / "tools/package.py")
packaging = importlib.util.module_from_spec(spec)
spec.loader.exec_module(packaging)


class PackagingTests(unittest.TestCase):
    def test_current_selection_and_review_subject(self):
        self.assertTrue(packaging.verify())
        review = (ROOT / "docs/INDEPENDENT-REVIEW.md").read_text()
        for name in ("hypothesis_scope/core.py", "review/independent_review.py"):
            self.assertIn(hashlib.sha256((ROOT / name).read_bytes()).hexdigest(), review)

    def test_tampering_fails_not_resealed_automatically(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in [packaging.MANIFEST, *packaging.selected()]:
                target = root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ROOT / name, target)
            self.assertTrue(packaging.verify(root))
            (root / "hypothesis_scope/core.py").write_bytes(b"modified")
            with self.assertRaisesRegex(ValueError, "immutable manifest"):
                packaging.verify(root)

    def test_deterministic_archive_and_no_source_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            one, two = Path(directory) / "one.zip", Path(directory) / "two.zip"
            a, b = packaging.build(one), packaging.build(two)
            self.assertEqual(a, b)
            self.assertEqual(one.read_bytes(), two.read_bytes())
        for name in (packaging.MANIFEST, "hypothesis_scope/core.py"):
            with self.assertRaisesRegex(ValueError, "overwrite selected source"):
                packaging.build(ROOT / name)


if __name__ == "__main__":
    unittest.main()
