import copy
import unittest

from hypothesis_scope import ScopeError, check, digest, pin
from hypothesis_scope.core import canonical_bytes
from tests.support import document, fixture, record, reseal


class BoundaryTests(unittest.TestCase):
    def test_registry_count_caps_including_exact_maximum(self):
        for field in ("objects", "maps", "facts"):
            d = document()
            original = d[field][0]
            while len(d[field]) < 64:
                d[field].append(record("Extra" + str(len(d[field])), original["content"]))
            self.assertTrue(check(d)["all_requirements_matched"])
            d[field].append(record("Overflow", original["content"]))
            with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
                check(d)

    def test_path_length_and_composition(self):
        _, maps, samples = fixture()
        p = samples["constant_vanishing"]
        for count in (0, 5):
            with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
                check(document({**p, "path": [pin(maps["loopS"])] * count}))
        with self.assertRaisesRegex(ScopeError, "map_endpoint"):
            check(document({**p, "path": list(reversed(p["path"]))}))
        with self.assertRaisesRegex(ScopeError, "map_endpoint"):
            check(document({**p, "inclusion": pin(maps["fST"])}))

    def test_type_context_and_exact_namespace(self):
        objects, maps, samples = fixture()
        with self.assertRaisesRegex(ScopeError, "object_type"):
            check(document({**samples["object_rank"], "object": pin(objects["R"])}))
        with self.assertRaisesRegex(ScopeError, "missing_reference"):
            check(document({**samples["map_zero"], "map": pin(objects["S"])}))
        d = document()
        new = record("Outside", {**objects["T"]["content"], "context_sha256": "f" * 64})
        d["objects"].append(new)
        d["rule"]["content"]["requirements"][0]["predicate"] = {"kind": "coherent_sheaf_equality", "left": pin(objects["S"]), "right": pin(new)}
        d["rule"] = reseal(d["rule"])
        with self.assertRaisesRegex(ScopeError, "context_mismatch"):
            check(d)

    def test_text_identifier_and_numeric_bounds(self):
        d = document()
        for count, allowed in ((1024, True), (1025, False)):
            changed = copy.deepcopy(d)
            changed["rule"]["content"]["purpose"] = "x" * count
            changed["rule"] = reseal(changed["rule"])
            changed["application"]["rule"] = pin(changed["rule"])
            if allowed:
                self.assertTrue(check(changed)["all_requirements_matched"])
            else:
                with self.assertRaises(ScopeError):
                    check(changed)
        for bad in ("", " \t\n"):
            changed = copy.deepcopy(d)
            changed["rule"]["content"]["purpose"] = bad
            changed["rule"] = reseal(changed["rule"])
            with self.assertRaises(ScopeError):
                check(changed)
        for length in (1, 64):
            self.assertEqual(len(record("a" * length, {})["id"]), length)
        for name in ("a" * 65, "1bad", "not allowed", "é"):
            with self.assertRaises(ScopeError):
                record(name, {})
        _, _, samples = fixture()
        for n in (0, 1000000):
            self.assertTrue(check(document({**samples["map_rank"], "value": n}))["all_requirements_matched"])
        for n in (-1, 1000001, True, 1.0):
            with self.assertRaises(ScopeError):
                check(document({**samples["map_rank"], "value": n}))

    def test_raw_guard_edges(self):
        self.assertEqual(canonical_bytes([0] * 256), b"[" + b",".join([b"0"] * 256) + b"]")
        for invalid in ([0] * 257, {str(i): i for i in range(17)}, "x" * 2049, -(2**31)-1, 2**31):
            with self.assertRaisesRegex(ScopeError, "budget_exceeded"):
                canonical_bytes(invalid)
        canonical_bytes({str(i): i for i in range(16)})
        canonical_bytes("x" * 2048)
        canonical_bytes(-(2**31))
        canonical_bytes(2**31 - 1)

    def test_operand_order_and_unicode_are_material(self):
        _, _, samples = fixture()
        pred = samples["coherent_sheaf_equality"]
        self.assertFalse(check(document(pred, {**pred, "left": pred["right"], "right": pred["left"]}))["all_requirements_matched"])
        self.assertNotEqual(digest({"x": "é"}), digest({"x": "e\u0301"}))


if __name__ == "__main__":
    unittest.main()
