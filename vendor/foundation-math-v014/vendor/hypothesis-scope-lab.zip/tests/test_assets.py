import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from hypothesis_scope import check, loads
from hypothesis_scope.core import PREDICATES

ROOT = Path(__file__).resolve().parents[1]


class AssetTests(unittest.TestCase):
    def test_all_frozen_examples(self):
        expected = json.loads((ROOT / "fixtures/expectations.json").read_text())
        self.assertEqual(len(expected), 12)
        for name, values in expected.items():
            with self.subTest(name=name):
                result = check(loads((ROOT / "fixtures" / (name + ".json")).read_bytes()))
                self.assertEqual(result["all_requirements_matched"], values["all_requirements_matched"])
                self.assertEqual(result["requirements"][0]["status"], values["status"])

    def test_schema_closed_kind_coverage(self):
        schema = json.loads((ROOT / "schemas/request.schema.json").read_text())
        self.assertIs(schema["additionalProperties"], False)
        variants = schema["$defs"]["predicate"]["oneOf"]
        self.assertEqual({v["properties"]["kind"]["const"] for v in variants}, set(PREDICATES))
        for variant in variants:
            self.assertIs(variant["additionalProperties"], False)
            self.assertEqual(set(variant["required"]), set(variant["properties"]))


if __name__ == "__main__":
    unittest.main()
