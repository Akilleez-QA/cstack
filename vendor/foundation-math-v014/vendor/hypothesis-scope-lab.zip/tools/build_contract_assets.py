"""Deterministically regenerate the descriptive schema and synthetic fixtures."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from hypothesis_scope import pin
from hypothesis_scope.core import OBJECT_TYPES, PHYSICAL_LABELS, PREDICATES, VERSION
from tests.support import document, fixture, reseal


def closed(properties):
    return {"type": "object", "additionalProperties": False, "required": list(properties), "properties": properties}


def write(relative, value):
    (ROOT / relative).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main():
    ident = {"type": "string", "pattern": "^[A-Za-z][A-Za-z0-9_.-]{0,63}$", "maxLength": 64}
    hsh = {"type": "string", "pattern": "^[0-9a-f]{64}$", "maxLength": 64}
    text = {"type": "string", "minLength": 1, "maxLength": 1024}
    natural = {"type": "integer", "minimum": 0, "maximum": 1000000}
    ref = {"$ref": "#/$defs/pin"}
    pin_schema = closed({"id": ident, "revision": {**natural, "minimum": 1}, "revision_sha256": hsh})
    def record_schema(content):
        return closed({"id": ident, "revision": {**natural, "minimum": 1}, "revision_sha256": hsh, "content": content})
    variants = []
    for kind, fields in PREDICATES.items():
        props = {"kind": {"const": kind}}
        for field, category in fields.items():
            props[field] = {"hash": hsh, "natural": natural, "label": {"enum": list(PHYSICAL_LABELS)}, "torsion_role": {"enum": ["original", "induced"]}, "map_path": {"type": "array", "minItems": 1, "maxItems": 4, "items": ref}}.get(category, ref)
        variants.append(closed(props))
    predicate = {"$ref": "#/$defs/predicate"}
    obj_record = record_schema(closed({"object_type": {"enum": list(OBJECT_TYPES)}, "context_sha256": hsh, "description": text}))
    map_record = record_schema(closed({"source": ref, "target": ref, "description": text}))
    fact_record = record_schema(closed({"predicate": predicate, "availability": {"enum": ["supplied", "withdrawn"]}, "provenance": closed({"artifact_sha256": hsh, "description": text})}))
    requirement = closed({"id": ident, "predicate": predicate})
    rule = record_schema(closed({"purpose": text, "requirements": {"type": "array", "minItems": 1, "maxItems": 32, "items": requirement}}))
    schema = closed({"schema": {"const": VERSION}, "objects": {"type": "array", "maxItems": 64, "items": obj_record}, "maps": {"type": "array", "maxItems": 64, "items": map_record}, "facts": {"type": "array", "maxItems": 64, "items": fact_record}, "rule": rule, "application": closed({"rule": ref, "bindings": {"type": "array", "maxItems": 32, "items": closed({"requirement_id": ident, "fact": ref})}})})
    schema.update({"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "urn:foundation-math:hypothesis-scope:1", "$defs": {"pin": pin_schema, "predicate": {"oneOf": variants}}, "description": "Structural aid only. The pure checker additionally enforces exact JSON types, integrity, references, contexts, endpoints, uniqueness, chronology-free current snapshot pins, and aggregate budgets."})
    write("schemas/request.schema.json", schema)
    _, maps, samples = fixture()
    cases = {
        "exact-full-kernel": document(),
        "generic-not-coherent": document(samples["coherent_sheaf_equality"], samples["generic_sheaf_equality"]),
        "selected-not-full-kernel": document(samples["full_kernel"], samples["selected_subkernel"]),
        "abstract-not-embedded": document(samples["embedded_splitting"], samples["abstract_splitting"]),
        "saturated-not-coherent-image": document(samples["coherent_image"], samples["saturated_image"]),
        "two-step-not-one-step": document({**samples["constant_vanishing"], "path": [pin(maps["fST"])]}, samples["constant_vanishing"]),
        "original-not-induced-torsion": document({**samples["torsion_identification"], "role": "induced"}, samples["torsion_identification"]),
        "W-not-Wp": document({**samples["physical_representation"], "label": "Wp"}, samples["physical_representation"]),
        "A-not-V": document({**samples["physical_representation"], "label": "A"}, {**samples["physical_representation"], "label": "V"}),
        "same-endpoints-not-same-map": document(samples["map_zero"], {**samples["map_zero"], "map": pin(maps["fAltST"])}),
        "withdrawn-fact": document(availability="withdrawn"),
    }
    stale = document()
    stale["facts"][0]["revision"] = 2
    stale["facts"][0] = reseal(stale["facts"][0])
    cases["stale-fact-pin"] = stale
    expectations = {}
    for name, doc in cases.items():
        write("fixtures/" + name + ".json", doc)
        expectations[name] = {"all_requirements_matched": name == "exact-full-kernel", "status": "exact_match" if name == "exact-full-kernel" else "fact_pin_not_current" if name == "stale-fact-pin" else "fact_withdrawn" if name == "withdrawn-fact" else "predicate_mismatch"}
    write("fixtures/expectations.json", expectations)


if __name__ == "__main__":
    main()
