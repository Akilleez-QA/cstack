"""Frozen source selection, hash verification, and deterministic local ZIP."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SELECTION = "SELECTION.json"
MANIFEST = "SOURCE-MANIFEST.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def selected(root=ROOT):
    selection = json.loads((root / SELECTION).read_text(encoding="utf-8"))
    if type(selection) is not list or selection != sorted(set(selection)) or SELECTION not in selection or MANIFEST in selection:
        raise ValueError("Invalid frozen selection")
    for name in selection:
        if type(name) is not str or str(PurePosixPath(name)) != name or PurePosixPath(name).is_absolute() or any(p in (".", "..") for p in PurePosixPath(name).parts):
            raise ValueError("Unsafe selection path")
        path = root / name
        if not path.is_file() or path.is_symlink() or root.resolve() not in path.resolve().parents:
            raise ValueError("Selection requires ordinary in-root files")
    return selection


def manifest(root=ROOT):
    return {"schema": "foundation-math-hypothesis-scope-source-selection/1", "files": {name: sha((root / name).read_bytes()) for name in selected(root)}}


def verify(root=ROOT):
    expected = json.loads((root / MANIFEST).read_text(encoding="utf-8"))
    actual = manifest(root)
    if expected != actual:
        raise ValueError("Selected source bytes differ from the immutable manifest")
    return actual


def build(output, root=ROOT):
    verify(root)
    if output.resolve() == (root / MANIFEST).resolve() or output.resolve() in {(root / name).resolve() for name in selected(root)}:
        raise ValueError("Output may not overwrite selected source")
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED) as archive:
        for name in sorted([MANIFEST, *selected(root)]):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, (root / name).read_bytes())
    return {"archive_sha256": sha(output.read_bytes()), "archive_bytes": output.stat().st_size, "selected_files": len(selected(root)) + 1}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--seal", action="store_true", help="Author operation: deliberately replace the source manifest after reviewed changes")
    args = parser.parse_args()
    if args.seal:
        (ROOT / MANIFEST).write_text(json.dumps(manifest(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    result = {"selection_verified": bool(verify())}
    if args.output:
        result.update(build(args.output))
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
