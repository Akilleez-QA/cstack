"""Single portable aggregate: pinned sources, normal/-O tests and isolated rebuild."""
from pathlib import Path
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from package import MANIFEST, build, selected, sha, verify


def run_tests(root):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    env.pop("PYTHONPATH", None)
    reports = []
    for optimized in (False, True):
        options = ["-O", "-B"] if optimized else ["-B"]
        for command in (["-m", "unittest", "discover", "-q"], ["review/independent_review.py", "."]):
            result = subprocess.run([sys.executable, *options, *command], cwd=root, env=env, capture_output=True, text=True, check=False, timeout=120)
            if result.returncode:
                raise RuntimeError(f"Failed {options + command}\n{result.stdout}\n{result.stderr}")
            reports.append({"optimized": optimized, "command": command, "returncode": result.returncode, "stdout": result.stdout.strip(), "stderr": result.stderr.strip()})
    return reports


def main():
    verify()
    original = run_tests(ROOT)
    with tempfile.TemporaryDirectory(prefix="hypothesis-scope-selected-") as temp:
        temp = Path(temp)
        first, second = temp / "first.zip", temp / "second.zip"
        receipt = build(first)
        delivery = temp / "selected"
        delivery.mkdir()
        # Only our verified fixed-entry archive is extracted, never an external ZIP.
        with zipfile.ZipFile(first) as archive:
            archive.extractall(delivery)
        if sorted(p.relative_to(delivery).as_posix() for p in delivery.rglob("*") if p.is_file()) != sorted([MANIFEST, *selected()]):
            raise RuntimeError("Selected-only extraction differs")
        verify(delivery)
        portable = run_tests(delivery)
        build(second, delivery)
        if first.read_bytes() != second.read_bytes():
            raise RuntimeError("Deterministic archive reproduction failed")
        # Regeneration happens only in the selected temporary copy.
        before = {name: (delivery / name).read_bytes() for name in selected(delivery) if name.startswith(("fixtures/", "schemas/"))}
        process = subprocess.run([sys.executable, "-B", "tools/build_contract_assets.py"], cwd=delivery, capture_output=True, text=True, timeout=120)
        if process.returncode or any((delivery / name).read_bytes() != data for name, data in before.items()):
            raise RuntimeError("Schema/fixture deterministic regeneration failed")
        verify(delivery)
    verify()
    print(json.dumps({"schema": "foundation-math-hypothesis-scope-validation/1", "python": platform.python_version(), "selection_verified": True, "selected_only_verified": True, "deterministic_zip": True, "deterministic_assets": True, "source_manifest_sha256": sha((ROOT / MANIFEST).read_bytes()), **receipt, "original": original, "selected_only": portable, "mathematical_truth_verified": False, "runtime_acceptance": False, "network_calls": 0, "model_calls": 0}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
