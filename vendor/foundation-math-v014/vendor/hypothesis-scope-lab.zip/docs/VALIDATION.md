# Validation and immutable local artifact

## One aggregate

```sh
PYTHONDONTWRITEBYTECODE=1 python -B tools/validate.py
```

The aggregate verifies every source selected by `SELECTION.json` against
`SOURCE-MANIFEST.json`, runs the 29 author test methods and 19 independent-review
methods under both normal Python and `python -O`, then builds a deterministic ZIP,
extracts only those selected files into a fresh temporary directory, reruns the
same normal/optimized suites there, and rebuilds the ZIP byte-identically.
It also regenerates schema/fixtures only in that temporary copy and verifies exact
byte identity. No sibling checkout, historical release ZIP, generated evidence,
network access, installation, model, clock, or credentials are inputs to checking.
The author receipt is generated outside the selection, avoiding self-reference.

The aggregate does not rerun Foundation Math v0.12's full historical aggregate.
Instead, author-side baseline preservation checks compare all 401 selected v0.12
source files against that release's manifest, and record the unchanged runtime
projection and fifteen bridge tool contracts in `BASELINE-PINS.json`. The lab itself
has no dependency on those files. Normal/-O and selected-only claims here apply to
this lab, not an unrun baseline release or real Lean backend.

## What “exhaustive bounded” means here

These are complete enumerations of explicitly stated finite test subdomains,
**not exhaustive enumeration of every possible bounded input document**:

- 18 × 18 = 324 ordered offered/required predicate-kind pairs, with valid synthetic
  representatives. Only structurally identical predicates match.
- All 30 nonempty words of lengths 1..4 over two distinct composable self-maps;
  all 30 × 30 = 900 offered/required word pairs. Only identical ordered paths match.
  The named constants object and inclusion are pinned in every case.
- 9 × 9 = 81 offered/required physical-label pairs, including W/Wp and A/V.
- 4 × 4 = 16 offered/required torsion variants over two roles and two origin maps.

The independent review separately constructs and hashes its inputs, with its own
324-kind-pair and 81-label-pair matrices. It does not reuse the author fixtures,
sealing helpers, hash helpers, or expected-output builder.

Focused adversarial controls cover the full/selected kernel and coherent/saturated
image distinctions, actual embeddings, rank/dimension and object/map identities,
constants subobjects and inclusions, original/induced torsion and identification
maps, missing provenance, stale nested and application pins, withdrawal, explicit
all-required binding, unknown keys/kinds/labels, wrong namespaces, map endpoints,
context mismatches, duplicate IDs/requirements/bindings/JSON keys, bool-as-int,
floats, invalid UTF-8, unpaired surrogates, cycles, depth, integer and byte limits,
array and field limits, exact maximum registry sizes, requirement/path caps,
normalization policy, report determinism, non-mutation and stdin-only CLI behavior.
Packaging tests detect changed source bytes and prohibit overwriting selected files.

Twelve frozen synthetic fixtures cover a positive exact match and the principal
scope failures. No actual geometric instance, experiment, private transcript, or
proof claim is included. A deliberate false/unsupported assertion with consistent
hashes remains matchable; every non-proof flag stays false. That test is essential
because rejecting only bad hashes could otherwise misleadingly suggest truth.

## Selection and reproduction

`SELECTION.json` is the explicit sorted file list. The manifest hashes that list and
every selected file; it excludes itself to avoid a hash cycle. The ZIP contains
exactly the selection plus the manifest. Fixed filenames, fixed 1980 timestamps,
fixed POSIX regular-file modes and ZIP_STORED avoid compressor-version dependence.
The archive digest and manifest digest are immutable selection identities, not
mathematical approval or protection against someone resealing a changed artifact.
No repository or published release is created.

```sh
python -B tools/package.py --output /tmp/hypothesis-scope-lab.zip
unzip /tmp/hypothesis-scope-lab.zip -d /tmp/hypothesis-scope-copy
cd /tmp/hypothesis-scope-copy
python -B tools/validate.py
```

`--seal` is an explicit author-only maintenance option that replaces the manifest
after intentional edits; ordinary validation and packaging never reseal. An
independent reviewer should use the supplied manifest/archive digests, not call
`--seal` before testing. The manifest does not include files outside the selected
artifact, and validation does not claim a filesystem security sandbox.

## Remaining work before any production integration

Review adequacy of each proposed mathematical rule and the exact correspondence of
its formal predicate fields to the intended objects. Add verifiers only with their
own precise mathematical contracts and independent tests. Design any ledger adapter
without accepting authored status or opaque artifact hashes as proof. Keep an
explicit boundary between syntactic applicability, checked arithmetic, reviewed
mathematical arguments and formal proof acceptance.
