# Existing Foundation Math boundary

The design was informed by the v0.12 architecture, its accepted exact-revision
claim ledger, and its fixed-character/split-bundle contracts. `BASELINE-PINS.json`
records the source manifest and relevant source-file digests used for that reading.
No code is imported from the release and no baseline files are runtime dependencies.

The release's fifteen tools, acceptance registry, calculators, proof bridge and
ledger implementation are unchanged. This lab has only a separate stdin CLI and a
small pure Python API. It is not a new accepted proof domain or release integration.
There are no actual research-instance computations, model calls or external services.

## Possible ledger use, not automatic integration

A caller can hash a serialized lab input or report and record that digest as an
opaque evidence artifact in the existing ledger. That ledger can record explicit
claim/obligation dependencies and replay its own exact revision pins, withdrawals
and stale references. A lab fact does not gain authority because such a ledger
record exists, and a no-blockers ledger replay does not verify the predicate.

Do not pass a ledger-authored `claimed_established` status off as a proved premise.
This lab deliberately has no ledger import, authored-status promotion, automatic
repinning, source fetch or acceptance hook. Its fact provenance is a recorded opaque
artifact digest, not a ledger record lookup. The generic pin shape is compatible
in shape only; identities from the two systems are not interchangeable.

Before a future integration, specify who supplies the authoritative current snapshot,
how exact ledger and artifact pins are bound, which lifecycle conditions block use,
which verifier establishes each predicate, and how mathematical rule adequacy is
reviewed. An unchecked statement should remain explicitly conditional even when both
syntactic scope matching and ledger dependency accounting succeed.

## Deliberately absent

No general theorem language, conclusion derivation, unification, symbolic geometry,
proof acceptance, Lean invocation, characterization by dimensions, inferred sheaf
isomorphisms, saturation algorithm, torsion calculation, or representation engine.
There is no weakening relation. These exclusions keep a narrow useful check honest.
