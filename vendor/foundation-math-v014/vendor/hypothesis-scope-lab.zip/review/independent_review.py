#!/usr/bin/env python3
"""Independent adversarial review. Usage: python -B FILE LAB_ROOT.

Records, pins, hashes, predicates and expected comparisons are constructed here,
without importing or invoking the lab's construction helpers. Only check(),
loads() and ScopeError are exercised from the implementation under review.
"""
import copy
import hashlib
import importlib
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
if len(sys.argv) < 2:
    raise SystemExit('Usage: python -B hypothesis-scope-independent-review.py LAB_ROOT')
ROOT = Path(sys.argv.pop(1)).resolve()
sys.path.insert(0, str(ROOT))
core = importlib.import_module('hypothesis_scope.core')
SCHEMA = 'foundation-math-hypothesis-scope/1'
CTX = hashlib.sha256(b'caller-authored universe A').hexdigest()
OTHER_CTX = hashlib.sha256(b'caller-authored universe B').hexdigest()
ARTIFACT = hashlib.sha256(b'artifact bytes not supplied to checker').hexdigest()
CATALOG = hashlib.sha256(b'caller physical catalog').hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def own_hash(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def record(rid, content, revision=1):
    body = {'id': rid, 'revision': revision, 'content': copy.deepcopy(content)}
    return {**body, 'revision_sha256': own_hash(body)}


def pin(value):
    return {key: value[key] for key in ('id', 'revision', 'revision_sha256')}


def reseal(value):
    return record(value['id'], value['content'], value['revision'])


def fixture():
    types = {
        'K': 'coherent_sheaf', 'E': 'coherent_sheaf', 'F': 'coherent_sheaf',
        'G': 'coherent_sheaf', 'I': 'coherent_sheaf', 'T': 'coherent_sheaf',
        'U': 'coherent_sheaf', 'Outside': 'coherent_sheaf',
        'Split': 'formal_splitting', 'Open': 'locus',
        'Rep': 'representation', 'RepOther': 'representation',
        'Vec': 'vector_space', 'VecOther': 'vector_space',
    }
    objects = {
        rid: record(rid, {'object_type': typ, 'context_sha256': CTX,
                         'description': 'Caller-authored ' + rid})
        for rid, typ in types.items()
    }
    arrows = {
        'incK': ('K', 'E'), 'incKOther': ('K', 'E'), 'incOutside': ('Outside', 'E'),
        'f': ('E', 'F'), 'fOther': ('E', 'F'), 'g': ('F', 'G'),
        'composite': ('E', 'G'), 'incI': ('I', 'F'),
        'embed': ('E', 'F'), 'embedOther': ('E', 'F'),
        'torsionIso': ('T', 'U'), 'torsionIsoOther': ('T', 'U'),
        'endoA': ('E', 'E'), 'endoB': ('E', 'E'),
        'repMap': ('Rep', 'RepOther'), 'vecMap': ('Vec', 'VecOther'),
    }
    maps = {
        rid: record(rid, {'source': pin(objects[src]), 'target': pin(objects[dst]),
                         'description': 'Caller-authored map ' + rid})
        for rid, (src, dst) in arrows.items()
    }
    return objects, maps


OBJECTS, MAPS = fixture()
O = {k: pin(v) for k, v in OBJECTS.items()}
M = {k: pin(v) for k, v in MAPS.items()}
PREDICATES = {
    'generic_sheaf_equality': {'kind': 'generic_sheaf_equality', 'left': O['E'], 'right': O['F'], 'locus': O['Open']},
    'coherent_sheaf_equality': {'kind': 'coherent_sheaf_equality', 'left': O['E'], 'right': O['F']},
    'selected_subkernel': {'kind': 'selected_subkernel', 'kernel': O['K'], 'inclusion': M['incK'], 'of_map': M['f']},
    'full_kernel': {'kind': 'full_kernel', 'kernel': O['K'], 'inclusion': M['incK'], 'of_map': M['f']},
    'abstract_splitting': {'kind': 'abstract_splitting', 'object': O['E'], 'splitting': O['Split']},
    'embedded_splitting': {'kind': 'embedded_splitting', 'object': O['E'], 'splitting': O['Split'], 'inclusion': M['embed']},
    'coherent_image': {'kind': 'coherent_image', 'image': O['I'], 'inclusion': M['incI'], 'of_map': M['f']},
    'saturated_image': {'kind': 'saturated_image', 'image': O['I'], 'inclusion': M['incI'], 'of_map': M['f']},
    'physical_representation': {'kind': 'physical_representation', 'object': O['Rep'], 'catalog_sha256': CATALOG, 'label': 'W'},
    'object_rank': {'kind': 'object_rank', 'object': O['E'], 'value': 2},
    'object_dimension': {'kind': 'object_dimension', 'object': O['Rep'], 'value': 2},
    'map_rank': {'kind': 'map_rank', 'map': M['f'], 'value': 2},
    'map_injective': {'kind': 'map_injective', 'map': M['f']},
    'map_zero': {'kind': 'map_zero', 'map': M['f']},
    'constant_vanishing': {'kind': 'constant_vanishing', 'constants': O['K'], 'inclusion': M['incK'], 'path': [M['f'], M['g']]},
    'torsion_identification': {'kind': 'torsion_identification', 'role': 'original', 'torsion': O['T'], 'of_map': M['f'], 'identified_with': O['U'], 'identification': M['torsionIso']},
    'object_identity': {'kind': 'object_identity', 'left': O['E'], 'right': O['F']},
    'map_identity': {'kind': 'map_identity', 'left': M['f'], 'right': M['fOther']},
}


def document(required=None, supplied=None):
    if required is None:
        required = PREDICATES['map_zero']
    if supplied is None:
        supplied = required
    fact = record('Fact', {'predicate': supplied, 'availability': 'supplied',
                           'provenance': {'artifact_sha256': ARTIFACT,
                                          'description': 'Unverified caller artifact'}})
    rule = record('Rule', {'purpose': 'Caller-authored applicability, not theorem acceptance',
                           'requirements': [{'id': 'Need', 'predicate': required}]})
    return copy.deepcopy({'schema': SCHEMA, 'objects': list(OBJECTS.values()),
                          'maps': list(MAPS.values()), 'facts': [fact], 'rule': rule,
                          'application': {'rule': pin(rule),
                                          'bindings': [{'requirement_id': 'Need', 'fact': pin(fact)}]}})


def changed(pred, **kwargs):
    return {**copy.deepcopy(pred), **copy.deepcopy(kwargs)}


class IndependentReview(unittest.TestCase):
    def assert_boundary(self, result):
        self.assertEqual(result['semantics'], 'exact_authored_premise_matching_only')
        for flag in ('fact_truth_checked', 'rule_soundness_checked', 'geometry_checked',
                     'runtime_acceptance', 'lean_proof'):
            self.assertIs(result[flag], False, flag)
        self.assertEqual(set(result), {
            'schema', 'input_sha256', 'rule', 'current_rule', 'all_requirements_matched',
            'requirements', 'semantics', 'fact_truth_checked', 'rule_soundness_checked',
            'geometry_checked', 'runtime_acceptance', 'lean_proof'})

    def assert_match(self, d, expected=True, code=None):
        before = copy.deepcopy(d)
        result = core.check(d)
        self.assertEqual(d, before, 'Checker mutated the caller document')
        self.assertIs(result['all_requirements_matched'], expected)
        self.assert_boundary(result)
        if code:
            self.assertEqual(result['requirements'][0]['status'], code)
        return result

    def assert_reject(self, d, code=None):
        with self.assertRaises(core.ScopeError) as caught:
            core.check(d)
        if code:
            self.assertEqual(caught.exception.code, code)
        self.assertIs(type(caught.exception.path), str)

    def test_01_all_18_predicates_match_only_exact_authored_requirement(self):
        self.assertEqual(len(PREDICATES), 18)
        for required_name, required in PREDICATES.items():
            for supplied_name, supplied in PREDICATES.items():
                with self.subTest(required=required_name, supplied=supplied_name):
                    expected = required == supplied  # Independent literal oracle.
                    self.assert_match(document(required, supplied), expected,
                                      'exact_match' if expected else 'predicate_mismatch')

    def test_02_scopes_are_not_weakened(self):
        for first, second in (
            ('generic_sheaf_equality', 'coherent_sheaf_equality'),
            ('selected_subkernel', 'full_kernel'),
            ('abstract_splitting', 'embedded_splitting'),
            ('coherent_image', 'saturated_image'),
            ('object_rank', 'object_identity'),
            ('object_dimension', 'object_identity'),
            ('map_rank', 'map_identity'),
            ('map_injective', 'map_identity'),
            ('map_zero', 'constant_vanishing'),
        ):
            for required, supplied in ((first, second), (second, first)):
                with self.subTest(required=required, supplied=supplied):
                    self.assert_match(document(PREDICATES[required], PREDICATES[supplied]),
                                      False, 'predicate_mismatch')

    def test_03_same_kind_object_map_and_endpoint_substitutions(self):
        swaps = [
            ('coherent_sheaf_equality', {'left': O['G']}),
            ('generic_sheaf_equality', {'right': O['G']}),
            ('selected_subkernel', {'inclusion': M['incKOther']}),
            ('full_kernel', {'of_map': M['fOther']}),
            ('embedded_splitting', {'inclusion': M['embedOther']}),
            ('coherent_image', {'of_map': M['fOther']}),
            ('saturated_image', {'of_map': M['fOther']}),
            ('object_rank', {'object': O['F']}),
            ('object_dimension', {'object': O['RepOther']}),
            ('map_rank', {'map': M['fOther']}),
            ('map_zero', {'map': M['fOther']}),
            ('map_injective', {'map': M['fOther']}),
            ('object_identity', {'left': O['F'], 'right': O['E']}),
            ('map_identity', {'left': M['fOther'], 'right': M['f']}),
        ]
        for name, fields in swaps:
            with self.subTest(predicate=name, fields=fields):
                required = PREDICATES[name]
                self.assert_match(document(required, changed(required, **fields)),
                                  False, 'predicate_mismatch')

    def test_04_physical_labels_and_catalogs_are_literal(self):
        base = PREDICATES['physical_representation']
        labels = ('1', 'W', 'A', 'S4', 'D', 'T6', 'P', 'Wp', 'V')
        for required in labels:
            for supplied in labels:
                self.assert_match(document(changed(base, label=required),
                                           changed(base, label=supplied)),
                                  required == supplied,
                                  'exact_match' if required == supplied else 'predicate_mismatch')
        for fields in ({'object': O['RepOther']}, {'catalog_sha256': '0' * 64}):
            self.assert_match(document(base, changed(base, **fields)), False, 'predicate_mismatch')
        for label in ('W_prime', "W'", 'w', 'W ', 'WP', 'a', 'v', 'unknown'):
            self.assert_reject(document(base, changed(base, label=label)), 'malformed_type')

    def test_05_two_step_is_not_one_step_or_a_composite(self):
        base = PREDICATES['constant_vanishing']
        for one in (changed(base, path=[M['f']]),
                    changed(base, path=[M['g']], constants=O['I'], inclusion=M['incI']),
                    changed(base, path=[M['composite']])):
            self.assert_match(document(base, one), False, 'predicate_mismatch')
            self.assert_match(document(one, base), False, 'predicate_mismatch')
        self.assert_match(document(changed(base, path=[M['endoA'], M['endoB']]),
                                   changed(base, path=[M['endoB'], M['endoA']])),
                          False, 'predicate_mismatch')
        self.assert_reject(document(changed(base, path=[M['g'], M['f']])), 'map_endpoint')
        for fields in ({'inclusion': M['incKOther']},
                       {'constants': O['Outside'], 'inclusion': M['incOutside']}):
            self.assert_match(document(base, changed(base, **fields)), False, 'predicate_mismatch')
        self.assert_reject(document(changed(base, constants=O['E'])), 'map_endpoint')
        self.assert_reject(document(changed(base, inclusion=M['incI'], constants=O['I'])), 'map_endpoint')
        missing = copy.deepcopy(base)
        del missing['constants']
        self.assert_reject(document(missing), 'fields')
        for path in ([], [M['endoA']] * 5):
            self.assert_reject(document(changed(base, path=path)), 'budget_exceeded')

    def test_06_torsion_role_and_origin_are_not_interchangeable(self):
        base = PREDICATES['torsion_identification']
        for fields in ({'role': 'induced'}, {'of_map': M['fOther']},
                       {'of_map': M['g']}, {'identification': M['torsionIsoOther']}):
            other = changed(base, **fields)
            self.assert_match(document(base, other), False, 'predicate_mismatch')
            self.assert_match(document(other, base), False, 'predicate_mismatch')
        self.assert_reject(document(changed(base, role='original_or_induced')), 'malformed_type')
        self.assert_reject(document(changed(base, of_map=M['vecMap'])), 'object_type')
        self.assert_reject(document(changed(base, torsion=O['E'])), 'map_endpoint')
        self.assert_reject(document(changed(base, identified_with=O['F'])), 'map_endpoint')

    def test_07_missing_and_swapped_provenance(self):
        for which in ('all', 'artifact_sha256', 'description'):
            d = document()
            if which == 'all':
                del d['facts'][0]['content']['provenance']
            else:
                del d['facts'][0]['content']['provenance'][which]
            d['facts'][0] = reseal(d['facts'][0])
            d['application']['bindings'][0]['fact'] = pin(d['facts'][0])
            self.assert_reject(d, 'fields')
        for field, value in (('artifact_sha256', 'not-a-hash'), ('description', '  ')):
            d = document()
            d['facts'][0]['content']['provenance'][field] = value
            d['facts'][0] = reseal(d['facts'][0])
            self.assert_reject(d, 'malformed_type')
        for field, value in (('artifact_sha256', '0' * 64), ('description', 'Different source')):
            d = document()
            d['facts'][0]['content']['provenance'][field] = value
            self.assert_reject(d, 'record_hash_mismatch')
            d['facts'][0] = reseal(d['facts'][0])
            self.assert_match(d, False, 'fact_pin_not_current')
            d['application']['bindings'][0]['fact'] = pin(d['facts'][0])
            self.assert_match(d, True, 'exact_match')  # Opaque provenance is not authenticated.

    def test_08_identical_predicate_does_not_substitute_a_different_fact_pin(self):
        d = document()
        old = d['facts'][0]
        d['facts'][0] = record('OtherFact', old['content'])
        self.assert_match(d, False, 'fact_not_supplied')
        d['application']['bindings'][0]['fact'] = pin(d['facts'][0])
        self.assert_match(d, True, 'exact_match')

    def test_09_stale_object_and_map_pins_reject_whole_snapshot(self):
        d = document()
        for i, obj in enumerate(d['objects']):
            if obj['id'] == 'E':
                d['objects'][i] = record('E', obj['content'], revision=2)
        self.assert_reject(d, 'pin_mismatch')
        d = document()
        for i, arrow in enumerate(d['maps']):
            if arrow['id'] == 'f':
                d['maps'][i] = record('f', arrow['content'], revision=2)
        self.assert_reject(d, 'pin_mismatch')

    def test_10_stale_fact_and_rule_pins_block(self):
        d = document()
        d['facts'][0] = record('Fact', d['facts'][0]['content'], revision=2)
        self.assert_match(d, False, 'fact_pin_not_current')
        d = document()
        d['rule'] = record('Rule', d['rule']['content'], revision=2)
        self.assert_match(d, False, 'rule_pin_not_current')
        d = document()
        d['application']['rule']['id'] = 'DifferentRule'
        self.assert_match(d, False, 'rule_pin_not_current')
        d = document()
        d['application']['bindings'][0]['fact']['revision_sha256'] = '0' * 64
        self.assert_match(d, False, 'fact_pin_not_current')

    def test_11_missing_binding_fact_and_withdrawal(self):
        d = document()
        d['application']['bindings'] = []
        self.assert_match(d, False, 'missing_binding')
        d = document()
        d['facts'] = []
        self.assert_match(d, False, 'fact_not_supplied')
        d = document()
        d['facts'][0]['content']['availability'] = 'withdrawn'
        d['facts'][0] = reseal(d['facts'][0])
        d['application']['bindings'][0]['fact'] = pin(d['facts'][0])
        self.assert_match(d, False, 'fact_withdrawn')

    def test_12_no_author_success_status_or_predicate_escape_hatch(self):
        d = document()
        d['facts'][0]['content']['claimed_established'] = True
        d['facts'][0] = reseal(d['facts'][0])
        self.assert_reject(d, 'fields')
        for status in ('accepted', 'proved', 'verified', 'claimed_established'):
            d = document()
            d['facts'][0]['content']['availability'] = status
            d['facts'][0] = reseal(d['facts'][0])
            self.assert_reject(d, 'malformed_type')
        for name in ('equivalent', 'compatible', 'anything', 'formal_proof'):
            self.assert_reject(document({'kind': name}), 'predicate_kind')
        d = document(changed(PREDICATES['map_zero'], trust_me=True))
        self.assert_reject(d, 'fields')

    def test_13_false_assertions_can_match_but_are_never_verified(self):
        # The checker has no mathematical semantics for these descriptions.
        d = document(PREDICATES['map_zero'])
        for i, arrow in enumerate(d['maps']):
            if arrow['id'] == 'f':
                arrow['content']['description'] = 'Identity map on a nonzero space, asserted zero anyway'
                d['maps'][i] = reseal(arrow)
                new_pin = pin(d['maps'][i])
        d['facts'][0]['content']['predicate']['map'] = new_pin
        d['facts'][0]['content']['provenance']['description'] = 'Not checked; potentially false'
        d['facts'][0] = reseal(d['facts'][0])
        d['rule']['content']['requirements'][0]['predicate']['map'] = new_pin
        d['rule'] = reseal(d['rule'])
        d['application']['rule'] = pin(d['rule'])
        d['application']['bindings'][0]['fact'] = pin(d['facts'][0])
        self.assert_match(d, True, 'exact_match')

    def test_14_context_and_endpoint_mismatch(self):
        d = document(changed(PREDICATES['coherent_sheaf_equality'], right=O['Outside']))
        for i, item in enumerate(d['objects']):
            if item['id'] == 'Outside':
                item['content']['context_sha256'] = OTHER_CTX
                d['objects'][i] = reseal(item)
                new_pin = pin(d['objects'][i])
        for i, arrow in enumerate(d['maps']):
            if arrow['id'] == 'incOutside':
                d['maps'].pop(i)
                break
        d['facts'][0]['content']['predicate']['right'] = new_pin
        d['facts'][0] = reseal(d['facts'][0])
        d['rule']['content']['requirements'][0]['predicate']['right'] = new_pin
        d['rule'] = reseal(d['rule'])
        d['application']['rule'] = pin(d['rule'])
        d['application']['bindings'][0]['fact'] = pin(d['facts'][0])
        self.assert_reject(d, 'context_mismatch')
        for kind, fields in (
            ('full_kernel', {'kernel': O['E']}),
            ('selected_subkernel', {'of_map': M['g']}),
            ('coherent_image', {'image': O['E']}),
            ('saturated_image', {'of_map': M['g']}),
            ('embedded_splitting', {'object': O['F']}),
            ('map_identity', {'right': M['g']}),
        ):
            self.assert_reject(document(changed(PREDICATES[kind], **fields)), 'map_endpoint')
        self.assert_reject(document(changed(PREDICATES['object_rank'], object=O['Rep'])), 'object_type')
        self.assert_reject(document(changed(PREDICATES['object_identity'], right=O['Rep'])), 'object_type')

    def test_15_strict_hashes_fields_types_and_namespaces(self):
        for collection in ('objects', 'maps', 'facts'):
            d = document()
            d[collection][0]['revision_sha256'] = '0' * 64
            self.assert_reject(d, 'record_hash_mismatch')
        d = document()
        d['objects'][0]['revision_sha256'] = 'A' * 64
        self.assert_reject(d, 'malformed_type')
        d = document()
        d['unexpected'] = None
        self.assert_reject(d, 'fields')
        for value in (True, 1.0, -1, 1000001):
            self.assert_reject(document(changed(PREDICATES['object_rank'], value=value)), 'malformed_type')
        for revision in (True, 0, 1.0):
            d = document()
            d['facts'][0]['revision'] = revision
            d['facts'][0] = reseal(d['facts'][0])
            self.assert_reject(d, 'malformed_type')
        class DictSubclass(dict):
            pass
        self.assert_reject(DictSubclass(document()), 'malformed_type')
        d = document()
        d['objects'].append(copy.deepcopy(d['objects'][0]))
        self.assert_reject(d, 'duplicate_id')
        d = document()
        d['maps'][0] = record(d['objects'][0]['id'], d['maps'][0]['content'])
        self.assert_reject(d, 'duplicate_id')
        wrong = changed(PREDICATES['map_zero'], map=O['E'])
        self.assert_reject(document(wrong), 'missing_reference')
        wrong = changed(PREDICATES['object_rank'], object=M['f'])
        self.assert_reject(document(wrong), 'missing_reference')

    def test_16_binding_and_requirement_closure(self):
        d = document()
        d['application']['bindings'].append(copy.deepcopy(d['application']['bindings'][0]))
        self.assert_reject(d, 'duplicate_binding')
        d = document()
        d['application']['bindings'][0]['requirement_id'] = 'Unknown'
        self.assert_reject(d, 'unknown_requirement')
        d = document()
        d['rule']['content']['requirements'].append(copy.deepcopy(d['rule']['content']['requirements'][0]))
        d['rule'] = reseal(d['rule'])
        self.assert_reject(d, 'duplicate_requirement')
        d = document()
        d['rule']['content']['requirements'] = []
        d['rule'] = reseal(d['rule'])
        self.assert_reject(d, 'budget_exceeded')
        d = document()
        d['application']['bindings'][0]['fact'] = {'id': 'Fact'}
        self.assert_reject(d, 'fields')

    def test_17_strict_json_loads(self):
        d = document()
        self.assertEqual(core.loads(canonical(d)), d)
        for raw, code in (
            ('{"x":1,"x":2}', 'duplicate_key'),
            ('{"x":1.0}', 'malformed_type'),
            ('{"x":NaN}', 'malformed_type'),
            ('{"x":Infinity}', 'malformed_type'),
            ('{"x":-Infinity}', 'malformed_type'),
            ('{"x":"\\ud800"}', 'malformed_type'),
            ('{"x":99999999999999999999999999999}', 'budget_exceeded'),
            (b'\xff', 'malformed_json'),
        ):
            with self.subTest(raw=raw):
                with self.assertRaises(core.ScopeError) as caught:
                    core.loads(raw)
                self.assertEqual(caught.exception.code, code)

    def test_18_order_normalization_determinism_and_independent_input_hash(self):
        d = document()
        result = self.assert_match(d)
        normalized = copy.deepcopy(d)
        for collection in ('objects', 'maps', 'facts'):
            normalized[collection].sort(key=lambda x: x['id'])
        normalized['application']['bindings'].sort(key=lambda x: x['requirement_id'])
        self.assertEqual(result['input_sha256'], own_hash(normalized))
        d['objects'].reverse()
        d['maps'].reverse()
        self.assertEqual(core.check(d), result)
        self.assertEqual(core.check(copy.deepcopy(d)), result)

    def test_19_report_retains_exact_requested_and_bound_pins(self):
        d = document()
        result = self.assert_match(d)
        self.assertEqual(result['rule'], pin(d['rule']))
        self.assertEqual(result['current_rule'], pin(d['rule']))
        requirement = result['requirements'][0]
        self.assertEqual(requirement['required_predicate'], d['rule']['content']['requirements'][0]['predicate'])
        self.assertEqual(requirement['bound_fact'], pin(d['facts'][0]))
        self.assertEqual(requirement['current_fact'], pin(d['facts'][0]))
        d['facts'][0] = record('Fact', d['facts'][0]['content'], 2)
        result = self.assert_match(d, False, 'fact_pin_not_current')
        self.assertNotEqual(result['requirements'][0]['bound_fact'], result['requirements'][0]['current_fact'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
