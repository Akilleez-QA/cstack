#!/usr/bin/env python3
"""Replay selected-only archive with no sibling tree or installed dependencies."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from build_release import ROOT,MANIFEST,create_zip,verify_manifest

def execute(root,script,optimized):
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='',SPLIT_REVIEW_ROOT=str(root))
    p=subprocess.run([sys.executable,*(['-O'] if optimized else []),str(root/script)],cwd='/tmp',env=env,capture_output=True,text=True,timeout=240)
    if p.returncode:raise RuntimeError(script+' failed: '+p.stderr+p.stdout)
    obj=json.loads(p.stdout)
    if obj.get('status')!='PASS':raise RuntimeError('Non-PASS replay')
    return obj

def normalized(obj):return {k:v for k,v in obj.items() if k!='python_optimized'}
def main():
    verify_manifest();runs={}
    for script in ('run_tests.py','review/review_checks.py','review/adversarial_controls.py'):
        a=execute(ROOT,script,False);b=execute(ROOT,script,True)
        if normalized(a)!=normalized(b):raise RuntimeError('Normal/-O mismatch '+script)
        runs[script]=normalized(a)
    verify_manifest()
    with tempfile.TemporaryDirectory(prefix='formal-split-replay-') as td:
        td=Path(td);z1,z2=td/'one.zip',td/'two.zip';receipt=create_zip(z1);create_zip(z2)
        if z1.read_bytes()!=z2.read_bytes():raise RuntimeError('Archive not byte reproducible')
        clean=td/'isolated';clean.mkdir()
        with zipfile.ZipFile(z1) as z:
            names=[r['path'] for r in verify_manifest()['files']]+[MANIFEST]
            if sorted(z.namelist())!=sorted(names):raise RuntimeError('Archive membership differs from manifest')
            z.extractall(clean)
        verify_manifest(clean)
        for script in runs:
            for opt in (False,True):
                out=normalized(execute(clean,script,opt))
                if out!=runs[script]:raise RuntimeError('Selected-only replay mismatch '+script)
        verify_manifest(clean);create_zip(td/'isolated.zip',clean)
        if (td/'isolated.zip').read_bytes()!=z1.read_bytes():raise RuntimeError('Selected-only ZIP rebuild differs')
    out={'status':'PASS','author_checks_per_mode':runs['run_tests.py']['checks'],'independent_checks_per_mode':runs['review/review_checks.py']['total'],'source_fault_cases':runs['review/adversarial_controls.py']['mutation_cases'],'source_fault_internal_runs_per_replay':runs['review/adversarial_controls.py']['runs'],'modes':['normal','optimized','isolated-normal','isolated-optimized'],'manifest_only_membership':True,'sibling_tree_required':False,'zip_byte_reproducible':True,'archive':receipt,'scope':'formal arithmetic only; no runtime acceptance, Lean proof or geometric realization'}
    print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':main()
