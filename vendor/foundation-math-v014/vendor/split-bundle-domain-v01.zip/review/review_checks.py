#!/usr/bin/env python3
"""Black-box formal-domain checks; author files are read/imported only."""
import ast, copy, hashlib, importlib, json, os, random, subprocess, sys, time
from collections import Counter
from pathlib import Path
REVIEW=Path(__file__).resolve().parent
ROOT=Path(os.environ.get('SPLIT_REVIEW_ROOT',str(REVIEW.parent))).resolve()
sys.path.insert(0,str(REVIEW));sys.path.insert(0,str(ROOT))
from independent_oracle import LABELS,DIMS,SIGNS,CH,ZERO,unit,sumv,sym,decomp,tensor,split,hom,dimension,character,self_check,CATALOG_SHA,mul
from split_bundle.producer import calculate
from split_bundle.verifier import verify
from split_bundle.contract import load_json,data_guard,parse_request
from split_bundle.verifier import guarded_wire,validate_request
REVIEWED_SOURCE_SHA256='3d6a775d8e92777a0614921adf23d26516d34d8312607d58040a126030b1962b'
COUNTS=Counter()

def need(ok,label,category='positive'):
    COUNTS[category]+=1
    if not ok:raise RuntimeError(label)
def reject(f,label,code=None):
    try:f()
    except ValueError as e:
        need(getattr(e,'code',None) is not None,label+' unstructured '+repr(e),'negative')
        if code:need(e.code==code,label+' wrong code '+e.code,'negative')
    else:raise RuntimeError(label+' accepted')
def block(label,a,n=1):return {'irrep':label,'twist':a,'multiplicity':n}
def triples(bs):return [(b['irrep'],b['twist'],b['multiplicity']) for b in bs]
def req(bs,ts):return {'schema':'fm-split-bundle-request-v1','operation':'cohomology','bundle':bs,'twists':ts}
def hreq(a,b):return {'schema':'fm-split-bundle-request-v1','operation':'hom','source':a,'target':b}
def check_character(actual,vector,label):
    v=list(vector);chars=[[a.numerator,a.denominator,b.numerator,b.denominator] for a,b in character(v)]
    parity={SIGNS[i] for i,n in enumerate(v) if n}
    expected={'multiplicities':v,'dimension':dimension(v),'classification':'genuine' if min(v)>=0 else 'proper_virtual','center_parity':'zero' if not parity else 'even' if parity=={1} else 'odd' if parity=={-1} else 'mixed','even_dimension':sum(DIMS[i]*v[i] for i in range(9) if SIGNS[i]==1),'odd_dimension':sum(DIMS[i]*v[i] for i in range(9) if SIGNS[i]==-1),'negative_multiplicities':{l:n for l,n in zip(LABELS,v) if n<0},'class_values':chars}
    need(actual==expected,label,'oracle')
def check_cohom(bs,ts,label):
    r=req(bs,ts);c=calculate(r);v=verify(r,c)
    need(v['status']=='verified_arithmetic' and v['result']==c['result'],label+' verified','oracle')
    need(v['runtime_acceptance'] is False and v['lean_proof'] is False and v['geometric_realization'] is False,label+' scope','scope')
    for t,row in zip(ts,c['result']['twists']):
        o=split(triples(bs),t)
        need(row['twist']==t and row['rank']==o['rank'] and row['degree']==o['degree']+t*o['rank'],label+' stats','oracle')
        need(c['result']['bundle']=={k:o[k] for k in ('rank','degree')},label+' base stats','oracle')
        for key in ('h0','h1','euler'):check_character(row[key],o[key],label+key)
        need(dimension(o['euler'])==o['rank']*(t+1)+o['degree'],label+' RR','structural')
        need(all(x>=0 for x in o['h0']+o['h1']),label+' genuine cohomology','structural')
    return c

def main():
    source=(REVIEW/'REVIEWED-SOURCE.json').read_bytes()
    need(hashlib.sha256(source).hexdigest()==REVIEWED_SOURCE_SHA256,'reviewed source record binding','integrity')
    for entry in json.loads(source)['files']:
        raw=(ROOT/entry['path']).read_bytes()
        need(len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],'reviewed source '+entry['path'],'integrity')
    need(self_check()==370,'oracle baseline','oracle')
    raw=(ROOT/'character_ring/catalog.json').read_bytes()
    need(hashlib.sha256(raw).hexdigest()==CATALOG_SHA,'frozen catalog digest','integrity')
    # Every shifted degree from -128 through 128, for each physical irrep.
    for l in LABELS:
        for a in (-64,64):
            for start in range(-64,65,32):
                ts=list(range(start,min(65,start+32)))
                check_cohom([block(l,a)],ts,l+str(a)+str(start))
    print(json.dumps({'stage':'all_irreps_all_shifted_degrees','counts':dict(COUNTS)}),file=sys.stderr,flush=True)
    check_cohom([],[-64,-2,-1,0,1,64],'empty')
    check_cohom([block('T6',64,0)],[-64,0,64],'zero multiplicity')
    critical=check_cohom([block('1',-10),block('1',-8),block('V',-8)],[8],'genuine Euler trap')
    need(critical['result']['twists'][0]['h1']['multiplicities']==list(unit('1')),'nonzero H1 with genuine Euler','critical')
    for start in range(-64,65,32):
        ts=list(range(start,min(65,start+32)))
        f=check_cohom([block('1',0),block('1',-2)],ts,'Euler collision split')
        g=check_cohom([block('W',-1)],ts,'Euler collision W')
        for x,y in zip(f['result']['twists'],g['result']['twists']):need(x['euler']==y['euler'],'Euler collision all admitted twists','critical')
    rng=random.Random(20261024)
    for k in range(24):
        bs=[block(rng.choice(LABELS),rng.randrange(-12,13),rng.randrange(0,11)) for _ in range(rng.randrange(0,17))]
        ts=rng.sample(range(-16,17),8)
        check_cohom(bs,ts,'seeded sum '+str(k))
        # Serre duality for supplied split objects, without any map or rank computation.
        dual=[block(b['irrep'],-b['twist']-2,b['multiplicity']) for b in bs]
        for t in ts:need(split(triples(bs),t)['h1']==split(triples(dual),-t)['h0'],'Serre duality','structural')
    check_cohom([block('T6',64,1000000)]*32,list(range(33,65)),'all request maxima')
    # All irreducible Hom pairs; negative degree, constants, low degrees, and maximum degree.
    for u in LABELS:
        for v in LABELS:
            for d in (-1,0,1,2,6,128):
                a=-64 if d==128 else 0;b=64 if d==128 else d
                source=[block(u,a)];target=[block(v,b)]
                r=hreq(source,target);c=calculate(r);vv=verify(r,c)
                need(c['result']['equivariant_hom_dimension']==hom(triples(source),triples(target)),'Hom '+u+v+str(d),'oracle')
                expect=ZERO if d<0 else decomp(tuple(mul(mul(x,y),z) for x,y,z in zip(CH[u],CH[v],sym(d))))
                check_character(c['result']['hom_character'],expect,'Hom character')
                need(vv['result']==c['result'],'Hom verified','oracle')
    h=calculate(hreq([block('W',-3)],[block('W',-3)]))
    need(h['result']['equivariant_hom_dimension']==1,'Hom dimension one','critical')
    need(h['result']['conclusion']=='dimension_of_equivariant_map_space_only_no_map_rank_or_embedding_claim','no map rank claim','scope')
    for source,target in [([],[]),([],[block('W',0)]),([block('W',0)],[]),([block('T6',-64,1000000)]*32,[block('T6',64,1000000)]*32)]:
        r=hreq(source,target);c=calculate(r)
        need(c['result']['equivariant_hom_dimension']==hom(triples(source),triples(target)),'Hom bounds','oracle');verify(r,c)
    print(json.dumps({'stage':'cohomology_and_hom_oracles','counts':dict(COUNTS)}),file=sys.stderr,flush=True)
    good=req([block('W',0)],[0]);cert=calculate(good)
    # Request binding is structural, not only result binding.
    collisions=[req([block('W',0,0),block('W',0)],[0]),req([block('W',0)],[1]),req([block('Wp',0)],[0])]
    for r in collisions:reject(lambda r=r:verify(r,cert),'external request replay')
    reordered=req([block('1',0),block('W',0)],[0,1]);cc=calculate(reordered)
    rr=copy.deepcopy(reordered);rr['bundle'].reverse();reject(lambda:verify(rr,cc),'block order binds')
    rr=copy.deepcopy(reordered);rr['twists'].reverse();reject(lambda:verify(rr,cc),'twist order binds')
    # Every scalar/container leaf in a nontrivial certificate is tamper-tested.
    c=critical
    def leaves(x,path=()):
        if type(x) is dict:
            for k,v in x.items():yield from leaves(v,path+(k,))
        elif type(x) is list:
            for i,v in enumerate(x):yield from leaves(v,path+(i,))
        else:yield path,x
    for path,value in leaves(c):
        m=copy.deepcopy(c);p=m
        for k in path[:-1]:p=p[k]
        p[path[-1]]=value+1 if type(value) is int else value+'!' if type(value) is str else 1
        reject(lambda m=m:verify(c['request'],m),'certificate leaf '+repr(path))
    for key in c:
        m=copy.deepcopy(c);del m[key];reject(lambda m=m:verify(c['request'],m),'missing cert key '+key)
    m=copy.deepcopy(c);m['rank_one']=1;reject(lambda:verify(c['request'],m),'extra rank claim')
    # Malformed input types and prohibited negative blocks.
    bad=[]
    for field,val in [('schema','bad'),('operation','map_rank'),('operation',None),('bundle',{}),('twists',[]),('twists',[0,0]),('twists',list(range(33))),('twists',[65]),('twists',[-65]),('twists',[True]),('twists',[1.0])]:
        r=copy.deepcopy(good);r[field]=val;bad.append(r)
    for field,vals in [('irrep',['A3','S3','w','WP',None,0]),('twist',[-65,65,True,1.0,'1',None]),('multiplicity',[-1,1000001,True,1.0,'1',None])]:
        for value in vals:
            r=copy.deepcopy(good);r['bundle'][0][field]=value;bad.append(r)
    for key in good:
        r=copy.deepcopy(good);del r[key];bad.append(r)
    r=copy.deepcopy(good);r['bundle']*=33;bad.append(r)
    r=copy.deepcopy(good);r['assumed_actual_hm_bundle']=1;bad.append(r)
    r=copy.deepcopy(good);r['bundle'][0]['rank']=2;bad.append(r)
    bad.extend([None,False,[],1,'request'])
    class D(dict):pass
    class L(list):pass
    class S(str):pass
    class I(int):pass
    bad.extend([D(good),dict(good,bundle=L(good['bundle'])),dict(good,schema=S(good['schema'])),req([dict(block('W',0),multiplicity=I(1))],[0])])
    for r in bad:
        reject(lambda r=r:calculate(r),'invalid producer request')
        reject(lambda r=r:verify(r,cert),'invalid checker request')
    for m in [None,False,[],1,'certificate',D(cert),dict(cert,result=D(cert['result'])),dict(cert,scope=S(cert['scope']))]:reject(lambda m=m:verify(good,m),'invalid certificate type')
    cycle={};cycle['x']=cycle
    for guard in (lambda x:data_guard(x,65536),lambda x:guarded_wire(x,65536)):
        reject(lambda:guard(cycle),'cyclic data')
        reject(lambda:guard({'x':'x'*257}),'over string length')
        reject(lambda:guard({'x':1<<300}),'over integer bit boundary')
        need(guard({'x':(1<<300)-1}) is not None,'integer boundary','boundary')
        need(guard({'x':'x'*256}) is not None,'string boundary','boundary')
        v=None
        for _ in range(15):v=[v]
        need(guard(v) is not None,'depth16 boundary','boundary');reject(lambda:guard([v]),'depth17')
        need(guard([None]*8191) is not None,'values8192 boundary','boundary');reject(lambda:guard([None]*8192),'values8193')
    for raw in [b'{"a":1,"a":2}',b'1.0',b'NaN',b'Infinity',b'\xff',b'{',b'1'*91,b'['*1100+b']'*1100]:reject(lambda raw=raw:load_json(raw,65536),'invalid wire')
    reject(lambda:load_json(b' '*65537,65536),'raw byte overflow')
    need(load_json(b'0'+b' '*65535,65536)==0,'raw byte exact bound','boundary')
    # A quote/escape-aware depth scan must run before the general JSON backend.
    for value in ['['*256,']'*256,'{'*256,'}'*256,'\\'*120+'"[]{}','"'*120]:
        raw=json.dumps(value).encode('ascii')
        need(load_json(raw,65536)==value,'quoted structural bytes','encoding')
    v=[]
    for _ in range(15):v=[v]
    need(load_json(json.dumps(v).encode(),65536)==v,'raw sixteen container boundary','boundary')
    reject(lambda:load_json(json.dumps([v]).encode(),65536),'raw seventeen containers')
    ingress=importlib.import_module('split_bundle.contract');original=ingress._load_json
    def forbidden_backend(*args):raise RuntimeError('JSON parser reached before nesting rejection')
    ingress._load_json=forbidden_backend
    try:reject(lambda:ingress.load_json(b'['*17+b']'*17,65536),'depth rejected before JSON backend','E_BUDGET')
    finally:ingress._load_json=original
    detached=req([block('V',0,2)],[0]);dc=calculate(detached);detached['bundle'][0]['multiplicity']=3
    need(dc['request']['bundle'][0]['multiplicity']==2,'certificate request detached','binding')
    # Strict producer/checker import separation.
    modules=[]
    for node in ast.walk(ast.parse((ROOT/'split_bundle/verifier.py').read_text())):
        if isinstance(node,ast.Import):modules.extend(x.name for x in node.names)
        if isinstance(node,ast.ImportFrom):modules.append(node.module or '')
    need(not any('producer' in x or x.endswith('contract') for x in modules),'checker does not import producer or contracts','separation')
    print(json.dumps({'status':'PASS','counts':dict(COUNTS),'total':sum(COUNTS.values()),'python_optimized':not __debug__,'catalog_sha256':CATALOG_SHA,'scope':'Universal formal split-bundle arithmetic, no actual geometric instances or Lean proof.'},sort_keys=True),flush=True)
if __name__=='__main__':main()
