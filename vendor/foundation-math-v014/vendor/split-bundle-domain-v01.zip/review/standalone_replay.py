#!/usr/bin/env python3
"""Independent manifest-only reproduction. Writes only review-owned temporary copies.

Run from delivered lab/review, or set SPLIT_REVIEW_ROOT to the reviewed lab.
The final JSON report goes to stdout and is not part of the archive it audits.
"""
from pathlib import Path,PurePosixPath
import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
REVIEW=Path(__file__).resolve().parent
ROOT=Path(os.environ.get('SPLIT_REVIEW_ROOT',str(REVIEW.parent))).resolve()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,label):
    if not ok:raise RuntimeError(label)
def inspect(root):
    select=json.loads((root/'RELEASE-FILES.json').read_text());manifest=json.loads((root/'ARTIFACT-MANIFEST.json').read_text())
    names=select['files']
    need(select['schema']=='fm-split-bundle-release-files-v1','selection schema')
    need(names==sorted(set(names)),'canonical selection')
    need(manifest['schema']=='fm-split-bundle-artifact-manifest-v1','manifest schema')
    need([row['path'] for row in manifest['files']]==names,'manifest membership')
    for row in manifest['files']:
        p=PurePosixPath(row['path'])
        need(not p.is_absolute() and '..' not in p.parts and str(p)==row['path'] and '\\' not in row['path'],'safe manifest path')
        target=root/row['path'];need(target.is_file() and not target.is_symlink(),'regular member')
        raw=target.read_bytes();need(len(raw)==row['bytes'] and digest(raw)==row['sha256'],'hash '+row['path'])
    return names,manifest

def main():
    names,manifest=inspect(ROOT);records=[]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
    with tempfile.TemporaryDirectory(prefix='selected-only-',dir=REVIEW) as td:
        temp=Path(td);clean=temp/'standalone';clean.mkdir()
        for name in names+['ARTIFACT-MANIFEST.json']:
            target=clean/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
        env['SPLIT_REVIEW_ROOT']=str(clean);inspect(clean)
        for script in ('run_tests.py','review/review_checks.py','review/adversarial_controls.py'):
            pair=[]
            for flags in ([],['-O']):
                p=subprocess.run([sys.executable,'-I','-B',*flags,str(clean/script)],cwd=temp,env=env,capture_output=True,text=True,timeout=240)
                need(p.returncode==0,script+' failed '+p.stderr[-4000:]);obj=json.loads(p.stdout);need(obj['status']=='PASS',script+' status')
                normalized={k:v for k,v in obj.items() if k!='python_optimized'};pair.append(normalized)
                records.append({'script':script,'mode':'optimized' if flags else 'normal','status':obj['status'],'checks':obj.get('total',obj.get('checks',obj.get('runs'))),'normalized_output_sha256':digest(json.dumps(normalized,sort_keys=True).encode())})
            need(pair[0]==pair[1],script+' normal/-O mismatch')
        inspect(clean)
        archives=[]
        for name in ('one.zip','two.zip'):
            out=temp/name
            p=subprocess.run([sys.executable,'-I','-B','-c','import sys;sys.path.insert(0,sys.argv[1]);from build_release import create_zip;import json;print(json.dumps(create_zip(sys.argv[2])))',str(clean),str(out)],cwd=temp,env=env,text=True,capture_output=True,timeout=60)
            need(p.returncode==0,'archive rebuild '+p.stderr);archives.append(out.read_bytes())
        need(archives[0]==archives[1],'byte reproducible ZIP')
        expected=sorted(names+['ARTIFACT-MANIFEST.json'])
        with zipfile.ZipFile(temp/'one.zip') as z:
            need(z.namelist()==expected,'exact ZIP membership')
            for info in z.infolist():
                need(info.date_time==(2026,1,1,0,0,0),'fixed ZIP time')
                need(info.compress_type==zipfile.ZIP_STORED and info.external_attr>>16==0o100644,'fixed ZIP format/mode')
                need(z.read(info.filename)==(clean/info.filename).read_bytes(),'ZIP member bytes')
        release=ROOT/'split-bundle-domain-v01.zip'
        if release.exists():need(release.read_bytes()==archives[0],'delivered archive differs from fresh build')
        # Source/manifest tampering is rejected without editing the original tree.
        target=clean/'split_bundle/producer.py';original=target.read_bytes();target.write_bytes(original+b'\n# injected source drift\n')
        p=subprocess.run([sys.executable,'-I','-B','-c','import sys;sys.path.insert(0,sys.argv[1]);from build_release import verify_manifest;verify_manifest()',str(clean)],cwd=temp,env=env,text=True,capture_output=True,timeout=30)
        need(p.returncode!=0 and 'Artifact drift' in p.stderr,'mutated source not rejected');target.write_bytes(original);inspect(clean)
        archive_sha=digest(archives[0]);archive_bytes=len(archives[0])
    inspect(ROOT)
    print(json.dumps({'status':'PASS','manifest_sha256':digest((ROOT/'ARTIFACT-MANIFEST.json').read_bytes()),'selected_files':len(names),'archive_members':len(names)+1,'archive_sha256':archive_sha,'archive_bytes':archive_bytes,'runs':records,'source_drift_rejected':True,'manifest_only_copy':True,'isolated_python':True,'no_sibling_dependency':True,'scope':'Formal arithmetic software replay, not Lean/runtime/geometric acceptance.'},sort_keys=True,indent=2))
if __name__=='__main__':main()
