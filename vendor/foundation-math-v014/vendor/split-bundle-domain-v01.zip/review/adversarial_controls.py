#!/usr/bin/env python3
"""Independent process isolation and source fault injection in review-owned copies."""
from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, sys, tempfile
REVIEW=Path(__file__).resolve().parent
ROOT=Path(os.environ.get('SPLIT_REVIEW_ROOT',str(REVIEW.parent))).resolve()
HARNESS=r'''
import copy,json,sys
from split_bundle.producer import calculate
from split_bundle.verifier import verify

def need(ok,label):
 if not ok:raise RuntimeError(label)
def reject(fn,label):
 try:fn()
 except ValueError:return
 raise RuntimeError(label+' accepted')
def b(l,a,n=1):return {'irrep':l,'twist':a,'multiplicity':n}
def r(bs,ts):return {'schema':'fm-split-bundle-request-v1','operation':'cohomology','bundle':bs,'twists':ts}
def h(a,b):return {'schema':'fm-split-bundle-request-v1','operation':'hom','source':a,'target':b}
r1=r([b('1',-10),b('1',-8),b('V',-8)],[8]);c=calculate(r1);v=verify(r1,c)
need(c['result']['twists'][0]['h1']['multiplicities']==[1,0,0,0,0,0,0,0,0],'negative H1')
need(c['result']['twists'][0]['euler']['multiplicities']==[0,0,0,0,0,0,0,0,1],'signed Euler')
need(v['lean_proof'] is False and v['runtime_acceptance'] is False and v['geometric_realization'] is False,'scope')
sym=r([b('1',0)],[2]);c2=calculate(sym);verify(sym,c2)
need(c2['result']['twists'][0]['h0']['multiplicities']==[0,0,1,0,0,0,0,0,0],'physical W')
h1=h([b('1',0)],[b('W',1)]);hc=calculate(h1);verify(h1,hc)
need(hc['result']['equivariant_hom_dimension']==1,'Hom orientation')
r2=copy.deepcopy(r1);r2['bundle'].append(b('1',0,0))
reject(lambda:verify(r2,c),'external binding')
cm=copy.deepcopy(c);cm['result']['twists'][0]['h1']['dimension']+=1
reject(lambda:verify(r1,cm),'tampered certificate')
print('PASS')
'''
MUTATIONS=[
 ('negative_h1_off_by_one','split_bundle/producer.py','sym(n if n>=0 else -n-2)','sym(n if n>=0 else -n-1)'),
 ('unsigned_euler','split_bundle/producer.py','e=h0.subtract(h1)','e=h0.add(h1)'),
 ('wrong_physical_doublet','split_bundle/producer.py','W=VirtualCharacter((0,1,0,0,0,0,0,0,0))','W=VirtualCharacter((0,0,0,0,0,0,0,1,0))'),
 ('trust_embedded_request','split_bundle/verifier.py','req=validate_request(expected_request)','req=validate_request(certificate["request"])'),
 ('checker_serre_shift','split_bundle/verifier.py','else -degree-2','else -degree-1'),
 ('checker_hom_reversal','split_bundle/verifier.py',"d=b['twist']-a['twist']","d=a['twist']-b['twist']"),
 ('checker_skip_certificate_equality','split_bundle/verifier.py',"require(wire.decode('ascii')==serial(expected),'E_CERTIFICATE'","require(True,'E_CERTIFICATE'"),
 ('false_lean_promotion','split_bundle/verifier.py',"'lean_proof':False","'lean_proof':True"),
]
def main():
    records=[]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
    for name,relative,old,new in [('baseline',None,None,None)]+MUTATIONS:
        with tempfile.TemporaryDirectory(prefix='fault-',dir=REVIEW) as td:
            dest=Path(td)
            for folder in ('split_bundle','character_ring'):shutil.copytree(ROOT/folder,dest/folder,ignore=shutil.ignore_patterns('__pycache__'))
            (dest/'harness.py').write_text(HARNESS)
            if relative:
                p=dest/relative;s=p.read_text()
                if s.count(old)!=1:raise RuntimeError('mutation precondition '+name)
                p.write_text(s.replace(old,new,1))
            for flags in ([],['-O']):
                p=subprocess.run([sys.executable,'-I','-B',*flags,'-c','import sys;sys.path.insert(0,sys.argv[1]);exec(open(sys.argv[1]+"/harness.py").read())',td],cwd=dest,env=env,text=True,capture_output=True,timeout=60)
                accepted=p.returncode==0
                if accepted!=(name=='baseline'):raise RuntimeError(name+' unexpected outcome '+p.stderr)
                records.append({'mutation':name,'mode':'optimized' if flags else 'normal','outcome':'baseline_passed' if accepted else 'detected','stderr_last_line':p.stderr.strip().split('\n')[-1] if p.stderr.strip() else None})
    out={'status':'PASS','mutation_cases':len(MUTATIONS),'runs':len(records),'records':records,'scope':'Fault injection in review-owned temporary copies; original author/frozen inputs unchanged.'}
    (REVIEW/'mutation-results.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
