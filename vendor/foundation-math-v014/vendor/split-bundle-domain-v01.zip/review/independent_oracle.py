"""Independent formal oracle, exact Q(sqrt5), no author imports.

The marked class table's identification with SL2(F5) is an assumption.
Closed binomial symmetric-character polynomials avoid the author's recurrence.
"""
from fractions import Fraction as Q
from functools import lru_cache
from math import comb

LABELS=('1','W','A','S4','D','T6','P','Wp','V')
DIMS=(1,2,3,4,5,6,4,2,3)
SIGNS=(1,-1,1,-1,1,-1,1,-1,1)
SIZES=(1,1,30,20,20,12,12,12,12)
CATALOG_SHA='84ceb37bc32d10c4908e5b5f1f2f5994082074f2c2a9f36c846347750c79fa74'
def q(a=0,b=0): return Q(a),Q(b)
def add(x,y): return x[0]+y[0],x[1]+y[1]
def scale(n,x): return n*x[0],n*x[1]
def mul(x,y): return x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def total(xs):
    ans=q()
    for x in xs:ans=add(ans,x)
    return ans
TRACE=(q(2),q(-2),q(),q(1),q(-1),q(Q(1,2),Q(1,2)),q(Q(-1,2),Q(-1,2)),q(Q(1,2),Q(-1,2)),q(Q(-1,2),Q(1,2)))
@lru_cache(None)
def sym(n):
    if type(n) is not int or n<0:raise ValueError('nonnegative exact degree required')
    ans=[]
    for x in TRACE:
        powers=[q(1)]
        for _ in range(n):powers.append(mul(x,powers[-1]))
        ans.append(total(scale((-1)**k*comb(n-k,k),powers[n-2*k]) for k in range(n//2+1)))
    return tuple(ans)
CH={name:sym(i) for i,name in enumerate(LABELS[:6])}
CH['P']=tuple(map(q,(4,4,0,1,1,-1,-1,-1,-1)))
CH['Wp']=tuple(add(mul(x,p),scale(-1,s)) for x,p,s in zip(TRACE,CH['P'],CH['T6']))
CH['V']=tuple(add(s,scale(-1,p)) for s,p in zip(sym(6),CH['P']))
ZERO=(0,)*9

def inner(c,d):
    a,b=total(scale(Q(s,120),mul(x,y)) for s,x,y in zip(SIZES,c,d))
    if b or a.denominator!=1:raise ValueError('not integral')
    return int(a)
def decomp(c):return tuple(inner(c,CH[l]) for l in LABELS)
def unit(l):return tuple(int(x==l) for x in LABELS)
def character(v):return tuple(total(scale(n,CH[l][j]) for l,n in zip(LABELS,v)) for j in range(9))
def tensor(u,v):return decomp(tuple(mul(x,y) for x,y in zip(character(u),character(v))))
def sumv(vs):return tuple(sum(v[i] for v in vs) for i in range(9))
def sparse(v):return {l:n for l,n in zip(LABELS,v) if n}
def dimension(v):return sum(d*n for d,n in zip(DIMS,v))
def split(blocks,t):
    # Independent review notation: iterable of (label, line degree, multiplicity).
    h0=[];h1=[];rank=0;degree=0
    for l,a,n in blocks:
        rank+=n*DIMS[LABELS.index(l)];degree+=n*a*DIMS[LABELS.index(l)]
        m=a+t
        if m==-1:continue
        v=decomp(tuple(mul(x,y) for x,y in zip(CH[l],sym(m if m>=0 else -m-2))))
        (h0 if m>=0 else h1).append(tuple(n*c for c in v))
    a,b=sumv(h0),sumv(h1)
    return {'h0':a,'h1':b,'euler':tuple(x-y for x,y in zip(a,b)),'rank':rank,'degree':degree}
def hom(source,target):
    count=0
    for u,a,nu in source:
        for v,b,nv in target:
            if b>=a:
                char=tuple(mul(mul(x,y),z) for x,y,z in zip(CH[u],CH[v],sym(b-a)))
                count+=nu*nv*inner(char,CH['1'])
    return count

def self_check():
    n=0
    def need(ok):
        nonlocal n
        n+=1
        if not ok:raise RuntimeError('oracle self-check '+str(n))
    need(sum(SIZES)==120);need(sum(x*x for x in DIMS)==120)
    for i,l in enumerate(LABELS):
        need(CH[l][0]==q(DIMS[i]));need(CH[l][1]==q(SIGNS[i]*DIMS[i]))
        for j,k in enumerate(LABELS):need(inner(CH[l],CH[k])==int(i==j))
    need(decomp(sym(2))==unit('A'));need(CH['A']!=CH['V']);need(CH['W']!=CH['Wp'])
    f=split([('1',-10,1),('1',-8,1),('V',-8,1)],8)
    need(f['h0']==sumv([unit('1'),unit('V')]));need(f['h1']==unit('1'));need(f['euler']==unit('V'));need(f['rank']==5);need(f['degree']==-42)
    need(hom([('W',-3,1)],[('W',-3,1)])==1)
    for t in range(-64,65):
        f=split([('1',0,1),('1',-2,1)],t);g=split([('W',-1,1)],t)
        need(f['euler']==g['euler'])
        need(dimension(f['euler'])==f['rank']*(t+1)+f['degree'])
    f=split([('1',0,1),('1',-2,1)],0);g=split([('W',-1,1)],0)
    need(f['h0']==f['h1']==unit('1'));need(g['h0']==g['h1']==ZERO)
    return n
if __name__=='__main__':
    import json
    print(json.dumps({'status':'PASS','checks':self_check(),'scope':'Formal arithmetic under the marked catalog assumption, not a geometric or Lean proof.'},sort_keys=True))
