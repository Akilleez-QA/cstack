# Independent formal split-bundle review

This review writes only under this review directory. The target is a standalone local formal calculator for supplied finite multisets of blocks U ⊗ O(a) on P(W). The physical catalog marking and its identification with SL2(F5) are mathematical assumptions. Numerical consistency, source hashes, and successful Python runs do not prove that identification, any geometric occurrence, a Lean theorem, or acceptance by another runtime.

## Independent mathematical oracle

Use exact rational pairs for Q(sqrt(5)); independently spell out the marked class table and decompose via weighted inner products. Evaluate Sym^n(W) from the closed binomial polynomial sum_k (-1)^k binom(n-k,k)x^(n-2k), not the author's fusion or symmetric recurrence. For each block, inspect m=a+t: H0=U⊗Sym^m(W) for m≥0, H1=U⊗Sym^(-m-2)(W) for m≤−2, and both zero for m=−1. Verify rank=sum dim U and degree=sum a dim U, including multiplicities. Verify dim Euler=rank(t+1)+degree, central parity on irreducible supports, direct-sum additivity, and Serre duality.

Hom controls use dim Hom_G(U(a),V(b))=dim (U*⊗V⊗Sym^(b−a)W)^G for b−a≥0, otherwise zero. In the marked real-character catalog U*=U. Distinguish Hom-space dimension from rank of any map and from existence of an embedding.

## Critical controls

- O(-10)+O(-8)+V(-8), t=8: H0=1+V, H1=1, Euler=V, rank=5, degree=−42.
- O⊕O(-2) versus W⊗O(-1): the same equivariant Euler class at every twist, but H0/H1 differ at t=0. The all-integer identity follows from the determinant-one equivariant Euler sequence 0→O(-2)→W⊗O(-1)→O→0, or the generalized symmetric-character recurrence, not a finite computation alone.
- W(-3) to itself: equivariant Hom dimension 1; no rank-one conclusion.
- Sym^2(W)=A, A≠V, W≠Wp.

## Boundary and integrity review

Exercise genuine/nonnegative block multiplicities; empty input; repeated blocks; exact ±boundaries; bool/float/subclasses/unknown keys, duplicate JSON keys, malformed UTF-8/JSON, cyclic in-memory values, resource limits, oversized strings/integers, invalid derived degrees, and omitted/excess fields. Determine whether every rejection occurs before unnecessary expensive work. Independently supplied requests must bind certificates even for requests with the same aggregate answer. Mutate each substantive certificate result, metadata, embedded request, digest, and scope. Tests must work under Python -O and not rely on assertions. Inspect import separation and catalog pinning. Reconstruct from only a manifest-listed source copy in a fresh directory; test normal and optimized runs and missing/changed source files.

No source-domain enumeration, actual coefficients, points, parameters, jets, matrices, instance ranks, model restart, package installation, repository creation, publication, or writes outside this review directory are authorized.
