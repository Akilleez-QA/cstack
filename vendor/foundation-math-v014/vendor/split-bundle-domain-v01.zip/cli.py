#!/usr/bin/env python3
from split_bundle.__main__ import main
if __name__=='__main__':raise SystemExit(main())
