#!/usr/bin/env python3
"""Build only explicitly selected files into a deterministic self-contained ZIP."""
import argparse,hashlib,json,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
MANIFEST='ARTIFACT-MANIFEST.json'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def safe_path(name):
    p=PurePosixPath(name)
    if type(name) is not str or p.is_absolute() or '..' in p.parts or str(p)!=name or not p.parts or '\\' in name:raise ValueError('Unsafe release path')
    return p

def selected(root=ROOT):
    obj=json.loads((root/'RELEASE-FILES.json').read_text());names=obj['files']
    if obj['schema']!='fm-split-bundle-release-files-v1' or names!=sorted(set(names)):raise ValueError('Noncanonical release selection')
    for name in names:
        safe_path(name)
        if name==MANIFEST or name.endswith('.zip') or '__pycache__' in name:raise ValueError('Invalid release selection')
        p=root/name
        if p.is_symlink() or not p.is_file():raise ValueError('Selected path must be a regular file')
    return names

def write_manifest(root=ROOT):
    rows=[]
    for name in selected(root):
        raw=(root/name).read_bytes();rows.append({'path':name,'bytes':len(raw),'sha256':digest(raw)})
    obj={'schema':'fm-split-bundle-artifact-manifest-v1','files':rows,'scope':'standalone formal supplied split-bundle arithmetic; no runtime acceptance, Lean proof or geometric realization'}
    (root/MANIFEST).write_text(json.dumps(obj,sort_keys=True,indent=2)+'\n');return obj

def verify_manifest(root=ROOT):
    m=json.loads((root/MANIFEST).read_text());names=selected(root)
    if m['schema']!='fm-split-bundle-artifact-manifest-v1' or [r['path'] for r in m['files']]!=names:raise ValueError('Manifest selection mismatch')
    for r in m['files']:
        raw=(root/r['path']).read_bytes()
        if len(raw)!=r['bytes'] or digest(raw)!=r['sha256']:raise ValueError('Artifact drift: '+r['path'])
    return m

def create_zip(output,root=ROOT):
    m=verify_manifest(root);names=sorted([r['path'] for r in m['files']]+[MANIFEST])
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_STORED) as z:
        for name in names:
            info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_STORED
            z.writestr(info,(root/name).read_bytes())
    return {'sha256':digest(Path(output).read_bytes()),'bytes':Path(output).stat().st_size,'files':len(names),'manifest_sha256':digest((root/MANIFEST).read_bytes())}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--write-manifest',action='store_true');p.add_argument('--output',type=Path,default=ROOT/'split-bundle-domain-v01.zip');a=p.parse_args()
    if a.write_manifest:write_manifest()
    print(json.dumps(create_zip(a.output),sort_keys=True,indent=2))
if __name__=='__main__':main()
