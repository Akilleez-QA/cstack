# Foundation Math: formal split-bundle cohomology lab

A standalone local arithmetic domain pack for a **supplied formal G-equivariant split bundle on P¹**. It computes exact H⁰, H¹, signed equivariant Euler characters, rank and degree at bounded requested twists. A second operation computes the equivariant Hom-space dimension between two supplied splittings, never a map rank or embedding verdict.

This is an experimental lab, not a registered Foundation Math runtime domain and not a Lean proof. No active research bundle is identified with a supplied splitting. The accepted physical character catalog is a pinned assumption: A=Sym²(W), A≠V and W≠Wp. Exact arithmetic is over Q(√5).

## Quick start

```sh
python cli.py calculate examples/negative_h1_critical.request.json > /tmp/split-certificate.json
python cli.py verify examples/negative_h1_critical.request.json /tmp/split-certificate.json
python run_tests.py
python -O run_tests.py
python reproduce.py
```

Requires only Python3.10+ standard library. Everything needed is contained here. No network, installations, sibling source tree, actual-instance data or model experiment is needed.

## Important controls

- For formal F=O(-10)⊕O(-8)⊕V(-8), at twist8: H⁰=1+V, H¹=1, Euler=V. Negative-degree contributions cannot be dropped.
- O⊕O(-2) and W⊗O(-1) have the same equivariant Euler characters at **all integer twists**, but different H⁰/H¹ at twist0. Equal Euler data do not determine cohomology or splitting.
- Hom_G(W(-3),W(-3)) has dimension1. That is the dimension of a space of maps, not a rank-one map conclusion.

## Contents

- MATHEMATICS.md: self-contained formulas, negative H¹ justification, fixed catalog and geometric boundaries.
- API.md: strict request grammar, resource limits, certificate fields and commands.
- split_bundle/: independent producer/checker implementation.
- character_ring/: byte-identical vendored accepted v0.9 character engine and fixed catalog, recorded by SOURCE-MANIFEST.json.
- run_tests.py, examples/, evidence/: synthetic normal/-O/adversarial controls.
- review/: independent review files after completion.
- RELEASE-FILES.json, ARTIFACT-MANIFEST.json, build_release.py, reproduce.py: manifest-selected deterministic archive and isolated replay.

The checker requires an external expected request and independently reconstructs every certificate field using exact class functions. The producer uses integer fusion, while the separate reviewer uses a binomial symmetric-character formula. Verification reports arithmetic validity conditional on the stated inputs, with runtime_acceptance=false, lean_proof=false and geometric_realization=false.

The frozen v0.9 tree and research packets are read-only inputs and are not edited. There is no publication, repository creation, runtime promotion or new experimental scan.
