#!/usr/bin/env python3
"""Synthetic universal/formal controls only. No active research instance inputs."""
import copy,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from split_bundle.producer import calculate
from split_bundle.verifier import verify,VerificationError,validate_request
from split_bundle.contract import parse_request,load_json,DomainError,serial,LABELS,BUDGETS
COUNT=0;MUTATIONS=[]
def check(ok,msg):
    global COUNT
    COUNT+=1
    if not ok:raise RuntimeError(msg)
def block(irrep='1',twist=0,multiplicity=1):return {'irrep':irrep,'twist':twist,'multiplicity':multiplicity}
def coh(bs,ts):return {'schema':'fm-split-bundle-request-v1','operation':'cohomology','bundle':bs,'twists':ts}
def hom(a,b):return {'schema':'fm-split-bundle-request-v1','operation':'hom','source':a,'target':b}
def reject(fn,label):
    try:fn()
    except (ValueError,TypeError,RecursionError):check(True,label);return
    raise RuntimeError('Invalid input accepted: '+label)
def run(req):
    c=calculate(req);v=verify(req,c);check(v['status']=='verified_arithmetic','verification');check(not v['runtime_acceptance'] and not v['lean_proof'] and not v['geometric_realization'],'scope');return c
def ms(c,i,key):return c['result']['twists'][i][key]['multiplicities']
def one(label,m=1):return [m*int(x==label) for x in LABELS]
def save(name,req):
    c=run(req)
    for kind,x in [('request',req),('certificate',c)]:
        (ROOT/'examples'/f'{name}.{kind}.json').write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
    return c

def main():
    critical=coh([block('1',-10),block('1',-8),block('V',-8)],[8])
    c=save('negative_h1_critical',critical)
    check(ms(c,0,'h0')==[a+b for a,b in zip(one('1'),one('V'))],'critical H0')
    check(ms(c,0,'h1')==one('1'),'critical H1');check(ms(c,0,'euler')==one('V'),'critical Euler')
    a=coh([block('1',0),block('1',-2)],[-64,-5,-2,-1,0,1,2,5,64]);b=coh([block('W',-1)],a['twists'])
    ca=save('euler_collision_lines',a);cb=save('euler_collision_doublet',b)
    for i in range(len(a['twists'])):check(ms(ca,i,'euler')==ms(cb,i,'euler'),'Euler collision sample')
    check(ms(ca,4,'h0')==ms(ca,4,'h1')==one('1'),'split lines at zero')
    check(ms(cb,4,'h0')==ms(cb,4,'h1')==[0]*9,'doublet at zero')
    ch=save('hom_not_map_rank',hom([block('W',-3)],[block('W',-3)]))
    check(ch['result']['equivariant_hom_dimension']==1,'Schur dimension1')
    check(ch['result']['hom_character']['dimension']==4,'all linear maps dimension4')
    check('map_rank' not in ch['result'] and 'no_map_rank' in ch['result']['conclusion'],'no map-rank inference')
    save('empty_bundle',coh([],[-64,-1,0,64]));save('zero_multiplicity',coh([block('V',64,0)],[64]))
    # Every physical label across all cohomological regimes, including extreme shifts.
    dims=(1,2,3,4,5,6,4,2,3)
    for label,dim in zip(LABELS,dims):
        req=coh([block(label,0,3)],[-64,-2,-1,0,1,2,64]);cc=run(req)
        for t,row in zip(req['twists'],cc['result']['twists']):
            check(row['h0']['dimension']==3*dim*max(t+1,0),'H0 dimension')
            check(row['h1']['dimension']==3*dim*max(-t-1,0),'H1 dimension')
            check(row['euler']['dimension']==3*dim*(t+1),'Euler dimension')
            check(row['rank']==3*dim and row['degree']==3*dim*t,'rank and degree')
        check(ms(cc,1,'h1')==one(label,3),'H1(-2) irrep')
        check(ms(cc,3,'h0')==one(label,3),'H0(0) irrep')
    # The chosen physical doublet and distinct same-dimensional irreps stay distinct.
    cc=run(coh([block()],[2]));check(ms(cc,0,'h0')==one('A'),'A=Sym2W not V')
    for left,right in [('W','Wp'),('A','V')]:
        check(run(hom([block(left)],[block(right)]))['result']['equivariant_hom_dimension']==0,'distinct labels')
    check(run(hom([block('1',1)],[block('1',0)]))['result']['equivariant_hom_dimension']==0,'Hom direction')
    check(run(hom([block('1',0)],[block('1',1)]))['result']['hom_character']['multiplicities']==one('W'),'Hom degree')
    # Request values are detached, and duplicate blocks sum without deduplication.
    q=coh([block('V',0,2),block('V',0,3)],[0]);z=run(q);check(ms(z,0,'h0')==one('V',5),'multiset')
    q['bundle'][0]['multiplicity']=9;check(z['request']['bundle'][0]['multiplicity']==2,'detached request')
    # Budget boundary: maximum block/twist count, multiplicities, and degree128.
    edge=coh([block(LABELS[i%9],64,1000000) for i in range(32)],list(range(33,65)))
    e=run(edge);check(len(e['result']['twists'])==32,'max boundary')
    run(coh([block('1',-64)],[-64]));run(hom([block('W',-64,1000000)],[block('Wp',64,1000000)]))
    # Reject invalid data independently at both request boundaries.
    invalid=[]
    for val in [-1,1000001,True,1.0,'1',None]:
        q=copy.deepcopy(critical);q['bundle'][0]['multiplicity']=val;invalid.append(q)
    for val in [-65,65,True,1.0,'0',None]:
        q=copy.deepcopy(critical);q['bundle'][0]['twist']=val;invalid.append(q)
    for val in ['wp','B','A=V','W=Wp','trivial',0,None]:
        q=copy.deepcopy(critical);q['bundle'][0]['irrep']=val;invalid.append(q)
    for ts in [[],[0,0],[65],[-65],[True],[1.0],list(range(33)),None]:
        q=copy.deepcopy(critical);q['twists']=ts;invalid.append(q)
    for change in [{'schema':'wrong'},{'operation':'map_rank'},{'operation':[]},{'geometric_realization':True},{'bundle':[block()]*33},{'bundle':{}},{'bundle':None}]:
        q=copy.deepcopy(critical);q.update(change);invalid.append(q)
    q=copy.deepcopy(critical);q['bundle'][0]['selected_point']=[0,0];invalid.append(q)
    q=copy.deepcopy(critical);del q['bundle'][0]['irrep'];invalid.append(q)
    for i,q in enumerate(invalid):
        reject(lambda q=q:parse_request(q),'producer invalid '+str(i));reject(lambda q=q:validate_request(q),'checker invalid '+str(i))
    for raw in [b'{"x":1,"x":2}',b'{"n":1.0}',b'{"n":NaN}',b'{"n":Infinity}',b'{"n":'+b'9'*91+b'}',b'\xff',b'['*2000+b']'*2000,b' '*65537]:
        reject(lambda raw=raw:load_json(raw,65536),'strict JSON')
    cyc=[];cyc.append(cyc);reject(lambda:parse_request(cyc),'cycle guard')
    reject(lambda:parse_request({'x':'a'*1000000}),'oversized string')
    reject(lambda:parse_request({'x':[0]*100000}),'oversized list')
    # Atomic edits target every reported claim and provenance binding.
    paths=[('schema',),('catalog_sha256',),('request_sha256',),('scope',),('assumptions','splitting'),('request','bundle',0,'twist'),('result','bundle','rank'),('result','bundle','degree'),('result','twists',0,'twist'),('result','twists',0,'degree'),('result','twists',0,'rank')]
    for key in ('h0','h1','euler'):
        base=('result','twists',0,key)
        paths += [base+('multiplicities',i) for i in range(9)]
        paths += [base+(k,) for k in ('dimension','classification','center_parity','even_dimension','odd_dimension')]
        paths += [base+('class_values',i,j) for i in range(9) for j in range(4)]
    for path in paths:
        z=copy.deepcopy(c);p=z
        for part in path[:-1]:p=p[part]
        old=p[path[-1]];p[path[-1]]=old+1 if type(old) is int else 'mutated'
        reject(lambda z=z:verify(critical,z),'certificate mutation '+str(path));MUTATIONS.append('/'.join(map(str,path)))
    for val in (True,1.0):
        z=copy.deepcopy(c);z['result']['bundle']['rank']=val;reject(lambda:verify(critical,z),'exact type mutation')
    z=copy.deepcopy(c);z['result']['embedding_exists']=1;reject(lambda:verify(critical,z),'unrequested geometric conclusion')
    z=copy.deepcopy(c);z['result']['twists'][0]['h1']['negative_multiplicities']={'1':-1};reject(lambda:verify(critical,z),'negative support mutation')
    other=copy.deepcopy(critical);other['bundle'].append(block('1',0,0));reject(lambda:verify(other,c),'same result different request')
    reject(lambda:verify(critical,ch),'cross operation certificate')
    for key in ('equivariant_hom_dimension','conclusion'):
        z=copy.deepcopy(ch);z['result'][key]=2 if key.endswith('dimension') else 'rank_one_map'
        reject(lambda z=z:verify(ch['request'],z),'Hom claim mutation')
    # Verification works when both producers and the request contract are forbidden.
    isolation="""import sys,importlib.abc,json
class Deny(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname in ('split_bundle.producer','split_bundle.contract','character_ring.producer','character_ring.contract'):raise RuntimeError('forbidden import '+fullname)
sys.meta_path.insert(0,Deny())
from split_bundle.verifier import verify
req=json.load(open(sys.argv[1]));cert=json.load(open(sys.argv[2]));verify(req,cert)
print('independent checker import PASS')
"""
    p=subprocess.run([sys.executable,*(['-O'] if not __debug__ else []),'-c',isolation,str(ROOT/'examples/negative_h1_critical.request.json'),str(ROOT/'examples/negative_h1_critical.certificate.json')],cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True,timeout=60)
    check(p.returncode==0,p.stderr)
    # CLI runs from unrelated cwd and rejects invalid request/certificate pairs.
    for mode,args in [('calculate',['examples/negative_h1_critical.request.json']),('verify',['examples/negative_h1_critical.request.json','examples/negative_h1_critical.certificate.json'])]:
        p=subprocess.run([sys.executable,*(['-O'] if not __debug__ else []),str(ROOT/'cli.py'),mode,*[str(ROOT/x) for x in args]],cwd='/tmp',capture_output=True,text=True,timeout=60)
        check(p.returncode==0,p.stderr);check(type(json.loads(p.stdout)) is dict,'CLI JSON')
    p=subprocess.run([sys.executable,str(ROOT/'cli.py'),'verify',str(ROOT/'examples/empty_bundle.request.json'),str(ROOT/'examples/negative_h1_critical.certificate.json')],cwd='/tmp',capture_output=True,text=True,timeout=60)
    check(p.returncode==2 and json.loads(p.stderr)['code']=='E_CERTIFICATE','CLI mismatch')
    print(json.dumps({'status':'PASS','checks':COUNT,'certificate_mutations_rejected':len(MUTATIONS),'invalid_request_cases':len(invalid),'critical_fixture':'H0=1+V; H1=1; Euler=V','euler_collision':'universal identity proved in MATHEMATICS.md; sampled boundary regression passed','checker_import_independence':True,'catalog_sha256':'84ceb37bc32d10c4908e5b5f1f2f5994082074f2c2a9f36c846347750c79fa74','scope':'formal_supplied_split_bundle_arithmetic_only','runtime_acceptance':False,'lean_proof':False,'geometric_realization':False},sort_keys=True,indent=2))
if __name__=='__main__':main()
