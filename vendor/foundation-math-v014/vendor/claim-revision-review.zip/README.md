# Independent claim-revision ledger review

Result: PASS for the exact corrected candidate pins below. One input-validation defect
was independently found, sent to the author, fixed, and verified closed. No outstanding
correctness defect was observed within the stated synthetic scope.

This is a separate reviewer artifact. It does not modify or integrate the candidate,
the frozen v0.10 tree, an acceptance registry, or a mathematical proof system.

## Reproduce

Python 3.11+ standard library only; no packages, network, credentials, or external models.

```sh
python -B reproduce_review.py /path/to/foundation-math-claim-revision-lab.zip
```

The script checks the exact pinned archive, manifest, and core; verifies every manifest
member; extracts only those members into a fresh temporary directory; copies only the
independent reviewer scripts into a separate directory; and runs the author aggregate
plus independent normal and optimized (`-O`) reviews. It removes PYTHONPATH and
PYTHONHOME from child environments. A saved JSON result is not used as a substitute
for execution. The archive is trusted source reviewed for this task, not an arbitrary
code-upload execution service.

To test an unpacked candidate against the independent suite:

```sh
python -B review.py /path/to/foundation-math-claim-revision-lab
python -B -O review.py /path/to/foundation-math-claim-revision-lab
```

## Candidate pins

- ZIP SHA-256: `c3805e92aa2b3259e310c126fac751f4bf34646f17f3442cfd63b44386d93fa9`
- SOURCE-MANIFEST.json SHA-256: `37101f16966c8427ac639e3328d98aca10cc5a3b17783748a56e808fb12a9c22`
- claim_revision/core.py SHA-256: `c6c1f2ef00a64d514a781f281c7318612d644dc6b872690f6de7f16577552294`
- docs/CONTRACT.md SHA-256: `f8f196d4d63c753b3d0f2d5834851ea02e7b37b5bf7c6d50247e76e5c9342d60`

See REPORT.md for findings and exact scope, CLEAN-REPLAY.json for freshly executed
machine-readable results, and REVIEW-MANIFEST.json for this review's file hashes.
