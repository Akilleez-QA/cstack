#!/usr/bin/env python3
"""Independent semantic source-guard mutation probes, only on temporary copies.
No author tests imported. A crash/PlanError is not counted as a killed mutant.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import verify

MUTANTS = [
 ('mandatory_role_guard',"if c['role'] in MANDATORY_FRESH:","if False:",'mandatory_current_runtime_normal'),
 ('closure_guard',"if c['closure'] != {'declaration': 'caller_declares_complete', 'files': 'exact_selected_manifest', 'process_state': 'pinned_environment_and_stdin', 'external_state': 'none', 'randomness': 'none', 'clock': 'none'}:","if False:",'unknown_closure_declaration'),
 ('input_pin_guard',"if c['invocation']['stdin_sha256'] is None or any(f['sha256'] is None for f in c['inputs']):","if False:",'unknown_stdin'),
 ('environment_guard',"if any(c['environment'][k] is None for k in ('runner_sha256', 'environment_sha256')):","if False:",'unknown_environment_sha256'),
 ('result_guard',"if result['outcome'] != 'declared_pass' or result['exit_code'] != 0:","if False:",'receipt_failed'),
 ('output_pin_guard',"if result['output_sha256'] is None:","if False:",'receipt_missing_output'),
 ('withdrawal_guard',"if rc['availability'] != 'supplied':","if False:",'receipt_withdrawn'),
 ('selected_task_equality',"if selection['task'] != pin(task):","if False:",'stale_task_selection'),
 ('selected_receipt_equality',"elif selection['receipt'] != pin(prior):","elif False:",'stale_receipt_selection'),
 ('receipt_task_equality',"if rc['task'] != pin(task):","if False:",'wrong_receipt_task_binding'),
 ('dependency_freshness',"if reports[dep['id']]['classification'] == 'MUST_RUN_FRESH':","if False:",'mandatory_fresh_propagates'),
 ('dependency_set_equality',"if set(expected_deps) != set(prior_deps):","if False:",'receipt_dependency_set_missing'),
 ('dependency_task_equality',"if edge['task'] != expected_deps[dep_id]:","if False:",'wrong_dependency_task_pin'),
 ('dependency_receipt_equality',"if edge['receipt'] != pin(actual_receipt):","if False:",'new_output_explicit_selection_but_stale_dependents'),
 ('integrity_guard',"if record['revision_sha256'] != digest({k: record[k] for k in ('id', 'revision', 'content')}):","if False:",'unsealed_tasks_revision'),
 ('boolean_integer_guard',"if type(value) is not int or not low <= value <= high:","if not isinstance(value, int) or not low <= value <= high:",'semantic_bytes_boolean'),
 ('nonclaim_false_literal',"'fresh_pass_claimed': False,","'fresh_pass_claimed': True,",'all_false_nonclaims_literal'),
]

def run(lab):
    source=(lab/'validation_receipt/core.py').read_text(); verify.register(); cases=dict(verify.CASES); out=[]
    # The unmutated source must pass the exact same probes first.
    baseline=verify.load_core(lab)
    for _,_,_,test in MUTANTS: cases[test](baseline)
    with tempfile.TemporaryDirectory(prefix='independent-receipt-mutants-') as tmp:
        for name,before,after,test in MUTANTS:
            if source.count(before)!=1: raise RuntimeError('mutation target not unique: '+name)
            dest=Path(tmp)/(name+'.py'); dest.write_text(source.replace(before,after))
            spec=importlib.util.spec_from_file_location('mutant_'+name,dest); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            actual_plan=module.plan; successful_reports=[]
            def record_plan(doc):
                report=actual_plan(doc); successful_reports.append(report); return report
            module.plan=record_plan
            try:
                cases[test](module)
            except AssertionError as exc:
                if not successful_reports: raise RuntimeError('not a successful semantic-report mutation: '+name)
                out.append({'mutation':name,'probe':test,'status':'killed_by_semantic_assertion','message':str(exc),'successful_mutant_reports':len(successful_reports)})
            except Exception as exc:
                out.append({'mutation':name,'probe':test,'status':'invalid_incidental_exception','exception':type(exc).__name__,'message':str(exc)})
            else: out.append({'mutation':name,'probe':test,'status':'survived'})
    return {'schema':'independent-receipt-source-mutations/1','optimized':not __debug__,'core_sha256':verify.bytesha(source.encode()),'mutants':len(out),'killed':sum(r['status']=='killed_by_semantic_assertion' for r in out),'results':out,'scope':'Temporary source copies only; every counted kill has successful planner output followed by a specific independent semantic assertion failure, never a crash.'}

def main():
    p=argparse.ArgumentParser(); p.add_argument('lab',type=Path); p.add_argument('--output',type=Path); a=p.parse_args(); result=run(a.lab.resolve()); text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if a.output: a.output.write_text(text)
    else: print(text,end='')
    print(f"{result['killed']}/{result['mutants']} independent semantic mutants killed",file=sys.stderr)
    return result['killed']!=result['mutants']

if __name__=='__main__': sys.exit(main())
