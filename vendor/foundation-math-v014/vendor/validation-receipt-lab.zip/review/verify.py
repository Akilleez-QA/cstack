#!/usr/bin/env python3
"""Independent portable contract probes. No author fixtures or hashing helpers used."""
import argparse
import ast
from copy import deepcopy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import subprocess
import sys
import tempfile

SCHEMA = 'foundation-math-validation-receipt-plan/1'
MATCH = 'PRIOR_PINNED_EVIDENCE_MATCHES'
FRESH = 'MUST_RUN_FRESH'
FALSES = ('execution_performed', 'fresh_pass_claimed', 'skip_authorized', 'closure_verified', 'artifact_bytes_verified', 'authenticity_verified', 'mathematical_truth_checked', 'proof_acceptance_changed')
CASES = []

def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')

def sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()

def bytesha(value):
    return hashlib.sha256(value).hexdigest()

def sign(record):
    body = {k: deepcopy(record[k]) for k in ('id', 'revision', 'content')}
    return dict(body, revision_sha256=sha(body))

def pin(record):
    return {k: deepcopy(record[k]) for k in ('id', 'revision', 'revision_sha256')}

def task(name, deps=(), role='historical_component'):
    return sign({'id': name, 'revision': 1, 'content': {
        'role': role,
        'invocation': {'argv': ['nonexistent-independent-runner', '--suite', name, ''], 'cwd': 'review/fixtures', 'stdin_sha256': bytesha(b'')},
        'inputs': [{'path': 'declared/' + name + '.txt', 'bytes': len(name.encode()), 'sha256': bytesha(name.encode())}],
        'environment': {'runner_sha256': bytesha(b'fictional independent runner'), 'environment_sha256': bytesha(b'fictional closed independent environment'), 'description': 'Invented reviewer declarations, not observed execution.'},
        'closure': {'declaration': 'caller_declares_complete', 'files': 'exact_selected_manifest', 'process_state': 'pinned_environment_and_stdin', 'external_state': 'none', 'randomness': 'none', 'clock': 'none'},
        'dependencies': sorted([pin(t) for t in deps], key=lambda t: t['id'])}})

def receipt(t, deps=(), name=None):
    return sign({'id': name or 'evidence.' + t['id'], 'revision': 1, 'content': {
        'task': pin(t), 'availability': 'supplied',
        'result': {'outcome': 'declared_pass', 'exit_code': 0, 'output_sha256': bytesha(('invented result ' + t['id']).encode())},
        'dependency_receipts': sorted([{'task': pin(t0), 'receipt': pin(r0)} for t0,r0 in deps], key=lambda d: d['task']['id'])}})

def document(tasks, receipts, select=True):
    rr = {r['content']['task']['id']:r for r in receipts}
    return {'schema': SCHEMA, 'tasks':tasks, 'receipts':receipts, 'selections':[{'task':pin(t), 'receipt':pin(rr[t['id']])} for t in tasks if t['id'] in rr] if select else []}

def single():
    t=task('Root'); return document([t],[receipt(t)])

def diamond():
    a=task('Root'); b=task('Left',[a]); c=task('Right',[a]); d=task('Join',[b,c]); e=task('Outside')
    ar=receipt(a); br=receipt(b,[(a,ar)]); cr=receipt(c,[(a,ar)]); dr=receipt(d,[(b,br),(c,cr)]); er=receipt(e)
    return document([a,b,c,d,e],[ar,br,cr,dr,er])

def change_task(doc, mutate, index=0, update_selection=True, update_receipt=False):
    t=deepcopy(doc['tasks'][index]); mutate(t); t=sign(t); doc['tasks'][index]=t
    if update_selection:
        for s in doc['selections']:
            if s['task']['id']==t['id']: s['task']=pin(t)
    if update_receipt:
        change_receipt(doc,lambda r:r['content'].update(task=pin(t)),index=index)
    return t

def change_receipt(doc, mutate, index=0, update_selection=True):
    r=deepcopy(doc['receipts'][index]); mutate(r); r=sign(r); doc['receipts'][index]=r
    if update_selection:
        for s in doc['selections']:
            if s['receipt']['id']==r['id']: s['receipt']=pin(r)
    return r

def equal(a,b,why='mismatch'):
    if a!=b: raise AssertionError(f'{why}: got {a!r}, expected {b!r}')

def truth(v,why):
    if not v: raise AssertionError(why)

def rows(report): return {r['task']['id']:r for r in report['tasks']}

def codes(row): return [r['code'] for r in row['reasons']]

def reject(module, doc, code, method='plan', path=None):
    try: getattr(module,method)(doc)
    except module.PlanError as exc:
        equal(exc.code,code,'rejection code')
        if path is not None: equal(exc.path,path,'rejection path')
        truth(type(exc.message) is str and bool(exc.message),'missing failure message')
        return
    raise AssertionError('expected explicit PlanError, got success')

def blocked(module, doc, code, subject='Root', propagation=False):
    rs=rows(module.plan(doc)); r=rs[subject]
    equal(r['classification'],FRESH,'classification')
    truth(code in codes(r),f'missing exact blocker {code}: {codes(r)}')
    if propagation:
        for name in ['Root','Left','Right','Join']: equal(rs[name]['classification'],FRESH,name)
        equal(rs['Outside']['classification'],MATCH,'unrelated component')
        equal(rs['Join']['fresh_dependencies'],['Left','Right'])
        equal(rs['Join']['fresh_ancestors'],['Left','Right','Root'])
    return rs

def case(name, fn): CASES.append((name,fn))

def full_expected(doc):
    normalized={**doc,'tasks':sorted(doc['tasks'],key=lambda t:t['id']),'receipts':sorted(doc['receipts'],key=lambda r:r['id']),'selections':sorted(doc['selections'],key=lambda s:s['task']['id'])}
    selected={s['task']['id']:s['receipt'] for s in doc['selections']}
    return {'schema':'foundation-math-validation-receipt-report/1','input_sha256':sha(normalized),
        'tasks':[{'task':pin(t),'classification':MATCH,'selected_receipt':selected[t['id']], 'supplied_receipt':selected[t['id']], 'reasons':[], 'fresh_dependencies':[], 'fresh_ancestors':[], 'selected_manifest_sha256':sha(t['content']['inputs'])} for t in sorted(doc['tasks'],key=lambda t:t['id'])],
        **{k:False for k in FALSES},'scope':'Syntactic integrity and applicability within a caller-declared closed input boundary only.'}

def register():
    case('independent_complete_report',lambda m: equal(m.plan(diamond()),full_expected(diamond())))
    case('independent_canonical_and_digest',lambda m:(equal(m.canonical_bytes({'z':'é','a':[True,None,7]}),b'{"a":[true,null,7],"z":"\xc3\xa9"}'),equal(m.digest({'z':'é','a':[True,None,7]}),sha({'z':'é','a':[True,None,7]}))))
    case('independent_seal_and_pin',lambda m:(equal(m.seal({k:v for k,v in single()['tasks'][0].items() if k!='revision_sha256'}),single()['tasks'][0]),equal(m.pin(single()['tasks'][0]),pin(single()['tasks'][0]))))
    def permutation(m):
        d=diamond(); before=deepcopy(d); expected=full_expected(d)
        for order in itertools.permutations(range(5)):
            p=deepcopy(d)
            for key in ('tasks','receipts','selections'): p[key]=[p[key][i] for i in order]
            equal(m.plan(p),expected,'registry permutation')
        equal(d,before,'input mutated')
        report=m.plan(d); report['tasks'][0]['task']['revision']=999; equal(d,before,'report aliases caller input')
    case('all_120_registry_permutations_and_nonmutation',permutation)
    for role in ('archival_full_replay','current_runtime','new_adapter'):
        for optimized_argv in (False,True):
            def run(m,role=role,opt=optimized_argv):
                t=task('Root',role=role)
                if opt: t['content']['invocation']['argv'].append('-O'); t=sign(t)
                d=document([t],[receipt(t)]); r=blocked(m,d,'mandatory_fresh_policy')['Root']
                equal(codes(r),['mandatory_fresh_policy'])
            case('mandatory_'+role+('_opt' if optimized_argv else '_normal'),run)
    def distinct(m):
        h=task('HistoricalEvidence'); a=task('RequestedReplay',role='archival_full_replay'); a['content']['invocation']=deepcopy(h['content']['invocation']); a=sign(a)
        r=rows(m.plan(document([h,a],[receipt(h),receipt(a)])))
        equal(r[h['id']]['classification'],MATCH); equal(r[a['id']]['classification'],FRESH)
    case('same_argv_distinct_historical_and_replay',distinct)
    mutations={
        'revision':lambda t:t.update(revision=2), 'argv_insert':lambda t:t['content']['invocation']['argv'].append('extra'),
        'argv_order':lambda t:t['content']['invocation']['argv'].__setitem__(slice(1,3),list(reversed(t['content']['invocation']['argv'][1:3]))), 'argv_empty_removed':lambda t:t['content']['invocation']['argv'].pop(),
        'cwd':lambda t:t['content']['invocation'].update(cwd='other'), 'stdin':lambda t:t['content']['invocation'].update(stdin_sha256=bytesha(b'new')),
        'file_hash':lambda t:t['content']['inputs'][0].update(sha256=bytesha(b'new')), 'file_size':lambda t:t['content']['inputs'][0].update(bytes=99),
        'file_name':lambda t:t['content']['inputs'][0].update(path='new/name'), 'manifest_remove':lambda t:t['content']['inputs'].clear(),
        'manifest_add':lambda t:t['content']['inputs'].append({'path':'z/add','bytes':0,'sha256':bytesha(b'')}),
        'runner':lambda t:t['content']['environment'].update(runner_sha256=bytesha(b'new')), 'environment':lambda t:t['content']['environment'].update(environment_sha256=bytesha(b'new')),
        'environment_description':lambda t:t['content']['environment'].update(description='Different interpretation')}
    for name, mutate in mutations.items():
        def run(m,mutate=mutate,name=name):
            d=diamond(); old=pin(d['tasks'][0]); change_task(d,mutate)
            rs=blocked(m,d,'receipt_task_pin_not_current',propagation=True)
            equal(rs['Root']['reasons'],[{'code':'receipt_task_pin_not_current','subject':'Root','expected':old,'supplied':pin(d['tasks'][0])}])
            truth('dependency_task_pin_not_current' in codes(rs['Left']),'dependency task drift not diagnosed')
        case('task_drift_'+name,run)
    unknowns=[('stdin',lambda t:t['content']['invocation'].update(stdin_sha256=None),'input_pin_unknown'),('file',lambda t:t['content']['inputs'][0].update(sha256=None),'input_pin_unknown')]
    unknowns += [(key,lambda t,key=key:t['content']['environment'].update({key:None}),'environment_pin_unknown') for key in ('runner_sha256','environment_sha256')]
    unknowns += [('closure_'+key,lambda t,key=key:t['content']['closure'].update({key:'unknown'}),'closure_not_declared_complete') for key in ('declaration','files','process_state','external_state','randomness','clock')]
    for name,mutate,code in unknowns:
        def run(m,mutate=mutate,code=code):
            d=single(); change_task(d,mutate,update_receipt=True); r=blocked(m,d,code)['Root']; equal(codes(r),[code])
        case('unknown_'+name,run)
    result_mutations=[('failed',lambda r:r['content']['result'].update(outcome='declared_fail'),'prior_result_not_declared_pass'),('unknown',lambda r:r['content']['result'].update(outcome='unknown'),'prior_result_not_declared_pass'),('nonzero_exit',lambda r:r['content']['result'].update(exit_code=1),'prior_result_not_declared_pass'),('negative_exit',lambda r:r['content']['result'].update(exit_code=-1),'prior_result_not_declared_pass'),('missing_exit',lambda r:r['content']['result'].update(exit_code=None),'prior_result_not_declared_pass'),('missing_output',lambda r:r['content']['result'].update(output_sha256=None),'prior_output_pin_unknown'),('withdrawn',lambda r:r['content'].update(availability='withdrawn'),'prior_receipt_withdrawn')]
    for name,mutate,code in result_mutations:
        def run(m,mutate=mutate,code=code):
            d=diamond(); change_receipt(d,mutate); blocked(m,d,code,propagation=True)
        case('receipt_'+name,run)
    def stale_output(m,selected):
        d=diamond(); old=pin(d['receipts'][0]); change_receipt(d,lambda r:r['content']['result'].update(output_sha256=bytesha(b'different output')),update_selection=selected)
        if not selected:
            rs=blocked(m,d,'selected_receipt_pin_not_current',propagation=True)
            equal(rs['Root']['selected_receipt'],old); equal(rs['Root']['supplied_receipt'],pin(d['receipts'][0]))
        else:
            rs=blocked(m,d,'dependency_receipt_pin_not_current',subject='Left'); equal(rs['Root']['classification'],MATCH); equal(rs['Join']['classification'],FRESH)
            truth('dependency_receipt_not_selected_exactly' in codes(rs['Left']),'new output silently rebound')
    case('stale_output_hash_selection',lambda m:stale_output(m,False)); case('new_output_explicit_selection_but_stale_dependents',lambda m:stale_output(m,True))
    def rebind(m):
        d=diamond(); change_receipt(d,lambda r:r['content']['result'].update(output_sha256=bytesha(b'different output')))
        for i in (1,2): change_receipt(d,lambda r:r['content']['dependency_receipts'][0].update(receipt=pin(d['receipts'][0])),index=i)
        change_receipt(d,lambda r:r['content'].update(dependency_receipts=[{'task':pin(d['tasks'][i]),'receipt':pin(d['receipts'][i])} for i in (1,2)]),index=3)
        equal(m.plan(d),full_expected(d))
    case('complete_explicit_rebinding_can_match_not_fresh_pass',rebind)
    def no_selection(m):
        d=diamond(); d['selections']=[]; r=rows(m.plan(d)); equal(set(r),{'Root','Left','Right','Join','Outside'})
        for rr in r.values(): equal(rr['classification'],FRESH); truth('prior_receipt_not_selected' in codes(rr),'automatic receipt search')
    case('no_implicit_latest_or_task_omission',no_selection)
    def missing(m):
        d=single(); d['selections'][0]['receipt']['id']='Unavailable'; r=blocked(m,d,'selected_receipt_not_supplied')['Root']; equal(r['supplied_receipt'],None)
    case('missing_selected_receipt_not_a_dangling_graph',missing)
    def alternative(m):
        d=single(); old=pin(d['receipts'][0]); r=deepcopy(d['receipts'][0]); r['id']='Newer'; r['revision']=999; d['receipts'].append(sign(r)); got=rows(m.plan(d))['Root']; equal(got['selected_receipt'],old); equal(got['classification'],MATCH)
    case('unselected_newer_receipt_never_substituted',alternative)
    def stale_task_selection(m):
        d=single(); d['selections'][0]['task']['revision']=2; blocked(m,d,'selection_task_pin_not_current')
    case('stale_task_selection',stale_task_selection)
    def stale_receipt_selection(m):
        d=single(); d['selections'][0]['receipt']['revision']=2; blocked(m,d,'selected_receipt_pin_not_current')
    case('stale_receipt_selection',stale_receipt_selection)
    for direction in ('missing','extra'):
        def run(m,direction=direction):
            d=diamond(); idx=1 if direction=='missing' else 0
            change_receipt(d,lambda r:r['content'].update(dependency_receipts=[] if direction=='missing' else [{'task':pin(d['tasks'][4]),'receipt':pin(d['receipts'][4])}]),index=idx)
            blocked(m,d,'receipt_dependency_set_mismatch',subject=d['tasks'][idx]['id'])
        case('receipt_dependency_set_'+direction,run)
    def wrong_task(m):
        d=diamond(); change_receipt(d,lambda r:r['content'].update(task=pin(d['tasks'][4]))); rs=blocked(m,d,'receipt_task_pin_not_current',propagation=True); truth('dependency_receipt_task_mismatch' in codes(rs['Left']),'wrong upstream task')
    case('wrong_receipt_task_binding',wrong_task)
    def wrong_dep_task(m):
        d=diamond(); change_receipt(d,lambda r:r['content']['dependency_receipts'][0]['task'].update(revision=2),index=1); blocked(m,d,'receipt_dependency_task_pin_mismatch',subject='Left')
    case('wrong_dependency_task_pin',wrong_dep_task)
    def deselect_upstream(m):
        d=diamond(); d['selections']=d['selections'][1:]; rs=blocked(m,d,'prior_receipt_not_selected',propagation=True); truth('dependency_receipt_not_selected_exactly' in codes(rs['Left']),'missing upstream selection')
    case('deselected_upstream_invalidates_diamond',deselect_upstream)
    def policy_propagation(m):
        a=task('Root',role='current_runtime'); b=task('Downstream',[a]); ar=receipt(a); br=receipt(b,[(a,ar)]); rs=rows(m.plan(document([a,b],[ar,br])))
        equal(rs['Downstream']['classification'],FRESH); equal(codes(rs['Downstream']),['dependency_requires_fresh']); equal(rs['Downstream']['fresh_ancestors'],['Root'])
    case('mandatory_fresh_propagates',policy_propagation)
    def false_claims(m):
        d=single(); change_task(d,lambda t:(t['content'].update(inputs=[]),t['content']['environment'].update(description='Fabricated closure and environment; no run happened.')),update_receipt=True)
        report=m.plan(d); equal(rows(report)['Root']['classification'],MATCH)
        for k in FALSES: equal(report[k],False,k)
    case('fabricated_closed_world_positive_trust_boundary',false_claims)
    def omitted_role(m):
        d=single(); change_task(d,lambda t:t['content']['invocation'].update(argv=['python','tools/reproduce_hypothesis_scope_release.py']),update_receipt=True)
        equal(rows(m.plan(d))['Root']['classification'],MATCH)
    case('caller_role_not_inferred_from_command_positive_boundary',omitted_role)
    def literal(m):
        d=single(); change_task(d,lambda t:t['content']['invocation'].update(argv=['not-a-program',';touch /tmp/receipt-must-not-execute','$(not-executed)','']),update_receipt=True)
        equal(rows(m.plan(d))['Root']['classification'],MATCH)
    case('literal_argv_not_interpreted',literal)
    def no_normalization(m):
        a=single(); b=single(); change_task(a,lambda t:t['content']['environment'].update(description='caf\u00e9'),update_receipt=True); change_task(b,lambda t:t['content']['environment'].update(description='cafe\u0301'),update_receipt=True)
        truth(m.plan(a)['input_sha256']!=m.plan(b)['input_sha256'],'Unicode normalization silently applied')
    case('unicode_not_silently_normalized',no_normalization)

    for where in ('task','receipt'):
        for cycle in ('self','diamond','unused'):
            def run(m,where=where,cycle=cycle):
                d=diamond(); idx=0
                if where=='task':
                    target=pin(d['tasks'][0 if cycle=='self' else 3])
                    if cycle=='unused':
                        t=task('Unused'); t['content']['dependencies']=[pin(t)]; d['tasks'].append(sign(t))
                    else: change_task(d,lambda t:t['content'].update(dependencies=[target]))
                else:
                    target=pin(d['receipts'][0 if cycle=='self' else 3]); tt=pin(d['tasks'][0 if cycle=='self' else 3])
                    if cycle=='unused':
                        r=receipt(d['tasks'][0],name='Unused'); r['content']['dependency_receipts']=[{'task':pin(d['tasks'][0]),'receipt':pin(r)}]; d['receipts'].append(sign(r))
                    else: change_receipt(d,lambda r:r['content'].update(dependency_receipts=[{'task':tt,'receipt':target}]))
                reject(m,d,'dependency_cycle',path='$/tasks' if where=='task' else '$/receipts')
            case(f'{where}_cycle_{cycle}',run)
    for target in ('task_dependency','receipt_dependency','receipt_task','receipt_edge_task'):
        def run(m,target=target):
            d=diamond()
            if target=='task_dependency': change_task(d,lambda t:t['content']['dependencies'][0].update(id='Absent'),index=1)
            elif target=='receipt_dependency': change_receipt(d,lambda r:r['content']['dependency_receipts'][0]['receipt'].update(id='Absent'),index=1)
            elif target=='receipt_task': change_receipt(d,lambda r:r['content']['task'].update(id='Absent'))
            else: change_receipt(d,lambda r:r['content']['dependency_receipts'][0]['task'].update(id='Absent'),index=1)
            reject(m,d,'dangling_dependency')
        case('dangling_'+target,run)
    def unused_bad(m):
        d=single(); r=receipt(d['tasks'][0],name='Unused'); r['content']['result']['outcome']='fresh_pass'; d['receipts'].append(sign(r)); reject(m,d,'enum')
    case('unused_malformed_record_rejects_atomically',unused_bad)
    for kind in ('tasks','receipts'):
        def run(m,kind=kind):
            d=single(); d[kind][0]['revision']=2; reject(m,d,'integrity')
        case('unsealed_'+kind+'_revision',run)
        def duplicate(m,kind=kind):
            d=single(); d[kind].append(deepcopy(d[kind][0])); reject(m,d,'duplicate_id')
        case('duplicate_'+kind,duplicate)
    def duplicate_selection(m):
        d=single(); d['selections']*=2; reject(m,d,'duplicate_selection')
    case('duplicate_selection',duplicate_selection)
    def dangling_selection(m):
        d=single(); d['selections'][0]['task']['id']='Absent'; reject(m,d,'dangling_selection')
    case('dangling_selection',dangling_selection)
    for field,mutation,code in [('bytes_boolean',lambda t:t['content']['inputs'][0].update(bytes=True),'integer'),('revision_boolean',lambda t:t.update(revision=True),'integer'),('unknown_role',lambda t:t['content'].update(role='cached'),'enum'),('uppercase_hash',lambda t:t['content']['environment'].update(runner_sha256='A'*64),'hash'),('empty_argv',lambda t:t['content']['invocation'].update(argv=[]),'budget_exceeded'),('blank_program',lambda t:t['content']['invocation'].update(argv=[' ']),'string'),('nul_arg',lambda t:t['content']['invocation']['argv'].append('a\x00b'),'argv'),('too_many_args',lambda t:t['content']['invocation'].update(argv=['a']*33),'budget_exceeded'),('long_arg',lambda t:t['content']['invocation'].update(argv=['a'*1025]),'argv'),('blank_environment',lambda t:t['content']['environment'].update(description='\t '),'string'),('long_environment',lambda t:t['content']['environment'].update(description='x'*1025),'string')]:
        def run(m,mutation=mutation,code=code):
            d=single(); change_task(d,mutation); reject(m,d,code)
        case('semantic_'+field,run)
    def boolean_exit(m):
        d=single(); change_receipt(d,lambda r:r['content']['result'].update(exit_code=False)); reject(m,d,'integer')
    case('semantic_boolean_exit',boolean_exit)
    for path in ['/absolute','a//b','a/./b','a/../b','a\\b','trailing/','a\nb','a\x7fb']:
        def run(m,path=path):
            d=single(); change_task(d,lambda t:t['content']['inputs'][0].update(path=path)); reject(m,d,'path')
        case('invalid_path_'+repr(path),run)
    def manifest_order(m,duplicate):
        d=single(); change_task(d,lambda t:t['content'].update(inputs=[deepcopy(t['content']['inputs'][0])]*2 if duplicate else [{'path':'z','bytes':0,'sha256':'0'*64},{'path':'a','bytes':0,'sha256':'0'*64}])); reject(m,d,'manifest_order')
    case('duplicate_manifest',lambda m:manifest_order(m,True)); case('unsorted_manifest',lambda m:manifest_order(m,False))
    def dep_order(m):
        d=diamond(); change_task(d,lambda t:t['content']['dependencies'].reverse(),index=3); reject(m,d,'dependency_order')
    case('unsorted_dependencies',dep_order)
    for path in [(),('tasks',0),('tasks',0,'content'),('tasks',0,'content','invocation'),('tasks',0,'content','environment'),('tasks',0,'content','closure'),('tasks',0,'content','inputs',0),('receipts',0,'content'),('receipts',0,'content','result'),('selections',0),('selections',0,'task')]:
        for remove in (False,True):
            def run(m,path=path,remove=remove):
                d=single(); target=d
                for key in path: target=target[key]
                if remove: target.pop(next(iter(target)))
                else: target['extra']=None
                if path and path[0] in ('tasks','receipts') and len(path)>2: d[path[0]][0]=sign(d[path[0]][0])
                reject(m,d,'shape')
            case('exact_shape_'+repr(path)+('_remove' if remove else '_add'),run)
    raw_cases=[('float',1.0,'invalid_type'),('nan',float('nan'),'invalid_type'),('inf',float('inf'),'invalid_type'),('tuple',(),'invalid_type'),('bytes',b'{}','invalid_type'),('surrogate_value','\ud800','invalid_string'),('surrogate_key',{'\udfff':1},'invalid_key'),('nonstring_key',{1:2},'invalid_key'),('huge_integer',2**31,'budget_exceeded'),('long_key',{'x'*65:1},'invalid_key'),('long_string','x'*2049,'invalid_string'),('wide_object',{str(i):0 for i in range(17)},'budget_exceeded'),('wide_array',[0]*513,'budget_exceeded')]
    for name,value,code in raw_cases: case('raw_'+name,lambda m,value=value,code=code:reject(m,value,code))
    for typ,value in [(dict,{}),(list,[]),(str,'x'),(int,1)]:
        custom=type('Custom'+typ.__name__,(typ,),{})(value)
        case('subclass_'+typ.__name__,lambda m,custom=custom:reject(m,custom,'invalid_type'))
    def pycycle(m):
        x=[]; x.append(x); reject(m,x,'cyclic_python_value')
    case('cyclic_python_input',pycycle)
    def deep(m):
        x=None
        for _ in range(17): x=[x]
        reject(m,x,'budget_exceeded')
    case('depth_budget',deep)
    case('node_budget',lambda m:reject(m,[[None]*512 for _ in range(65)],'budget_exceeded'))
    def task_count(m):
        ts=[task('T'+str(i)) for i in range(33)]; reject(m,document(ts,[]),'budget_exceeded')
    case('task_count_budget',task_count)
    def receipt_count(m):
        t=task('Root'); reject(m,document([t],[receipt(t,name='R'+str(i)) for i in range(65)],select=False),'budget_exceeded')
    case('receipt_count_budget',receipt_count)
    def aggregate_files(m):
        ts=[]
        for i in range(3):
            t=task('T'+str(i)); t['content']['inputs']=[{'path':'f'+str(n).zfill(3),'bytes':0,'sha256':'0'*64} for n in range(171)]; ts.append(sign(t))
        reject(m,document(ts,[]),'budget_exceeded',path='$/tasks')
    case('aggregate_manifest_budget',aggregate_files)
    def edge_budget(m):
        ts=[]
        for i in range(18): ts.append(task('T'+str(i).zfill(2),ts))
        reject(m,document(ts,[]),'budget_exceeded',path='$')
    case('aggregate_edge_budget',edge_budget)
    def encoded_budget(m):
        ts=[]
        for i in range(8):
            t=task('T'+str(i)); t['content']['invocation']['argv']=['\u0800'*1024]*32; ts.append(sign(t))
        reject(m,document(ts,[]),'budget_exceeded',path='$')
    case('real_utf8_encoded_input_budget',encoded_budget)
    decode=[('duplicate','{"x":1,"x":2}','duplicate_key'),('nested_duplicate','{"x":{"a":1,"a":2}}','duplicate_key'),('escaped_duplicate','{"x":1,"\\u0078":2}','duplicate_key'),('fraction','1.0','invalid_type'),('exponent','1e0','invalid_type'),('nan','NaN','invalid_type'),('infinity','Infinity','invalid_type'),('negative_infinity','-Infinity','invalid_type'),('bad_utf8',b'\xff','invalid_json'),('trailing','{} {}','invalid_json'),('escaped_surrogate','"\\ud800"','invalid_string'),('parse_depth','['*17+'null'+']'*17,'budget_exceeded'),('huge_decimal','9'*100,'budget_exceeded'),('raw_size',b' '*262145,'budget_exceeded')]
    for name,value,code in decode: case('strict_json_'+name,lambda m,value=value,code=code:reject(m,value,code,method='loads'))
    case('strict_json_roundtrip',lambda m:equal(m.loads(canonical(diamond())),diamond()))
    def false_flags_all(m):
        for d in (single(),diamond()):
            report=m.plan(d)
            equal(set(report),set(FALSES)|{'schema','input_sha256','tasks','scope'})
            for key in FALSES: truth(report[key] is False,key+' not literal false')
    case('all_false_nonclaims_literal',false_flags_all)


    def maximum_tasks(m):
        ts=[task('T'+str(i).zfill(2)) for i in range(32)]; report=m.plan(document(ts,[])); equal(len(report['tasks']),32); equal({r['classification'] for r in report['tasks']},{FRESH})
    case('positive_32_tasks',maximum_tasks)

    def unicode_path_scope(m):
        d=single(); change_task(d,lambda t:t['content']['inputs'][0].update(path='a\u0085b'),update_receipt=True); equal(m.plan(d),full_expected(d))
    case('unicode_C1_not_an_ASCII_control_documented_boundary',unicode_path_scope)

    def maximum_receipts(m):
        t=task('Root'); rr=[receipt(t,name='R'+str(i).zfill(2)) for i in range(64)]; report=m.plan(document([t],rr)); equal(rows(report)['Root']['classification'],MATCH); equal(rows(report)['Root']['selected_receipt'],pin(rr[-1]))
    case('positive_64_receipts_exact_selected',maximum_receipts)
    def maximum_files(m):
        ts=[]
        for i in range(2):
            t=task('T'+str(i)); t['content']['inputs']=[{'path':'f'+str(j).zfill(3),'bytes':0,'sha256':bytesha(b'')} for j in range(256)]; ts.append(sign(t))
        d=document(ts,[receipt(t) for t in ts]); equal(m.plan(d),full_expected(d))
    case('positive_512_files_256_per_task',maximum_files)
    def maximum_edges(m):
        ts=[]; rr=[]
        for i in range(17):
            selected=list(range(i)) if i<16 else list(range(8)); t=task('T'+str(i).zfill(2),[ts[j] for j in selected]); r=receipt(t,[(ts[j],rr[j]) for j in selected]); ts.append(t); rr.append(r)
        d=document(ts,rr); equal(sum(len(t['content']['dependencies']) for t in ts),128); equal(m.plan(d),full_expected(d))
    case('positive_128_task_and_receipt_edges',maximum_edges)
    def receipt_edges_over(m):
        ts=[task('T'+str(i).zfill(2)) for i in range(17)]; rr=[]
        for i,t in enumerate(ts):
            selected=list(range(i)) if i<16 else list(range(9)); rr.append(receipt(t,[(ts[j],rr[j]) for j in selected]))
        reject(m,document(ts,rr),'budget_exceeded',path='$')
    case('receipt_129_edges_rejected',receipt_edges_over)
    case('positive_exact_raw_byte_limit',lambda m:equal(m.loads(' '*(262144-2)+'{}'),{}))
    def depth_edge(m):
        x=None
        for _ in range(16): x=[x]
        equal(m.loads('['*16+'null'+']'*16),x)
    case('positive_exact_raw_depth_limit',depth_edge)
    def output_guard(m):
        old=m.MAX_OUTPUT_BYTES
        try:
            m.MAX_OUTPUT_BYTES=10; reject(m,single(),'budget_exceeded',path='$')
        finally: m.MAX_OUTPUT_BYTES=old
    case('output_budget_guard_reduced_threshold_only',output_guard)


def load_core(lab):
    spec=importlib.util.spec_from_file_location('independent_target',lab/'validation_receipt/core.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def run(lab):
    module=load_core(lab); register(); results=[]
    for name,fn in CASES:
        try: fn(module); results.append({'name':name,'status':'passed'})
        except Exception as exc: results.append({'name':name,'status':'failed','exception':type(exc).__name__,'message':str(exc)})
    # Run CLI without importing author fixtures. Validate valid FRESH still exits zero.
    d=single(); d['selections']=[]
    for opt in ([],['-O']):
        for label,data,args,code,expected in [('fresh_report',canonical(d),[],0,None),('malformed',b'{bad',[],2,'invalid_json'),('extra_argument',b'{}',['--execute'],2,'arguments'),('oversized',b' '*262145,[],2,'budget_exceeded')]:
            name='cli_'+('optimized_' if opt else 'normal_')+label
            try:
                cp=subprocess.run([sys.executable,'-B',*opt,'-m','validation_receipt',*args],input=data,cwd=lab,capture_output=True,timeout=10)
                equal(cp.returncode,code); equal(cp.stderr,b''); decoded=json.loads(cp.stdout)
                if expected: equal(decoded['code'],expected); truth('tasks' not in decoded,'partial classifications on error')
                else: equal(decoded,module.plan(d)); equal(rows(decoded)['Root']['classification'],FRESH)
                results.append({'name':name,'status':'passed'})
            except Exception as exc: results.append({'name':name,'status':'failed','exception':type(exc).__name__,'message':str(exc)})
    try:
        tree=ast.parse((lab/'validation_receipt/core.py').read_text()); imports={n.name for node in ast.walk(tree) if isinstance(node,ast.Import) for n in node.names}; equal(imports,{'hashlib','json','re'}); truth(not any(isinstance(n,ast.ImportFrom) for n in ast.walk(tree)),'unexpected import from'); truth(not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in {'open','eval','exec','__import__','compile'} for n in ast.walk(tree)),'effectful builtin'); results.append({'name':'reviewed_core_static_io_surface','status':'passed'})
    except Exception as exc: results.append({'name':'reviewed_core_static_io_surface','status':'failed','exception':type(exc).__name__,'message':str(exc)})
    return {'schema':'independent-receipt-planner-review/1','optimized':not __debug__,'core_sha256':bytesha((lab/'validation_receipt/core.py').read_bytes()),'independent_cases':len(results),'passed':sum(r['status']=='passed' for r in results),'failed':sum(r['status']=='failed' for r in results),'results':results,'scope':'Contract probes only; not proof, actual gate replay, closure/authenticity certificate, cache implementation, or skip authorization.'}

def main():
    p=argparse.ArgumentParser(); p.add_argument('lab',type=Path); p.add_argument('--output',type=Path); args=p.parse_args(); result=run(args.lab.resolve()); text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if args.output: args.output.write_text(text)
    else: print(text,end='')
    print(f"{result['passed']}/{result['independent_cases']} independent cases passed; {result['failed']} failed",file=sys.stderr)
    return bool(result['failed'])

if __name__=='__main__': sys.exit(main())
