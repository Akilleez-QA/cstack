# Independent review harnesses

These reviewer-authored files are byte-preserved, use independent fixtures and
canonical hashing, and do not import the author's tests or fixture builders.

- `verify.py`: 181 bounded contract cases, including 120 registry permutations,
  complete independently constructed expected reports, explicit fresh-policy
  behavior, exact dependency invalidation, malformed inputs, positive hard limits,
  CLI behavior, literal false non-claims, and static core I/O surface.
- `mutations.py`: 17 independent semantic guard mutants on temporary source copies.
  A kill requires successful planner output followed by an explicit semantic
  assertion failure. Crashes and incidental exceptions are not counted as kills.

```sh
python -B review/verify.py .
python -B -O review/verify.py .
python -B review/mutations.py .
python -B -O review/mutations.py .
```

`tools/validate.py` runs all four commands in the original and clean selected-only
lab. Review neither runs nor changes the actual Foundation Math gates. No proof,
authenticity, closure-completeness, or workflow-adoption conclusion follows.

The reviewed implementation SHA256 is
`9508bc57c57fa79bf31d538df48a08549b720f6a9e83935650f80371639c3305`.
The only author correction from review clarified that path rejection covers ASCII
control characters U+0000..001F and U+007F, not every Unicode control category.
The implementation did not change.
