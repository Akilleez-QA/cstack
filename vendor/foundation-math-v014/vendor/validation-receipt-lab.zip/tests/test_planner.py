import ast
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

from validation_receipt import PlanError, canonical_bytes, digest, loads, pin, plan, seal
from validation_receipt import core
from tests.fixtures import chain, document, policy_example, receipt, replace_receipt, replace_task, reseal, task

ROOT = Path(__file__).resolve().parents[1]
MATCH = 'PRIOR_PINNED_EVIDENCE_MATCHES'
FRESH = 'MUST_RUN_FRESH'


def rows(doc):
    return {r['task']['id']: r for r in plan(doc)['tasks']}


def codes(row):
    return {r['code'] for r in row['reasons']}


class PlannerTests(unittest.TestCase):
    def test_complete_matching_chain(self):
        report = plan(chain())
        self.assertEqual({r['classification'] for r in report['tasks']}, {MATCH})
        self.assertFalse(report['fresh_pass_claimed'])
        self.assertFalse(report['execution_performed'])
        self.assertFalse(report['skip_authorized'])
        self.assertTrue(all(v is False for k, v in report.items() if k.endswith(('_verified', '_checked', '_changed'))))

    def test_registry_order_deterministic_and_pure(self):
        d = chain(); before = deepcopy(d); baseline = plan(d)
        for k in ('tasks', 'receipts', 'selections'):
            d[k].reverse()
        self.assertEqual(plan(d), baseline)
        self.assertEqual(plan(before), baseline)
        self.assertEqual(chain(), before)

    def test_all_mandatory_roles_fresh_even_with_matching_evidence(self):
        d = policy_example(); got = rows(d)
        self.assertEqual(sum(r['classification'] == FRESH for r in got.values()), 5)
        for t in d['tasks']:
            r = got[t['id']]
            if t['content']['role'] in core.MANDATORY_FRESH:
                self.assertEqual(r['classification'], FRESH)
                self.assertIn('mandatory_fresh_policy', codes(r))
            else:
                self.assertEqual(r['classification'], MATCH)

    def test_archival_is_not_historical_evidence_reference(self):
        historic = task('prior.archival.evidence')
        archival = task('requested.fresh.archival', role='archival_full_replay')
        # Even identical argv does not erase the explicit fresh-task obligation.
        archival['content']['invocation'] = deepcopy(historic['content']['invocation'])
        archival = reseal(archival)
        d = document([historic, archival], [receipt(historic), receipt(archival)])
        self.assertEqual(rows(d)['prior.archival.evidence']['classification'], MATCH)
        self.assertEqual(rows(d)['requested.fresh.archival']['classification'], FRESH)

    def test_task_semantic_mutations_invalidate_exact_receipt(self):
        mutations = [
            lambda t: t.update(revision=2),
            lambda t: t['content'].update(role='current_runtime'),
            lambda t: t['content']['invocation']['argv'].append('--different'),
            lambda t: t['content']['invocation']['argv'].reverse(),
            lambda t: t['content']['invocation'].update(cwd='other'),
            lambda t: t['content']['invocation'].update(stdin_sha256=digest('other')),
            lambda t: t['content']['inputs'][0].update(sha256=digest('other')),
            lambda t: t['content']['inputs'][0].update(bytes=8),
            lambda t: t['content']['inputs'][0].update(path='other.txt'),
            lambda t: t['content']['inputs'].clear(),
            lambda t: t['content']['environment'].update(runner_sha256=digest('other')),
            lambda t: t['content']['environment'].update(environment_sha256=digest('other')),
            lambda t: t['content']['environment'].update(description='Changed environment interpretation'),
            lambda t: t['content']['closure'].update(clock='unknown'),
        ]
        for mutate in mutations:
            with self.subTest(mutation=mutate):
                d = chain(); replace_task(d, 0, mutate)
                got = rows(d)
                self.assertEqual([got[x]['classification'] for x in ('historical.base', 'historical.middle', 'historical.top', 'unrelated')], [FRESH, FRESH, FRESH, MATCH])
                self.assertIn('receipt_task_pin_not_current', codes(got['historical.base']))
                self.assertEqual(got['historical.top']['fresh_ancestors'], ['historical.base', 'historical.middle'])

    def test_unknown_pins_or_closure_never_match_even_resealed_receipt(self):
        mutations = [lambda t: t['content']['invocation'].update(stdin_sha256=None), lambda t: t['content']['inputs'][0].update(sha256=None)]
        mutations += [lambda t, k=k: t['content']['environment'].update({k: None}) for k in ('runner_sha256', 'environment_sha256')]
        mutations += [lambda t, k=k: t['content']['closure'].update({k: 'unknown'}) for k in ('declaration', 'files', 'process_state', 'external_state', 'randomness', 'clock')]
        for mutate in mutations:
            with self.subTest(mutation=mutate):
                d = chain(); t = replace_task(d, 0, mutate)
                replace_receipt(d, 0, lambda r: r['content'].update(task=pin(t)))
                self.assertEqual(rows(d)[t['id']]['classification'], FRESH)

    def test_prior_result_mutations(self):
        for field, value, expected in [('outcome', 'declared_fail', 'prior_result_not_declared_pass'), ('outcome', 'unknown', 'prior_result_not_declared_pass'), ('exit_code', None, 'prior_result_not_declared_pass'), ('exit_code', 1, 'prior_result_not_declared_pass'), ('output_sha256', None, 'prior_output_pin_unknown')]:
            with self.subTest(field=field, value=value):
                d = chain(); replace_receipt(d, 0, lambda r: r['content']['result'].update({field: value}))
                got = rows(d)
                self.assertIn(expected, codes(got['historical.base']))
                self.assertEqual(got['historical.top']['classification'], FRESH)
                self.assertEqual(got['unrelated']['classification'], MATCH)

    def test_output_drift_requires_exact_selection_and_downstream_rebinding(self):
        d = chain(); replace_receipt(d, 0, lambda r: r['content']['result'].update(output_sha256=digest('changed')), False)
        got = rows(d)
        self.assertIn('selected_receipt_pin_not_current', codes(got['historical.base']))
        self.assertEqual(got['historical.top']['classification'], FRESH)
        d = chain(); replace_receipt(d, 0, lambda r: r['content']['result'].update(output_sha256=digest('changed')))
        got = rows(d)
        self.assertEqual(got['historical.base']['classification'], MATCH)
        self.assertIn('dependency_receipt_pin_not_current', codes(got['historical.middle']))
        self.assertIn('dependency_receipt_not_selected_exactly', codes(got['historical.middle']))
        self.assertEqual(got['historical.top']['classification'], FRESH)

    def test_withdrawal_transitive(self):
        d = chain(); replace_receipt(d, 0, lambda r: r['content'].update(availability='withdrawn'))
        got = rows(d)
        self.assertIn('prior_receipt_withdrawn', codes(got['historical.base']))
        self.assertEqual(got['historical.top']['classification'], FRESH)

    def test_no_selection_never_looks_up_latest(self):
        d = chain(); d['selections'] = []
        self.assertTrue(all(r['classification'] == FRESH for r in rows(d).values()))
        self.assertIn('prior_receipt_not_selected', codes(rows(d)['historical.base']))

    def test_missing_selected_receipt_is_fresh(self):
        d = chain(); d['selections'][0]['receipt']['id'] = 'missing'
        self.assertIn('selected_receipt_not_supplied', codes(rows(d)['historical.base']))

    def test_stale_selection_task_is_fresh(self):
        d = chain(); d['selections'][0]['task']['revision'] = 2
        self.assertIn('selection_task_pin_not_current', codes(rows(d)['historical.base']))

    def test_newer_receipt_not_automatically_chosen(self):
        d = chain(); r = deepcopy(d['receipts'][0]); r['id'] = 'another.base'; r['revision'] = 2
        d['receipts'].append(reseal(r))
        result = rows(d)['historical.base']
        self.assertEqual(result['selected_receipt'], d['selections'][0]['receipt'])
        self.assertEqual(result['classification'], MATCH)

    def test_receipt_bound_to_wrong_task(self):
        d = chain(); replace_receipt(d, 0, lambda r: r['content'].update(task=pin(d['tasks'][3])))
        got = rows(d)
        self.assertIn('receipt_task_pin_not_current', codes(got['historical.base']))
        self.assertIn('dependency_receipt_task_mismatch', codes(got['historical.middle']))

    def test_missing_and_extra_dependency_receipts(self):
        d = chain(); replace_receipt(d, 1, lambda r: r['content'].update(dependency_receipts=[]))
        self.assertIn('receipt_dependency_set_mismatch', codes(rows(d)['historical.middle']))
        d = chain(); replace_receipt(d, 0, lambda r: r['content']['dependency_receipts'].append({'task': pin(d['tasks'][3]), 'receipt': pin(d['receipts'][3])}))
        self.assertIn('receipt_dependency_set_mismatch', codes(rows(d)['historical.base']))

    def test_receipt_dependency_task_pin_change(self):
        d = chain(); replace_receipt(d, 1, lambda r: r['content']['dependency_receipts'][0]['task'].update(revision=2))
        self.assertIn('receipt_dependency_task_pin_mismatch', codes(rows(d)['historical.middle']))

    def test_unselected_dependency_receipt(self):
        d = chain(); d['selections'].pop(0)
        self.assertIn('dependency_receipt_not_selected_exactly', codes(rows(d)['historical.middle']))

    def test_mandatory_dependency_blocks_otherwise_matching_historical_task(self):
        a = task('fresh', role='current_runtime'); b = task('historical', [a]); ar = receipt(a); br = receipt(b, [ar])
        got = rows(document([a, b], [ar, br]))
        self.assertEqual(got['historical']['classification'], FRESH)
        self.assertEqual(got['historical']['fresh_ancestors'], ['fresh'])

    def test_diamond_full_transitive_invalidation(self):
        a = task('a'); b = task('b', [a]); c = task('c', [a]); d = task('d', [b, c]); u = task('u')
        ar = receipt(a); br = receipt(b, [ar]); cr = receipt(c, [ar]); dr = receipt(d, [br, cr]); ur = receipt(u)
        doc = document([a, b, c, d, u], [ar, br, cr, dr, ur])
        replace_receipt(doc, 0, lambda r: r['content'].update(availability='withdrawn'))
        got = rows(doc)
        self.assertEqual(got['d']['fresh_dependencies'], ['b', 'c'])
        self.assertEqual(got['d']['fresh_ancestors'], ['a', 'b', 'c'])
        self.assertEqual(got['u']['classification'], MATCH)

    def test_false_caller_assertions_can_match(self):
        # A positive trust-boundary control, not validation of these invented facts.
        d = chain(); replace_task(d, 3, lambda t: t['content']['environment'].update(description='I fabricated this entire closed environment.'))
        replace_receipt(d, 3, lambda r: r['content'].update(task=pin(d['tasks'][3])))
        self.assertEqual(rows(d)['unrelated']['classification'], MATCH)
        self.assertFalse(plan(d)['closure_verified'])

    def test_ordinary_shell_metacharacters_are_data(self):
        d = chain(); t = replace_task(d, 3, lambda t: t['content']['invocation'].update(argv=['fixture-runner', '; touch /tmp/not-created', '', '$(anything)']))
        replace_receipt(d, 3, lambda r: r['content'].update(task=pin(t)))
        self.assertEqual(rows(d)['unrelated']['classification'], MATCH)

    def test_empty_selected_manifest_is_explicit_not_missing(self):
        t = task('closed.no.files'); t['content']['inputs'] = []; t = reseal(t)
        self.assertEqual(rows(document([t], [receipt(t)]))[t['id']]['classification'], MATCH)

    def test_report_output_limit(self):
        with patch.object(core, 'MAX_OUTPUT_BYTES', 10):
            with self.assertRaises(PlanError) as cm:
                plan(chain())
        self.assertEqual(cm.exception.code, 'budget_exceeded')


class RejectionTests(unittest.TestCase):
    def reject(self, doc, code=None):
        with self.assertRaises(PlanError) as cm:
            plan(doc)
        if code:
            self.assertEqual(cm.exception.code, code)

    def test_task_cycles_even_stale(self):
        d = chain(); replace_task(d, 0, lambda t: t['content']['dependencies'].append(pin(d['tasks'][2])))
        self.reject(d, 'dependency_cycle')

    def test_receipt_cycles_even_stale(self):
        d = chain(); replace_receipt(d, 0, lambda r: r['content']['dependency_receipts'].append({'task': pin(d['tasks'][2]), 'receipt': pin(d['receipts'][2])}))
        self.reject(d, 'dependency_cycle')

    def test_task_and_receipt_dangling_dependencies(self):
        d = chain(); replace_task(d, 1, lambda t: t['content']['dependencies'][0].update(id='missing'))
        self.reject(d, 'dangling_dependency')
        d = chain(); replace_receipt(d, 1, lambda r: r['content']['dependency_receipts'][0]['receipt'].update(id='missing'))
        self.reject(d, 'dangling_dependency')
        d = chain(); replace_receipt(d, 1, lambda r: r['content'].update(task={**r['content']['task'], 'id': 'missing'}))
        self.reject(d, 'dangling_dependency')

    def test_malformed_unused_receipt_also_rejects(self):
        d = chain(); r = deepcopy(d['receipts'][3]); r['id'] = 'unused'; r['content']['result']['outcome'] = 'actually_proved'
        d['receipts'].append(reseal(r)); self.reject(d, 'enum')

    def test_integrity(self):
        d = chain(); d['tasks'][0]['content']['invocation']['argv'].append('drift')
        self.reject(d, 'integrity')
        d = chain(); d['receipts'][0]['content']['result']['output_sha256'] = '0'*64
        self.reject(d, 'integrity')

    def test_missing_unknown_fields_every_object_level(self):
        base = chain()
        paths = [(), ('tasks', 0), ('tasks', 0, 'content'), ('tasks', 0, 'content', 'invocation'), ('tasks', 0, 'content', 'environment'), ('tasks', 0, 'content', 'closure'), ('tasks', 0, 'content', 'inputs', 0), ('receipts', 0), ('receipts', 0, 'content'), ('receipts', 0, 'content', 'result'), ('selections', 0), ('selections', 0, 'task')]
        for path in paths:
            for remove in (False, True):
                with self.subTest(path=path, remove=remove):
                    d = deepcopy(base); target = d
                    for k in path:
                        target = target[k]
                    if remove:
                        target.pop(next(iter(target)))
                    else:
                        target['unexpected'] = None
                    self.reject(d)

    def test_strict_semantic_types_and_enums(self):
        for mutate in [lambda t: t['content']['inputs'][0].update(bytes=True), lambda t: t['content'].update(role='cache'), lambda t: t['content']['environment'].update(runner_sha256='A'*64), lambda t: t['content']['closure'].update(clock=True), lambda t: t['content']['invocation'].update(argv=[]), lambda t: t['content']['invocation'].update(cwd='/tmp'), lambda t: t['content']['inputs'][0].update(path='../escape'), lambda t: t['content']['inputs'][0].update(path='a//b')]:
            d = chain(); replace_task(d, 0, mutate); self.reject(d)

    def test_duplicate_ids_selections_and_manifest(self):
        d = chain(); d['tasks'].append(d['tasks'][0]); self.reject(d, 'duplicate_id')
        d = chain(); d['receipts'].append(d['receipts'][0]); self.reject(d, 'duplicate_id')
        d = chain(); d['selections'].append(d['selections'][0]); self.reject(d, 'duplicate_selection')
        d = chain(); replace_task(d, 0, lambda t: t['content']['inputs'].append(deepcopy(t['content']['inputs'][0]))); self.reject(d, 'manifest_order')

    def test_duplicate_dependency_and_selection_target(self):
        d = chain(); replace_task(d, 1, lambda t: t['content']['dependencies'].append(deepcopy(t['content']['dependencies'][0]))); self.reject(d, 'dependency_order')
        d = chain(); d['selections'][0]['task']['id'] = 'absent'; self.reject(d, 'dangling_selection')

    def test_raw_rejections(self):
        class D(dict): pass
        class I(int): pass
        class S(str): pass
        for value in [1.0, float('nan'), (1,), D(), I(1), S('str'), {'x': '\ud800'}, {'x': 2**31}, {1: 'value'}, b'{}']:
            with self.subTest(value=repr(value)):
                self.reject(value)
        cyclic = []; cyclic.append(cyclic); self.reject(cyclic, 'cyclic_python_value')

    def test_raw_budgets(self):
        value = None
        for _ in range(18): value = [value]
        self.reject(value, 'budget_exceeded')
        self.reject([None]*513, 'budget_exceeded')
        self.reject({str(i): 0 for i in range(17)}, 'budget_exceeded')
        self.reject('x'*2049, 'invalid_string')
        self.reject([[None]*512 for _ in range(65)], 'budget_exceeded')

    def test_task_count_and_encoded_input_budget(self):
        tasks = [task('t' + str(i)) for i in range(33)]
        self.reject(document(tasks, [receipt(t) for t in tasks]), 'budget_exceeded')
        with patch.object(core, 'MAX_INPUT_BYTES', 10):
            self.reject(chain(), 'budget_exceeded')

    def test_edge_and_file_aggregate_budgets(self):
        ts = []
        for i in range(18):
            ts.append(task('t' + str(i).zfill(2), ts))
        self.reject(document(ts, []), 'budget_exceeded')
        ts = []
        for i in range(3):
            t = task('t' + str(i)); t['content']['inputs'] = [{'path': 'f' + str(j).zfill(3), 'bytes': 0, 'sha256': '0'*64} for j in range(180)]; ts.append(reseal(t))
        self.reject(document(ts, []), 'budget_exceeded')

    def test_loads_strict(self):
        for value in [b'\xff', '{"x":1,"x":2}', '{"x":1.0}', '{"x":NaN}', '{} {}', '"\\ud800"', '['*2000 + ']'*2000, '1'*5000]:
            with self.subTest(value=value[:25]):
                with self.assertRaises(PlanError):
                    loads(value)
        with self.assertRaises(PlanError):
            loads(b' '*262145)
        self.assertEqual(loads(canonical_bytes(chain())), chain())


class SurfaceTests(unittest.TestCase):
    def test_core_import_surface(self):
        tree = ast.parse((ROOT/'validation_receipt/core.py').read_text())
        modules = {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names}
        self.assertEqual(modules, {'hashlib', 'json', 're'})
        self.assertFalse(any(isinstance(n, ast.ImportFrom) for n in ast.walk(tree)))
        forbidden = {'open', 'exec', 'eval', 'compile', '__import__'}
        self.assertFalse(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in forbidden for n in ast.walk(tree)))

    def test_cli_success_and_reject(self):
        result = subprocess.run([sys.executable, '-B', '-m', 'validation_receipt'], input=canonical_bytes(chain()), cwd=ROOT, capture_output=True, timeout=10)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(json.loads(result.stdout), plan(chain()))
        for args, data in [([], b'{bad'), (['arbitrary-command'], b'{}'), ([], b' '*262145)]:
            result = subprocess.run([sys.executable, '-B', '-m', 'validation_receipt', *args], input=data, cwd=ROOT, capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(json.loads(result.stdout)['schema'], 'foundation-math-validation-receipt-error/1')

    def test_checked_in_examples_have_exact_expected_outputs(self):
        filenames = sorted((ROOT/'examples').glob('*.input.json'))
        self.assertEqual(len(filenames), 7)
        for filename in filenames:
            expected = filename.with_name(filename.name.replace('.input.', '.expected.'))
            self.assertEqual(plan(loads(filename.read_bytes())), loads(expected.read_bytes()))


if __name__ == '__main__':
    unittest.main()
