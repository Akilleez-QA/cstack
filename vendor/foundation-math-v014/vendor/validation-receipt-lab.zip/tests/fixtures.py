"""Fictional caller-authored documents. These do not attest to any actual run."""
from copy import deepcopy
from validation_receipt import digest, pin, seal
from validation_receipt.core import SCHEMA


def task(identifier, dependencies=(), role='historical_component'):
    return seal({'id': identifier, 'revision': 1, 'content': {
        'role': role,
        'invocation': {'argv': ['fixture-runner', identifier, '--mode=normal'], 'cwd': '.', 'stdin_sha256': digest('synthetic empty stdin')},
        'inputs': [{'path': 'fixtures/' + identifier + '.txt', 'bytes': 7, 'sha256': digest('synthetic ' + identifier)}],
        'environment': {'runner_sha256': digest('fictional runner image'), 'environment_sha256': digest('fictional environment, no undeclared inputs'), 'description': 'Fictional fixed environment; not a measurement of this machine.'},
        'closure': {'declaration': 'caller_declares_complete', 'files': 'exact_selected_manifest', 'process_state': 'pinned_environment_and_stdin', 'external_state': 'none', 'randomness': 'none', 'clock': 'none'},
        'dependencies': sorted([pin(d) for d in dependencies], key=lambda p: p['id']),
    }})


def receipt(t, dependencies=()):
    return seal({'id': 'receipt.' + t['id'], 'revision': 1, 'content': {
        'task': pin(t), 'availability': 'supplied',
        'result': {'outcome': 'declared_pass', 'exit_code': 0, 'output_sha256': digest('fictional output ' + t['id'])},
        'dependency_receipts': sorted([{'task': r['content']['task'], 'receipt': pin(r)} for r in dependencies], key=lambda p: p['task']['id']),
    }})


def document(tasks, receipts):
    by_task = {r['content']['task']['id']: r for r in receipts}
    return {'schema': SCHEMA, 'tasks': tasks, 'receipts': receipts, 'selections': [
        {'task': pin(t), 'receipt': pin(by_task[t['id']])} for t in tasks if t['id'] in by_task]}


def chain():
    a = task('historical.base'); b = task('historical.middle', [a]); c = task('historical.top', [b]); u = task('unrelated')
    ar = receipt(a); br = receipt(b, [ar]); cr = receipt(c, [br]); ur = receipt(u)
    return document([a, b, c, u], [ar, br, cr, ur])


def policy_example():
    doc = chain()
    for name, role in [('archival.full.replay', 'archival_full_replay'), ('runtime.normal', 'current_runtime'), ('runtime.optimized', 'current_runtime'), ('adapter.normal', 'new_adapter'), ('adapter.optimized', 'new_adapter')]:
        t = task(name, role=role); r = receipt(t)
        doc['tasks'].append(t); doc['receipts'].append(r); doc['selections'].append({'task': pin(t), 'receipt': pin(r)})
    return doc


def reseal(record):
    return seal({k: deepcopy(record[k]) for k in ('id', 'revision', 'content')})


def replace_task(doc, index, mutate, update_selection=True):
    t = deepcopy(doc['tasks'][index]); mutate(t); t = reseal(t); doc['tasks'][index] = t
    if update_selection:
        for s in doc['selections']:
            if s['task']['id'] == t['id']:
                s['task'] = pin(t)
    return t


def replace_receipt(doc, index, mutate, update_selection=True):
    r = deepcopy(doc['receipts'][index]); mutate(r); r = reseal(r); doc['receipts'][index] = r
    if update_selection:
        for s in doc['selections']:
            if s['receipt']['id'] == r['id']:
                s['receipt'] = pin(r)
    return r
