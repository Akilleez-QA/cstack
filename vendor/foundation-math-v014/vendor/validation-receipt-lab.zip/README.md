# Foundation Math validation-receipt planning lab

Local, standalone, planner-only experiment. **Not a release, gate change, cache,
executor, proof checker, or permission to skip a check.** It has no connection to
Foundation Math's sixteen runtime tools or proof-acceptance path.

The observed v0.13 delivery gate took **1,590.072 seconds**. Its saved evidence
contains repeated historical replay suites. That motivates investigating explicit
receipt applicability, not a claim of measured speedup or evidence that any input
boundary is complete. The historical gate has not been rerun or modified here.

## One bounded question

Given an explicitly supplied task snapshot, exact prior receipt selections, and a
caller-declared closed input boundary, does each task's prior pinned evidence still
match syntactically, or must it run fresh?

- `PRIOR_PINNED_EVIDENCE_MATCHES`: selected, internally consistent prior evidence
  matches the exact declared task and all required dependency pins. **Not a fresh
  pass**, an authentic execution, verified closure, mathematical truth, or skip
  authorization.
- `MUST_RUN_FRESH`: policy requires fresh execution, or some required declaration,
  pin, prior result, selection, or dependency does not match. This does not execute
  the task or promise that a fresh execution will pass.
- Malformed, over-budget, cyclic, or dangling dependency documents are rejected
  atomically, with no partial report.

## Try it

All commands below run this lab only, without network or external packages:

```sh
python -B -m validation_receipt < examples/mandatory-fresh-policy.input.json
python -B -m unittest discover -s tests -v
python -B -O -m unittest discover -s tests -v
python -B tools/validate.py
```

Examples are entirely fictional and explicitly caller-authored. Their hashes are
synthetic and their claimed passes are not execution evidence. The source delivery
and timing receipts under `reference/` are design evidence only; this lab does not
convert them into reusable planner receipts or infer missing environments/closure.

## Fresh replay versus referencing historical evidence

A requested `archival_full_replay` is always fresh. So are `current_runtime` and
`new_adapter`, in normal and optimized modes. Only a separately named
`historical_component` task can receive the prior-evidence classification. Even
matching evidence cannot waive an explicit fresh replay obligation.

The full v0.13 archival delivery command remains, unchanged:

```sh
python -B tools/reproduce_hypothesis_scope_release.py
```

The current full aggregate remains:

```sh
PYTHONDONTWRITEBYTECODE=1 python -B tools/run_hypothesis_scope_validation.py
```

Run those in the original v0.13 tree if a fresh v0.13 result is wanted. They are not
run by this lab. No historical command, check, source copy, runtime test, adapter
test, or acceptance condition has been removed. A routine plan may separately
reference immutable historical evidence, but this is not approval to replace or
omit an archival replay that the actual workflow requires. Adoption would require
separate review and explicit authorization to change that workflow.

Read [the contract](docs/CONTRACT.md), [design provenance](docs/DESIGN.md), and
[example guide](examples/README.md). The precise runtime authority is
`validation_receipt/core.py`; `schema/input.schema.json` is structural documentation.
