# Complete bounded examples

Every `*.input.json` is a standalone complete document. Its sibling
`*.expected.json` is the exact deterministic planner result. These are fictional,
caller-authored test records, **not receipts for any actual execution**. The runner,
environment, stdin, input and output hashes are synthetic. No missing context is
obtained from v0.13 or another tree. A matching classification only tests this lab's
syntactic contract.

- `all-pins-match`: three historical components in a dependency chain and one
  unrelated component; all four classify as prior pinned evidence matches.
- `mandatory-fresh-policy`: the same four, plus an explicit full archival replay,
  normal/optimized current-runtime checks and normal/optimized new-adapter checks.
  Those five remain fresh despite internally matching prior receipts. A historical
  evidence reference and a requested full fresh replay are separate task identities.
- `input-drift-chain`: changed leaf argv with a new exact task hash, but no invented
  new run. All three linked tasks are fresh; the unrelated task still matches.
- `unknown-environment-chain`: unavailable environment identity blocks the leaf and
  its full downstream chain, not the unrelated component.
- `withdrawn-receipt-chain`: withdrawing the explicitly selected leaf evidence blocks
  the chain. It does not assert that the old result was mathematically false.
- `no-implicit-latest`: all receipt records remain present, but all selections are
  absent. Every task is fresh; no apparently suitable evidence is chosen implicitly.
- `unestablished-closure-chain`: a caller who cannot assert a closed boundary marks
  it unknown. The chain is fresh, even though manifests and other pins are present.

`tools/generate_assets.py` deterministically rebuilds these complete examples and
the structural JSON Schema from the pinned local fixtures. Tests also cover failed
or unknown results, changed output hashes, stale selection pins, dependency receipt
substitution, missing selected evidence, cycles/dangling references, false authored
closure, full diamond invalidation and bounded rejection cases.
