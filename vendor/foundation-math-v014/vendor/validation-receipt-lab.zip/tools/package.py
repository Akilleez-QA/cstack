"""Deterministic selected-source lab artifact, trusted single-writer workspace only."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
STAMP = (2026, 1, 1, 0, 0, 0)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def name(value):
    require(type(value) is str and value and '\\' not in value and not value.startswith('/'), 'invalid selected name')
    require(str(PurePosixPath(value)) == value and all(p not in ('', '.', '..') for p in value.split('/')), 'invalid selected path')
    return value


def read(root, relative):
    name(relative)
    target = root
    for part in relative.split('/'):
        target = target/part
        require(not target.is_symlink(), 'symlink input rejected')
    info = target.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'nonregular/hardlink input rejected')
    return target.read_bytes()


def selection(root):
    names = json.loads(read(root, 'SELECTED-FILES.json'))
    require(type(names) is list and names == sorted(set(names)), 'selection must be sorted and unique')
    require('SELECTED-FILES.json' in names and 'SOURCE-MANIFEST.json' not in names, 'selection self-binding rules')
    for value in names:
        name(value)
    return names


def snapshot(root):
    return {'schema': 'foundation-math-validation-receipt-lab-source/1', 'files': {
        relative: {'bytes': len(data), 'sha256': sha(data)}
        for relative in selection(root) for data in [read(root, relative)]}}


def verify(root):
    data = read(root, 'SOURCE-MANIFEST.json')
    manifest = json.loads(data)
    require(data == canonical(manifest), 'manifest encoding differs')
    require(manifest == snapshot(root), 'selected source drift')
    return manifest


def build(root, output):
    manifest = verify(root)
    names = sorted([*manifest['files'], 'SOURCE-MANIFEST.json'])
    # Exclusive creation. No existing artifact is silently overwritten.
    with output.open('xb') as stream:
        with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_STORED) as archive:
            for relative in names:
                info = zipfile.ZipInfo(relative, STAMP)
                info.create_system = 3; info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_STORED
                archive.writestr(info, read(root, relative))
    data = output.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data), 'files': len(names), 'source_manifest_sha256': sha(read(root, 'SOURCE-MANIFEST.json'))}


def extract(archive_path, target):
    target.mkdir()
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        require(names == sorted(set(names)), 'duplicate/unsorted archive inventory')
        for info in archive.infolist():
            name(info.filename)
            require(info.date_time == STAMP and info.create_system == 3 and info.external_attr == 0o100644 << 16 and info.compress_type == zipfile.ZIP_STORED, 'archive metadata differs')
            path = target/info.filename; path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read(info))
    manifest = verify(target)
    require(names == sorted([*manifest['files'], 'SOURCE-MANIFEST.json']), 'archive selection differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write-manifest', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.write_manifest:
        (ROOT/'SOURCE-MANIFEST.json').write_bytes(canonical(snapshot(ROOT)))
    if args.output:
        print(json.dumps(build(ROOT, args.output), sort_keys=True))
    elif not args.write_manifest:
        print(json.dumps({'source_manifest_sha256': sha(read(ROOT, 'SOURCE-MANIFEST.json')), 'files': len(verify(ROOT)['files'])}, sort_keys=True))


if __name__ == '__main__':
    main()
