"""Build structural schema and complete synthetic examples, never execution receipts."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from validation_receipt import pin, plan
from validation_receipt.core import SCHEMA, ROLES
from tests.fixtures import chain, policy_example, replace_receipt, replace_task


def object_schema(properties):
    return {'type': 'object', 'properties': properties, 'required': list(properties), 'additionalProperties': False}


def array(item, maximum, minimum=0):
    return {'type': 'array', 'items': item, 'minItems': minimum, 'maxItems': maximum}


def enum(*values):
    return {'enum': list(values)}


def schema():
    ref = lambda name: {'$ref': '#/$defs/' + name}
    text = {'type': 'string', 'minLength': 1, 'maxLength': 1024}
    hash_ = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
    nullable_hash = {'anyOf': [hash_, {'type': 'null'}]}
    integer = {'type': 'integer', 'minimum': 0, 'maximum': 2147483647}
    pin_ = object_schema({'id': {'type': 'string', 'pattern': '^[A-Za-z][A-Za-z0-9_.-]{0,63}$'}, 'revision': {'type': 'integer', 'minimum': 1, 'maximum': 1000000}, 'revision_sha256': hash_})
    def record(content):
        return object_schema({**pin_['properties'], 'content': content})
    closure = object_schema({
        'declaration': enum('caller_declares_complete', 'unknown'), 'files': enum('exact_selected_manifest', 'unknown'),
        'process_state': enum('pinned_environment_and_stdin', 'unknown'),
        **{k: enum('none', 'unknown') for k in ('external_state', 'randomness', 'clock')},
    })
    task = record(object_schema({
        'role': enum(*ROLES),
        'invocation': object_schema({'argv': array({'type': 'string', 'maxLength': 1024}, 32, 1), 'cwd': {'type': 'string', 'minLength': 1, 'maxLength': 512}, 'stdin_sha256': nullable_hash}),
        'inputs': array(object_schema({'path': {'type': 'string', 'minLength': 1, 'maxLength': 512}, 'bytes': integer, 'sha256': nullable_hash}), 256),
        'environment': object_schema({'runner_sha256': nullable_hash, 'environment_sha256': nullable_hash, 'description': text}),
        'closure': closure,
        'dependencies': array(ref('pin'), 32),
    }))
    binding = object_schema({'task': ref('pin'), 'receipt': ref('pin')})
    receipt = record(object_schema({
        'task': ref('pin'), 'availability': enum('supplied', 'withdrawn'),
        'result': object_schema({'outcome': enum('declared_pass', 'declared_fail', 'unknown'), 'exit_code': {'anyOf': [{'type': 'integer', 'minimum': -255, 'maximum': 255}, {'type': 'null'}]}, 'output_sha256': nullable_hash}),
        'dependency_receipts': array(ref('binding'), 32),
    }))
    return {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:foundation-math:validation-receipt-plan:1',
            'description': 'Structural shape only. The pure planner enforces integrity, exact Python types, references, DAGs, order and aggregate budgets. No external schema resources are loaded.',
            **object_schema({'schema': {'const': SCHEMA}, 'tasks': array(ref('task'), 32, 1), 'receipts': array(ref('receipt'), 64), 'selections': array(ref('binding'), 32)}),
            '$defs': {'pin': pin_, 'binding': binding, 'task': task, 'receipt': receipt}}


def assets():
    docs = {'all-pins-match': chain(), 'mandatory-fresh-policy': policy_example()}
    d = chain(); replace_task(d, 0, lambda t: t['content']['invocation']['argv'].append('--changed')); docs['input-drift-chain'] = d
    d = chain(); replace_task(d, 0, lambda t: t['content']['environment'].update(environment_sha256=None)); docs['unknown-environment-chain'] = d
    d = chain(); replace_receipt(d, 0, lambda r: r['content'].update(availability='withdrawn')); docs['withdrawn-receipt-chain'] = d
    d = chain(); d['selections'] = []; docs['no-implicit-latest'] = d
    d = chain(); replace_task(d, 0, lambda t: t['content']['closure'].update(declaration='unknown')); docs['unestablished-closure-chain'] = d
    result = {'schema/input.schema.json': schema()}
    for name, doc in docs.items():
        result['examples/' + name + '.input.json'] = doc
        result['examples/' + name + '.expected.json'] = plan(doc)
    return {name: (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode() for name, value in result.items()}


def main():
    for name, data in assets().items():
        target = ROOT/name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)


if __name__ == '__main__':
    main()
