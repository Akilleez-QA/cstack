"""Fresh lab-only author tests, semantic mutations and selected-only reproduction."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.generate_assets import assets
from tools.mutations import run_mutations
from tools.package import build, extract, require, sha, verify


def suite(root, optimized):
    command = [sys.executable, '-B', *(['-O'] if optimized else []), '-m', 'unittest', 'discover', '-s', 'tests', '-v']
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(root)}
    result = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=60, env=env)
    require(result.returncode == 0, result.stderr)
    match = re.search(r'Ran (\d+) tests', result.stderr)
    require(match is not None and '\nOK\n' in result.stderr and 'skipped=' not in result.stderr, 'suite completeness')
    return {'optimized': optimized, 'tests': int(match[1]), 'skipped': 0, 'returncode': result.returncode}


def independent(root, optimized):
    reports = []
    for script in ('verify.py', 'mutations.py'):
        command = [sys.executable, '-B', *(['-O'] if optimized else []), str(root/'review'/script), str(root)]
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(root)}
        result = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=60, env=env)
        require(result.returncode == 0, result.stderr)
        reports.append(json.loads(result.stdout))
    cases, mutations = reports
    require(cases['independent_cases'] == cases['passed'] == 181 and cases['failed'] == 0, 'independent case coverage')
    require(mutations['mutants'] == mutations['killed'] == 17, 'independent semantic mutation coverage')
    require(cases['core_sha256'] == mutations['core_sha256'] == sha((root/'validation_receipt/core.py').read_bytes()), 'independent core binding')
    return {'optimized': optimized, 'independent_cases': cases['passed'], 'semantic_mutants_killed': mutations['killed'], 'core_sha256': cases['core_sha256']}


def validate():
    initial = verify(ROOT)
    for relative, data in assets().items():
        require((ROOT/relative).read_bytes() == data, 'deterministic asset mismatch: ' + relative)
    original = [suite(ROOT, optimized) for optimized in (False, True)]
    mutations = run_mutations(ROOT)
    independent_original = [independent(ROOT, optimized) for optimized in (False, True)]
    with tempfile.TemporaryDirectory(prefix='fm-receipt-delivery-') as temp:
        work = Path(temp); first = work/'one.zip'; second = work/'two.zip'
        receipt = build(ROOT, first); build(ROOT, second)
        require(first.read_bytes() == second.read_bytes(), 'nondeterministic archive')
        selected = work/'selected'; extract(first, selected)
        selected_suites = [suite(selected, optimized) for optimized in (False, True)]
        independent_selected = [independent(selected, optimized) for optimized in (False, True)]
        rebuilt = work/'rebuilt.zip'; build(selected, rebuilt)
        require(first.read_bytes() == rebuilt.read_bytes(), 'selected-only archive mismatch')
        target = selected/'validation_receipt/core.py'; data = target.read_bytes()
        target.write_bytes(data + b'\n# deliberate selected-source drift\n')
        rejected = False
        try:
            verify(selected)
        except RuntimeError:
            rejected = True
        require(rejected, 'source drift accepted')
    require(verify(ROOT) == initial, 'sources changed during validation')
    return {'status': 'PASS', 'scope': 'Fresh tests of this standalone planning lab only; no v0.13 validation task executed or skipped.',
            'original': original, 'selected_only': selected_suites, 'source_mutations': mutations,
            'independent_original': independent_original, 'independent_selected_only': independent_selected,
            'deterministic_assets': True, 'deterministic_archive': True, 'selected_only_rebuild_identical': True,
            'source_drift_rejected': True, 'archive': receipt, 'sibling_imports_required': False,
            'v013_gate_modified': False, 'actual_runtime_checks_reused': False, 'actual_speedup_measured': False}


if __name__ == '__main__':
    print(json.dumps(validate(), sort_keys=True, indent=2))
