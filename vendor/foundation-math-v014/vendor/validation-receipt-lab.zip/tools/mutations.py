"""Semantic guard mutations on disposable copies; never modify shipped source."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MUTATIONS = [
    ('mandatory_fresh', "if c['role'] in MANDATORY_FRESH:", 'if False:', 'PlannerTests.test_all_mandatory_roles_fresh_even_with_matching_evidence'),
    ('closure_unknown', "reason('closure_not_declared_complete')", 'pass', 'PlannerTests.test_unknown_pins_or_closure_never_match_even_resealed_receipt'),
    ('environment_unknown', "reason('environment_pin_unknown')", 'pass', 'PlannerTests.test_unknown_pins_or_closure_never_match_even_resealed_receipt'),
    ('input_unknown', "reason('input_pin_unknown')", 'pass', 'PlannerTests.test_unknown_pins_or_closure_never_match_even_resealed_receipt'),
    ('task_binding', "reason('receipt_task_pin_not_current', key, rc['task'], pin(task))", 'pass', 'PlannerTests.test_task_semantic_mutations_invalidate_exact_receipt'),
    ('transitive_freshness', "reason('dependency_requires_fresh')", 'pass', 'PlannerTests.test_mandatory_dependency_blocks_otherwise_matching_historical_task'),
    ('output_pin', "reason('prior_output_pin_unknown')", 'pass', 'PlannerTests.test_prior_result_mutations'),
    ('prior_success', "reason('prior_result_not_declared_pass')", 'pass', 'PlannerTests.test_prior_result_mutations'),
    ('withdrawal', "reason('prior_receipt_withdrawn')", 'pass', 'PlannerTests.test_withdrawal_transitive'),
    ('selection_pin', "reason('selected_receipt_pin_not_current', prior['id'], selection['receipt'], pin(prior))", 'pass', 'PlannerTests.test_output_drift_requires_exact_selection_and_downstream_rebinding'),
    ('dependency_receipt_identity', "reason('dependency_receipt_not_selected_exactly', dep_id, edge['receipt'], None if dep_selection is None else dep_selection['receipt'])", 'pass', 'PlannerTests.test_output_drift_requires_exact_selection_and_downstream_rebinding'),
    ('record_integrity', "fail('integrity', path, 'record hash mismatch')", 'pass', 'RejectionTests.test_integrity'),
    ('closed_shape', "fail('shape', path, 'exact object keys required: ' + keys)", 'pass', 'RejectionTests.test_missing_unknown_fields_every_object_level'),
    ('fresh_pass_nonclaim', "'fresh_pass_claimed': False", "'fresh_pass_claimed': True", 'PlannerTests.test_complete_matching_chain'),
    ('skip_nonclaim', "'skip_authorized': False", "'skip_authorized': True", 'PlannerTests.test_complete_matching_chain'),
    ('output_budget', "if len(encode(result)) > MAX_OUTPUT_BYTES:", 'if False:', 'PlannerTests.test_report_output_limit'),
]


def run_mutations(root=ROOT):
    results = []
    original = (root/'validation_receipt/core.py').read_text()
    with tempfile.TemporaryDirectory(prefix='fm-receipt-mutations-') as temp:
        work = Path(temp)
        for dirname in ('validation_receipt', 'tests', 'examples'):
            shutil.copytree(root/dirname, work/dirname, ignore=shutil.ignore_patterns('__pycache__'))
        for label, old, new, test in MUTATIONS:
            if original.count(old) != 1:
                raise RuntimeError('mutation anchor count: ' + label)
            (work/'validation_receipt/core.py').write_text(original.replace(old, new))
            for optimized in (False, True):
                command = [sys.executable, '-B', *(['-O'] if optimized else []), '-m', 'unittest', 'tests.test_planner.' + test]
                env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(work)}
                result = subprocess.run(command, cwd=work, capture_output=True, text=True, timeout=20, env=env)
                killed = result.returncode != 0 and ('FAIL:' in result.stderr or 'ERROR:' in result.stderr) and 'Ran ' in result.stderr
                if not killed:
                    raise RuntimeError('surviving mutation ' + label + ': ' + result.stderr)
                results.append({'mutation': label, 'optimized': optimized, 'killed': killed, 'targeted_test': test})
    return results


if __name__ == '__main__':
    import json
    print(json.dumps(run_mutations(), sort_keys=True, indent=2))
