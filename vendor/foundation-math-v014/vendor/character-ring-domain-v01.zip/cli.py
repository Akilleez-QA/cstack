#!/usr/bin/env python3
"""Absolute-path launcher for an alternate current working directory."""
from character_ring.__main__ import main
if __name__=='__main__':raise SystemExit(main())
