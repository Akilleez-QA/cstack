#!/usr/bin/env python3
"""Rebuild only fixed universal catalog data. No group/geometry identification proof."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
LABELS=['1','W','A','S4','D','T6','P','Wp','V']
def add(x,y):return (x[0]+y[0],x[1]+y[1])
def mul(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def scale(c,x):return (c*x[0],c*x[1])
def sym(d,x):
    a,b=(F(0),F(0)),(F(1),F(0))
    for _ in range(d): a,b=b,add(mul(x,b),scale(-1,a))
    return b
T=[(F(2),F(0)),(F(-2),F(0)),(F(0),F(0)),(F(1),F(0)),(F(-1),F(0)),(F(1,2),F(1,2)),(F(-1,2),F(-1,2)),(F(1,2),F(-1,2)),(F(-1,2),F(1,2))]
S=[1,1,30,20,20,12,12,12,12]
C=[[sym(i,t) for t in T] for i in range(6)]
P=[(F(n),F(0)) for n in [4,4,0,1,1,-1,-1,-1,-1]]
C.append(P)
C.append([add(mul(t,p),scale(-1,c)) for t,p,c in zip(T,P,C[5])])
C.append([add(sym(6,t),scale(-1,p)) for t,p in zip(T,P)])
def enc(x):return [x[0].numerator,x[0].denominator,x[1].numerator,x[1].denominator]
def prod(i,j):
    out=[]
    for k in range(9):
        a,b=F(0),F(0)
        for s,x,y,z in zip(S,C[i],C[j],C[k]):
            u,v=scale(F(s,120),mul(mul(x,y),z));a+=u;b+=v
        if b or a.denominator!=1 or a<0:raise ValueError('invalid fixed fusion')
        out.append(int(a))
    return out
cat={'schema':'fm-sl2f5-catalog-v1','group':'SL2(F5)','group_order':120,'labels':LABELS,'dimensions':[1,2,3,4,5,6,4,2,3],'center_signs':[1,-1,1,-1,1,-1,1,-1,1], 'classes':[{'id':name,'size':size,'W_trace':enc(t)} for name,size,t in zip(['identity','center','order4','trace1','trace_minus1','trace_phi','trace_minus_phi','trace_phi_conjugate','trace_minus_phi_conjugate'],S,T)],'characters':[[enc(x) for x in row] for row in C],'fusion':[[prod(i,j) for j in range(9)] for i in range(9)],'mathematical_input':'The identification of this fixed marked character table with G is assumed from the pinned mathematical sources, not proved by hashes or orthogonality.'}
raw=(json.dumps(cat,indent=2,sort_keys=True)+'\n').encode()
(ROOT/'character_ring/catalog.json').write_bytes(raw)
print(hashlib.sha256(raw).hexdigest())
