#!/usr/bin/env python3
"""Deterministic arithmetic and adversarial replay; no instance computations."""
import copy,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
from character_ring.producer import calculate,VirtualCharacter
from character_ring.contract import LABELS,BUDGETS,DomainError,load_json,canonical
from character_ring.verifier import verify,check_catalog,VerificationError
ROOT=Path(__file__).resolve().parent
CHECKS=0;NEGATIVES=[]
def need(x,message):
    global CHECKS
    CHECKS+=1
    if not x:raise RuntimeError(message)
def reject(name,call,code=None):
    global CHECKS
    try:call()
    except (DomainError,VerificationError) as e:
        need(code is None or e.code==code,name+' wrong error: '+e.code);NEGATIVES.append(name);return
    raise RuntimeError('mutation accepted: '+name)
def leaf(label):return {'op':'irrep','label':label}
def sym(n):return {'op':'symmetric_power','degree':n}
def virt(c):return {'op':'virtual','coefficients':c}
def op(n,a,b):return {'op':n,'left':a,'right':b}
def req(e,kind='any',equals=None):return {'schema':'fm-character-request-v1','expression':e,'expectation':{'classification':kind,'equals':equals}}
def checked(r):
    c=calculate(r);v=verify(r,c)
    need(v['status']=='verified_arithmetic','verification result')
    return c

def main():
    check_catalog()
    for i,n in enumerate(LABELS):
        c=checked(req(leaf(n),'genuine',{n:1}));need(c['result']['multiplicities'][i]==1,'irreducible unit')
    symcerts=[]
    for d in range(257):
        c=checked(req(sym(d),'genuine'));symcerts.append(c)
        need(c['result']['dimension']==d+1,'symmetric dimension')
        need(c['result']['center_parity']==('odd' if d%2 else 'even'),'symmetric parity')
    for a in LABELS:
        for b in LABELS:
            c=checked(req(op('tensor',leaf(a),leaf(b)),'genuine'))
            cc=checked(req(op('tensor',leaf(b),leaf(a)),'genuine'))
            need(c['result']==cc['result'],'commutative fusion')
    for a in LABELS:
        for b in LABELS:
            for c in LABELS:
                x=checked(req(op('tensor',op('tensor',leaf(a),leaf(b)),leaf(c))))
                y=checked(req(op('tensor',leaf(a),op('tensor',leaf(b),leaf(c)))))
                need(x['result']==y['result'],'associative fusion')
    examples=[('symmetric_square',req(sym(2),'genuine',{'A':1})),('physical_tensor',req(op('tensor',leaf('P'),leaf('W')),'genuine',{'Wp':1,'T6':1})),('positive_dimension_virtual',req(virt({'1':3,'W':-1}),'proper_virtual',{'1':3,'W':-1})),('distinct_three_spaces',req(op('subtract',leaf('A'),leaf('V')),'proper_virtual',{'A':1,'V':-1})),('distinct_doublets',req(op('subtract',leaf('W'),leaf('Wp')),'proper_virtual',{'W':1,'Wp':-1})),('mixed_parity',req(op('add',leaf('1'),leaf('W')),'genuine',{'1':1,'W':1})),('zero',req(op('subtract',leaf('W'),leaf('W')),'genuine',{}))]
    for name,r in examples:
        c=checked(r)
        (ROOT/'examples'/f'{name}.request.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n')
        (ROOT/'examples'/f'{name}.certificate.json').write_text(json.dumps(c,sort_keys=True,indent=2)+'\n')
    for bad in ('V','Wp'):
        r=req(sym(2 if bad=='V' else 1),'genuine',{bad:1})
        reject('false physical marking '+bad,lambda r=r:calculate(r),'E_EXPECTATION')
    for expr in (virt({'1':3,'W':-1}),op('subtract',leaf('W'),leaf('Wp')),op('subtract',leaf('A'),leaf('V'))):
        reject('dimension not positivity '+canonical(expr),lambda expr=expr:calculate(req(expr,'genuine')),'E_EXPECTATION')
    signed=[{n:(-1 if i%2 else 2) for i,n in enumerate(LABELS)}, {'W':-3,'A':2,'P':-1},{}]
    for x in signed:
        for y in signed:
            for opname in ('add','subtract','tensor'):checked(req(op(opname,virt(x),virt(y))))
    base=req(op('tensor',leaf('W'),leaf('W')),'genuine',{'1':1,'A':1});good=checked(base)
    def mutate(name,change):
        c=copy.deepcopy(good);change(c);reject(name,lambda:verify(base,c),'E_CERTIFICATE')
    mutate('A exchanged with V',lambda c:c['result']['multiplicities'].__setitem__(2,0))
    mutate('false dimension',lambda c:c['result'].__setitem__('dimension',5))
    mutate('false scalar parity',lambda c:c['result'].__setitem__('center_parity','mixed'))
    mutate('false positivity',lambda c:c['result'].__setitem__('classification','proper_virtual'))
    mutate('bool coefficient',lambda c:c['result']['multiplicities'].__setitem__(0,True))
    mutate('float coefficient',lambda c:c['result']['multiplicities'].__setitem__(0,1.0))
    mutate('noncanonical rational',lambda c:c['class_values'][0].__setitem__(1,2))
    mutate('wrong irrational component',lambda c:c['class_values'][5].__setitem__(2,7))
    mutate('wrong class ordering',lambda c:c['class_values'].reverse())
    mutate('extra certificate claim',lambda c:c.__setitem__('lean_proof',True))
    mutate('scope escalation',lambda c:c.__setitem__('scope','actual_embedding'))
    mutate('wrong catalog pin',lambda c:c.__setitem__('catalog_sha256','0'*64))
    mutate('wrong request pin',lambda c:c.__setitem__('request_sha256','0'*64))
    mutate('drop coefficient',lambda c:c['result']['multiplicities'].pop())
    mutate('extra coefficient',lambda c:c['result']['multiplicities'].append(0))
    altered=req(op('tensor',leaf('Wp'),leaf('Wp')))
    wrong=calculate(altered)
    reject('internally valid certificate for wrong request',lambda:verify(base,wrong),'E_CERTIFICATE')
    wrong=copy.deepcopy(good);wrong['request']=altered;wrong['request_sha256']=hashlib.sha256(canonical(altered).encode()).hexdigest()
    reject('rehash substituted request',lambda:verify(base,wrong),'E_CERTIFICATE')
    for name,change in [('class weight',lambda c:c['classes'][2].__setitem__('size',31)),('A V catalog swap',lambda c:c['characters'].__setitem__(2,c['characters'][8])),('W Wp catalog swap',lambda c:c['characters'].__setitem__(1,c['characters'][7])),('fusion entry',lambda c:c['fusion'][1][1].__setitem__(2,0))]:
        c=json.loads((ROOT/'character_ring/catalog.json').read_text());change(c)
        reject('fixed catalog '+name,lambda c=c:check_catalog(json.dumps(c).encode()),'E_CATALOG')
    for alias in ('S','T','P4','D5',"W'",'W′','__import__'):
        reject('reject alias '+alias,lambda alias=alias:calculate(req(leaf(alias))),'E_SCHEMA')
    malformed=[('boolean degree',sym(True),'E_TYPE'),('float degree',sym(2.0),'E_TYPE'),('negative degree',sym(-1),'E_BUDGET'),('degree 257',sym(257),'E_BUDGET'),('boolean multiplicity',virt({'W':True}),'E_TYPE'),('zero sparse multiplicity',virt({'W':0}),'E_TYPE'),('rational coefficient',virt({'W':'1/2'}),'E_TYPE'),('oversize input',virt({'1':2**63}),'E_BUDGET'),('unknown operation',{'op':'eval','code':'pass'},'E_SCHEMA'),('extra operator key',{'op':'irrep','label':'W','point':0},'E_SCHEMA')]
    for name,expr,code in malformed:
        reject(name,lambda expr=expr:calculate(req(expr)),code)
        reject('verifier '+name,lambda expr=expr:verify(req(expr),good),code)
    checked(req(virt({'1':2**63-1})))
    big=virt({'1':2**63-1});b4=op('tensor',op('tensor',big,big),op('tensor',big,big))
    checked(req(b4))
    too=op('tensor',b4,big)
    reject('intermediate coefficient overflow producer',lambda:calculate(req(too)),'E_BUDGET')
    reject('intermediate coefficient overflow verifier',lambda:verify(req(too),good),'E_BUDGET')
    # Budget enforcement precedes cancellation, preventing huge hidden work.
    cancel=op('subtract',too,too)
    reject('overflow cancelled at root',lambda:calculate(req(cancel)),'E_BUDGET')
    chain=leaf('1')
    for _ in range(15):chain=op('add',chain,leaf('1'))
    checked(req(chain))
    reject('depth seventeen',lambda:calculate(req(op('add',chain,leaf('1')))),'E_BUDGET')
    balanced=leaf('1')
    for _ in range(6):balanced=op('add',balanced,balanced)
    checked(req(balanced))
    reject('node budget 129',lambda:calculate(req(op('add',balanced,leaf('1')))),'E_BUDGET')
    for name,raw,code in [('duplicate keys',b'{"x":1,"x":2}','E_JSON'),('float JSON',b'1.0','E_TYPE'),('NaN JSON',b'NaN','E_TYPE'),('huge integer JSON',b'1'*91,'E_BUDGET'),('invalid UTF8',b'\xff','E_JSON'),('malformed JSON',b'{','E_JSON'),('byte budget',b' '*65537,'E_BUDGET')]:
        reject(name,lambda raw=raw:load_json(raw,65536),code)
    class StringSubclass(str):pass
    class PretendSchema:
        def __eq__(self,other):return True
    def subclass_root_key(r):
        value=r.pop('schema');r[StringSubclass('schema')]=value
    for name,change in [('equivalent root key subclass',subclass_root_key),('schema subclass',lambda r:r.__setitem__('schema',StringSubclass(r['schema']))),('schema custom object',lambda r:r.__setitem__('schema',PretendSchema())),('custom root key',lambda r:r.update({StringSubclass('extra'):0})),('custom coefficient key',lambda r:r.__setitem__('expression',virt({StringSubclass('W'):1})))]:
        r=copy.deepcopy(base);change(r)
        reject('API '+name,lambda r=r:calculate(r),'E_SCHEMA')
        reject('verifier API '+name,lambda r=r:verify(r,good),'E_SCHEMA')
    c=copy.deepcopy(good);c['schema']=StringSubclass(c['schema'])
    reject('certificate string subclass',lambda:verify(base,c),'E_CERTIFICATE')
    c=copy.deepcopy(good);c['cycle']=c
    reject('certificate cyclic object',lambda:verify(base,c),'E_BUDGET')
    c=copy.deepcopy(good);c['extra']=[None]*8192
    reject('certificate value budget',lambda:verify(base,c),'E_BUDGET')
    from character_ring.verifier import certificate_wire
    for value in ('quote"slash\\',chr(0)+chr(8)+chr(127)+chr(128)+chr(65535)+chr(128512),{'x':['a',-3,None,{}]}):
        need(certificate_wire(value).decode('ascii')==canonical(value),'exact certificate byte preflight')
    reject('oversize certificate string before serialization',lambda:certificate_wire('a'*262143),'E_BUDGET')
    reject('oversize certificate key before serialization',lambda:certificate_wire({'a'*262140:None}),'E_BUDGET')
    need(all(certificate_wire(chr(i)).decode('ascii')==canonical(chr(i)) for i in list(range(256))+[55296,65535,65536,1114111]),'JSON escape accounting sample')
    reject('DEL escaped certificate exceeds byte budget',lambda:certificate_wire(chr(127)*43691),'E_BUDGET')
    reject('escaped certificate exceeds byte budget',lambda:certificate_wire(chr(0)*43691),'E_BUDGET')
    # Verifier-only module import independence, not merely function-call claims.
    env=dict(os.environ,PYTHONPATH=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
    p=subprocess.run([sys.executable,'-c',"import sys; import character_ring.verifier; print('character_ring.producer' in sys.modules); print('character_ring.contract' in sys.modules)"],cwd='/tmp',env=env,capture_output=True,text=True)
    need(p.returncode==0 and p.stdout=='False\nFalse\n','verifier import independence')
    with tempfile.TemporaryDirectory(prefix='replay-',dir=ROOT/'evidence') as td:
        t=Path(td);rp=t/'request.json';cp=t/'certificate.json';rp.write_text(json.dumps(base));cp.write_text(json.dumps(good))
        for option in ([],['-O']):
            p=subprocess.run([sys.executable,*option,'-m','character_ring','check',str(rp),str(cp)],cwd='/tmp',env=env,capture_output=True,text=True)
            need(p.returncode==0 and json.loads(p.stdout)['status']=='verified_arithmetic','CLI alternate CWD')
        for args,code in [([],2),(['calculate',str(t/'missing')],2)]:
            p=subprocess.run([sys.executable,'-m','character_ring',*args],cwd=ROOT,env=env,capture_output=True,text=True)
            need(p.returncode==code and not p.stdout,'CLI error exit')
        rp.write_text(json.dumps(req(virt({'W':-1}),'genuine')))
        p=subprocess.run([sys.executable,'-m','character_ring','calculate',str(rp)],cwd=ROOT,env=env,capture_output=True,text=True)
        need(p.returncode==3 and json.loads(p.stderr)['code']=='E_EXPECTATION','CLI expectation false')
    out={'status':'PASS','checks':CHECKS,'rejected_controls':NEGATIVES,'rejected_control_count':len(NEGATIVES),'symmetric_degrees':257,'ordered_irreducible_products':81,'associativity_triples':729,'budgets':BUDGETS,'catalog_sha256':good['catalog_sha256'],'scope':'Universal representation arithmetic only; no geometric or Lean proof or runtime acceptance.'}
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
