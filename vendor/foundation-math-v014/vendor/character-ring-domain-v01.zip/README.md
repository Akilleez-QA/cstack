# Foundation Math: fixed physical character ring lab

A standalone, local, standard-library-only domain pack for exact representation arithmetic in the fixed physical marking of SL2(F5). It is experimental and is not registered with, or accepted automatically by, any mathematical runtime.

## What is checked

- Signed virtual-character addition, subtraction and tensor product.
- Sym^d(W), for every integer 0 <= d <= 256, with W fixed, not interchangeable with Wp.
- Exact irreducible decomposition, dimension, center parity and genuine/proper-virtual classification.
- A separately supplied expected request, an optional exact expected decomposition, and a fixed catalog.
- Exact Q(sqrt(5)) class values and class-weighted inner products, with no floating-point arithmetic.

The physical labels, in certificate order, are:

`1, W, A, S4, D, T6, P, Wp, V`.

Here A=Sym^2(W), S4=Sym^3(W), D=Sym^4(W), T6=Sym^5(W). V is the other three-dimensional irreducible; Wp is the other doublet. Aliases are rejected rather than silently converted. For example:

- W tensor W = 1 + A, not 1 + V.
- P tensor W = Wp + T6.
- Sym^6(W) = P + V.
- 3·1 − W has positive dimension but is not genuine.
- A − V and W − Wp have dimension zero but are not zero characters.

## Quick start

Python 3.10+ is required. No package install, network access, credentials, repository setup or external service is needed.

```sh
python cli.py calculate examples/physical_tensor.request.json > result.json
python cli.py check examples/physical_tensor.request.json result.json
python reproduce.py
```

`python -m character_ring` accepts the same calculate/check commands. An absolute path to `cli.py` works from another current working directory. Output goes to stdout; structured errors go to stderr. The CLI never evaluates code supplied in a request and never selects an actual mathematical instance.

Public API:

```python
from character_ring import calculate, verify
certificate = calculate(request_data)
receipt = verify(expected_request_data, certificate)
```

Use the TypedDict contracts in `character_ring/types.py`. Runtime validation is mandatory and independent of annotations. See [API.md](API.md) for exact schemas, budgets and errors, [MATHEMATICS.md](MATHEMATICS.md) for trust boundaries, and [VALIDATION.md](VALIDATION.md) for replay and mutation coverage.

## Evidence and limits

The producer computes in the integer fusion ring. The separate verifier imports neither producer nor request-contract code when imported alone; it evaluates the expression as an exact class function and obtains every multiplicity from class inner products. CLI JSON ingestion is shared, and the fixed mathematical input is shared. This is algorithmic separation, not a claim of formal independence from every common assumption.

An independent human-readable review and independently authored test program are under `review/`. Their conclusion applies only to the files and hashes stated there. Machine receipts are calculation evidence, not Lean proofs, actual bundle/embedding theorems, geometric occurrence statements, cryptographic attestations of truth, or automatic runtime acceptance.

No actual HM/source coefficients, selected parameters, points, jets, matrices or instance ranks are used. No source-domain enumeration, consumed one-shot or model spike is run. Existing research and runtime releases are not modified.
