#!/usr/bin/env python3
"""Run finite local checks in both Python modes and a fresh selected-only tree."""
import hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def run():
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    outputs=[]
    for label,flags in [('normal',[]),('optimized',['-O'])]:
        p=subprocess.run([sys.executable,*flags,str(ROOT/'run_tests.py')],cwd='/tmp',env=env,capture_output=True,timeout=180)
        if p.returncode:raise RuntimeError(p.stderr.decode())
        (ROOT/'evidence'/f'tests-{label}.json').write_bytes(p.stdout);outputs.append(p.stdout)
    if outputs[0]!=outputs[1]:raise RuntimeError('normal and optimized evidence differ')
    with tempfile.TemporaryDirectory(prefix='isolated-',dir=ROOT/'evidence') as td:
        t=Path(td)
        shutil.copytree(ROOT/'character_ring',t/'character_ring',ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copy2(ROOT/'run_tests.py',t/'run_tests.py')
        (t/'examples').mkdir();(t/'evidence').mkdir()
        isolated=[]
        for flags in ([],['-O']):
            p=subprocess.run([sys.executable,*flags,str(t/'run_tests.py')],cwd='/tmp',env=env,capture_output=True,timeout=180)
            if p.returncode:raise RuntimeError(p.stderr.decode())
            if p.stdout!=outputs[0]:raise RuntimeError('isolated selected-only replay differs')
            isolated.append(hashlib.sha256(p.stdout).hexdigest())
    out={'status':'PASS','normal_optimized_identical':True,'selected_only_isolated_identical':True,'test_output_sha256':hashlib.sha256(outputs[0]).hexdigest(),'isolated_hashes':isolated,'replay_modes':4,'scope':'standalone arithmetic software; not Lean or geometry or runtime acceptance'}
    (ROOT/'evidence/replay.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out,sort_keys=True,indent=2))
if __name__=='__main__':run()
