#!/usr/bin/env python3
"""Selected-only local replay, isolated from source notes and PYTHONPATH."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
request={'schema':'fm-character-request-v1','expression':{'op':'symmetric_power','degree':6},'expectation':{'classification':'genuine','equals':{'P':1,'V':1}}}
def main():
    records=[]
    with tempfile.TemporaryDirectory(prefix='clean-copy-',dir=ROOT/'review') as td:
        tmp=Path(td)
        shutil.copytree(ROOT/'character_ring',tmp/'character_ring',ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copy2(ROOT/'cli.py',tmp/'cli.py')
        (tmp/'request.json').write_text(json.dumps(request))
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME')}
        env['PYTHONDONTWRITEBYTECODE']='1'
        def call(flags,operation):
            args=[str(tmp/'request.json')]
            if operation=='check':args.append(str(tmp/'certificate.json'))
            return subprocess.run([sys.executable,*flags,str(tmp/'cli.py'),operation,*args],cwd=ROOT/'review',env=env,text=True,capture_output=True,timeout=60)
        for flags in ([],['-O']):
            p=call(flags,'calculate')
            if p.returncode or p.stderr:raise RuntimeError(p.stderr)
            certificate=json.loads(p.stdout)
            if certificate['result']['multiplicities']!=[0,0,0,0,0,0,1,0,1]:raise RuntimeError('physical sextic')
            (tmp/'certificate.json').write_text(json.dumps(certificate))
            p=call(flags,'check')
            if p.returncode or p.stderr or json.loads(p.stdout)['status']!='verified_arithmetic':raise RuntimeError(p.stderr)
            records.append({'optimization':bool(flags),'standalone_calculate_and_check':'PASS'})
        catalog=json.loads((tmp/'character_ring/catalog.json').read_text())
        catalog['characters'][2],catalog['characters'][8]=catalog['characters'][8],catalog['characters'][2]
        (tmp/'character_ring/catalog.json').write_text(json.dumps(catalog))
        for flags in ([],['-O']):
            for operation in ['calculate','check']:
                p=call(flags,operation)
                if p.returncode!=2 or p.stdout or json.loads(p.stderr)['code']!='E_CATALOG':raise RuntimeError('catalog replacement escaped')
                records.append({'optimization':bool(flags),'operation':operation,'catalog_replacement':'E_CATALOG'})
    print(json.dumps({'status':'PASS','checks':records},indent=2,sort_keys=True))
if __name__=='__main__':main()
