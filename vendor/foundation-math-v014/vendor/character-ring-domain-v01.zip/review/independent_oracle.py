#!/usr/bin/env python3
"""Independent universal character oracle. Not a proof identifying its table with G.

Uses direct binomial polynomials, rather than a McKay or symmetric recurrence.
Does not import author code or evaluate any geometric instance.
"""
from fractions import Fraction as F
from math import comb
from functools import lru_cache
import json

LABELS = ('1', 'W', 'A', 'S4', 'D', 'T6', 'P', 'Wp', 'V')
SIZES = (1, 1, 30, 20, 20, 12, 12, 12, 12)
DIMS = (1, 2, 3, 4, 5, 6, 4, 2, 3)
CENTER = (1, -1, 1, -1, 1, -1, 1, -1, 1)

def q(a=0, b=0):
    return (F(a), F(b))

def add(x, y):
    return x[0] + y[0], x[1] + y[1]

def scale(n, x):
    return n * x[0], n * x[1]

def mul(x, y):
    return x[0] * y[0] + 5 * x[1] * y[1], x[0] * y[1] + x[1] * y[0]

def total(xs):
    result = q()
    for x in xs:
        result = add(result, x)
    return result

TRACE = (q(2), q(-2), q(0), q(1), q(-1), q(F(1,2),F(1,2)),
         q(F(-1,2),F(-1,2)), q(F(1,2),F(-1,2)), q(F(-1,2),F(1,2)))

@lru_cache(None)
def direct_sym(degree):
    if type(degree) is not int or degree < 0:
        raise ValueError('degree must be a nonnegative exact integer')
    out = []
    for trace in TRACE:
        powers = [q(1)]
        for _ in range(degree):
            powers.append(mul(powers[-1], trace))
        out.append(total(scale((-1)**k * comb(degree-k,k),powers[degree-2*k])
                         for k in range(degree//2+1)))
    return tuple(out)

CH = dict(zip(LABELS[:6], [direct_sym(n) for n in range(6)]))
CH['P'] = tuple(q(n) for n in (4,4,0,1,1,-1,-1,-1,-1))
CH['Wp'] = tuple(add(mul(w,p),scale(-1,t)) for w,p,t in zip(TRACE,CH['P'],CH['T6']))
CH['V'] = tuple(add(s,scale(-1,p)) for s,p in zip(direct_sym(6),CH['P']))

def inner(left,right):
    value = total(scale(F(size,120),mul(a,b)) for size,a,b in zip(SIZES,left,right))
    if value[1] != 0 or value[0].denominator != 1:
        raise ValueError('nonintegral inner product')
    return int(value[0])

def decompose(character):
    return tuple(inner(character, CH[label]) for label in LABELS)

def character(coefficients):
    if len(coefficients) != 9 or any(type(x) is not int for x in coefficients):
        raise ValueError('expected nine signed integers')
    return tuple(total(scale(c,CH[label][i]) for label,c in zip(LABELS,coefficients))
                 for i in range(9))

def tensor(left,right):
    return decompose(tuple(mul(a,b) for a,b in zip(character(left),character(right))))

def unit(label):
    return tuple(int(name == label) for name in LABELS)

def sparse(coefficients):
    return {label:n for label,n in zip(LABELS,coefficients) if n}

def self_check():
    checks = 0
    def check(condition,message):
        nonlocal checks
        checks += 1
        if not condition:
            raise ValueError(message)
    check(sum(SIZES) == 120, 'class sum')
    check(sum(d*d for d in DIMS) == 120, 'dimension squares')
    for i,label in enumerate(LABELS):
        check(CH[label][0] == q(DIMS[i]), 'dimension')
        check(CH[label][1] == q(DIMS[i]*CENTER[i]), 'central sign')
        for j,other in enumerate(LABELS):
            check(inner(CH[label],CH[other]) == int(i == j), 'orthonormality')
            values = tensor(unit(label),unit(other))
            check(all(v >= 0 for v in values), 'tensor genuine')
            check(sum(d*n for d,n in zip(DIMS,values)) == DIMS[i]*DIMS[j], 'tensor dimension')
    check(CH['A'] != CH['V'], 'physical A and V distinct')
    check(CH['W'] != CH['Wp'], 'physical W and Wp distinct')
    check(sparse(tensor(unit('W'),unit('Wp'))) == {'P':1}, 'W times Wp')
    check(sparse(tensor(unit('W'),unit('S4'))) == {'A':1,'D':1}, 'W times S4')
    check(sparse(tensor(unit('W'),unit('T6'))) == {'D':1,'P':1,'V':1}, 'W times T6')
    check(sparse(decompose(direct_sym(6))) == {'P':1,'V':1}, 'physical sextic')
    return checks

if __name__ == '__main__':
    print(json.dumps({'status':'PASS','checks':self_check(),
      'method':'Exact conjugacy-class inner products with direct binomial symmetric-power polynomials.',
      'scope':'Conditional on the pinned physical character-table identification; no geometric or Lean theorem.'},sort_keys=True))
