#!/usr/bin/env python3
"""Independent black-box/domain review with no edits to the implementation."""
from pathlib import Path
from collections import Counter
from copy import deepcopy
from fractions import Fraction
import hashlib, importlib, json, os, random, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
REVIEWED_SOURCE_MANIFEST='fbd2014cd2931db57964142c4af7bba09853a4fa6e191bf8a550fee9f1b2cb37'
sys.path.insert(0,str(ROOT))
from independent_oracle import LABELS,DIMS,CENTER,CH,SIZES,decompose,direct_sym,tensor,unit,sparse,self_check
from character_ring.producer import calculate,VirtualCharacter
from character_ring.verifier import verify,check_catalog,certificate_wire as encode_certificate_wire
from character_ring.contract import load_json,BUDGETS
COUNTS=Counter()
FAILURES=[]

def need(ok,msg,category='positive'):
    COUNTS[category]+=1
    if not ok: raise RuntimeError(msg)

def reject(call,code,label):
    try: call()
    except Exception as e:
        need(getattr(e,'code',None)==code,f'{label}: expected {code}, got {type(e).__name__}: {e}','negative')
    else: raise RuntimeError(f'{label}: unexpectedly accepted')

def expr(label):return {'op':'irrep','label':label}
def virt(c):return {'op':'virtual','coefficients':c}
def binary(op,left,right):return {'op':op,'left':left,'right':right}
def req(e,classification='any',equals=None):return {'schema':'fm-character-request-v1','expression':e,'expectation':{'classification':classification,'equals':equals}}
def verify_value(e,expected,label):
    request=req(e,equals=sparse(expected));cert=calculate(request)
    need(cert['result']['multiplicities']==list(expected),label+' producer','oracle')
    review=verify(request,cert)
    need(review['status']=='verified_arithmetic' and review['result']==cert['result'],label+' verifier','oracle')
    need(cert['result']['dimension']==sum(d*m for d,m in zip(DIMS,expected)),label+' dimension','oracle')
    need(cert['result']['classification']==('genuine' if min(expected)>=0 else 'proper_virtual'),label+' genuineness','oracle')
    return cert

def balanced(leaves):
    if len(leaves)==1:return leaves[0]
    k=len(leaves)//2
    return binary('add',balanced(leaves[:k]),balanced(leaves[k:]))

def power_of_two(k):
    parts=[]
    while k>62:parts.append(virt({'1':2**62}));k-=62
    parts.append(virt({'1':2**k}))
    out=parts[0]
    for part in parts[1:]:out=binary('tensor',out,part)
    return out

def cli(args,cwd,optimized=False):
    env=dict(os.environ,PYTHONPATH=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
    return subprocess.run([sys.executable,*(['-O'] if optimized else []),'-m','character_ring',*args],cwd=cwd,env=env,text=True,capture_output=True,timeout=60)

def main():
    manifest=(ROOT/'SOURCE-MANIFEST.json').read_bytes()
    need(hashlib.sha256(manifest).hexdigest()==REVIEWED_SOURCE_MANIFEST,'review source manifest binding','integrity')
    for file in json.loads(manifest)['files']:
        raw=(ROOT/file['path']).read_bytes()
        need(len(raw)==file['bytes'] and hashlib.sha256(raw).hexdigest()==file['sha256'],'manifest file '+file['path'],'integrity')
    need(self_check()==269,'oracle self-check count')
    catalog_path=ROOT/'character_ring/catalog.json';raw=catalog_path.read_bytes();catalog=json.loads(raw)
    need(hashlib.sha256(raw).hexdigest()=='84ceb37bc32d10c4908e5b5f1f2f5994082074f2c2a9f36c846347750c79fa74','literal catalog pin','catalog')
    need(tuple(catalog['labels'])==LABELS,'labels','catalog')
    need(tuple(catalog['dimensions'])==DIMS,'dimensions','catalog')
    need(tuple(catalog['center_signs'])==CENTER,'central signs','catalog')
    need(tuple(c['size'] for c in catalog['classes'])==SIZES,'class sizes','catalog')
    for i,label in enumerate(LABELS):
        need(tuple((Fraction(a,b),Fraction(c,d)) for a,b,c,d in catalog['characters'][i])==CH[label],'independent class row '+label,'catalog')
        for j,other in enumerate(LABELS):
            expected=tensor(unit(label),unit(other))
            need(catalog['fusion'][i][j]==list(expected),'fusion '+label+'*'+other,'catalog')
            verify_value(binary('tensor',expr(label),expr(other)),expected,label+'*'+other)
    for d in range(257):
        expected=decompose(direct_sym(d))
        verify_value({'op':'symmetric_power','degree':d},expected,'symmetric '+str(d))
        need(sum(a*b for a,b in zip(DIMS,expected))==d+1,'symmetric dimension '+str(d),'oracle')
        need(all(not m or CENTER[i]==(-1)**d for i,m in enumerate(expected)),'symmetric center '+str(d),'oracle')
    rng=random.Random(20261024)
    for case in range(12):
        a=tuple(rng.randrange(-7,8) for _ in LABELS);b=tuple(rng.randrange(-7,8) for _ in LABELS)
        ea,eb=virt(sparse(a)),virt(sparse(b))
        verify_value(binary('add',ea,eb),tuple(x+y for x,y in zip(a,b)),f'signed sum {case}')
        verify_value(binary('subtract',ea,eb),tuple(x-y for x,y in zip(a,b)),f'signed difference {case}')
        verify_value(binary('tensor',ea,eb),tensor(a,b),f'signed tensor {case}')
    for e,expected,label in [
        (virt({}), (0,)*9,'zero'),
        (virt({'1':3,'W':-1}), (3,-1,0,0,0,0,0,0,0),'positive dimension nongenuine'),
        (virt({'A':1,'V':-1}), (0,0,1,0,0,0,0,0,-1),'zero dimension A-V'),
        (virt({'W':1,'Wp':-1}), (0,1,0,0,0,0,0,-1,0),'zero dimension W-Wp')]:
        verify_value(e,expected,label)
    need(calculate(req(virt({})))['result']['center_parity']=='zero','zero center convention')
    need(calculate(req(virt({'1':3,'W':-1})))['result']['center_parity']=='mixed','mixed center')
    for e,c,eq in [(expr('W'),'proper_virtual',None),(virt({'1':3,'W':-1}),'genuine',None),(expr('A'),'any',{'V':1})]:
        bad=req(e,c,eq);reject(lambda bad=bad:calculate(bad),'E_EXPECTATION','false expectation')
        reject(lambda bad=bad:verify(bad,{}),'E_EXPECTATION','checker false expectation')
    good=req(expr('W'));certificate=calculate(good)
    class StrSubclass(str):pass
    class IntSubclass(int):pass
    class DictSubclass(dict):pass
    class ListSubclass(list):pass
    class EqSchema:
        def __eq__(self,other):return True
    class EqKey:
        def __hash__(self):return hash('schema')
        def __eq__(self,other):return other=='schema'
    for value in [StrSubclass('fm-character-request-v1'),EqSchema()]:
        r=deepcopy(good);r['schema']=value
        reject(lambda r=r:calculate(r),'E_SCHEMA','exact schema string producer')
        reject(lambda r=r:verify(r,certificate),'E_SCHEMA','exact schema string verifier')
    for key in [StrSubclass('schema'),EqKey()]:
        r={key:good['schema'],'expression':good['expression'],'expectation':good['expectation']}
        reject(lambda r=r:calculate(r),'E_SCHEMA','exact object key producer')
        reject(lambda r=r:verify(r,certificate),'E_SCHEMA','exact object key verifier')
    for constructor in [lambda c:DictSubclass(c),lambda c:dict(c,result=DictSubclass(c['result'])),lambda c:dict(c,class_values=ListSubclass(c['class_values'])),lambda c:dict(c,schema=StrSubclass(c['schema']))]:
        c=constructor(deepcopy(certificate));reject(lambda c=c:verify(good,c),'E_CERTIFICATE','certificate built-in containers and strings')
    c=deepcopy(certificate);c['result']['multiplicities'][1]=IntSubclass(1)
    reject(lambda:verify(good,c),'E_CERTIFICATE','certificate exact integer type')
    c={EqKey():1};reject(lambda:verify(good,c),'E_CERTIFICATE','certificate exact key type')
    c={};c['cycle']=c
    reject(lambda:verify(good,c),'E_BUDGET','cyclic certificate')
    need(encode_certificate_wire({'x':[None]*8190}), 'certificate 8192-value exact boundary','boundary')
    reject(lambda:encode_certificate_wire({'x':[None]*8191}),'E_BUDGET','certificate 8193-value overflow')
    c=None
    for _ in range(31):c=[c]
    need(encode_certificate_wire(c), 'certificate depth32 exact boundary','boundary')
    reject(lambda:encode_certificate_wire([c]),'E_BUDGET','certificate depth33 overflow')
    need(encode_certificate_wire({'x':10**90-1}), 'certificate 90-digit exact boundary','boundary')
    reject(lambda:encode_certificate_wire({'x':10**90}),'E_BUDGET','certificate 91-digit overflow')
    for point in list(range(256))+[256,1024,55295,55296,56319,56320,57343,57344,65534,65535,65536,128512,1114111]:
        value=chr(point)
        need(encode_certificate_wire({'x':value})==json.dumps({'x':value},sort_keys=True,separators=(',',':'),ensure_ascii=True).encode('ascii'),'independent Unicode byte accounting '+str(point),'encoding')
    for value in ['a'*262142, {'x':'a'*262136}, {'a'*262135:None}, chr(0)*43690+'aa', chr(128512)*21845+'aa']:
        need(len(encode_certificate_wire(value))==262144,'exact canonical certificate byte boundary','boundary')
    for value in ['a'*262143, {'x':'a'*262137}, {'a'*262136:None}, chr(0)*43690+'aaa', chr(128512)*21845+'aaa']:
        reject(lambda value=value:encode_certificate_wire(value),'E_BUDGET','canonical byte boundary overflow')
    vm=importlib.import_module('character_ring.verifier');original_serial=vm.serial
    def forbidden_serial(value):raise RuntimeError('serialization occurred before oversized input rejection')
    vm.serial=forbidden_serial
    try:
        reject(lambda:encode_certificate_wire({'x':'a'*262145}),'E_BUDGET','oversized value rejected before serialization')
        reject(lambda:encode_certificate_wire({'a'*262145:None}),'E_BUDGET','oversized key rejected before serialization')
    finally:vm.serial=original_serial
    badcases=[]
    x=deepcopy(good);x['extra']=0;badcases.append((x,'E_SCHEMA','extra request key'))
    x=deepcopy(good);del x['schema'];badcases.append((x,'E_SCHEMA','missing request key'))
    x=deepcopy(good);x['schema']='other';badcases.append((x,'E_SCHEMA','wrong schema'))
    x=deepcopy(good);x['expectation']['classification']=True;badcases.append((x,'E_SCHEMA','bool classification'))
    for e in [None,True,[],{'op':'eval','code':'1+1'},{'op':'irrep','label':'A3'},{'op':'irrep','label':'W','extra':0},{'op':'symmetric_power','degree':1,'label':'Wp'}]:badcases.append((req(e),'E_SCHEMA','malformed expression'))
    for value in [True,1.0,'1',None,[],{}]:badcases.append((req({'op':'symmetric_power','degree':value}),'E_TYPE','noninteger degree'))
    for value in [-1,257,2**100]:badcases.append((req({'op':'symmetric_power','degree':value}),'E_BUDGET','degree out of range'))
    for value in [0,True,1.0,'1',None,[],{}]:badcases.append((req(virt({'W':value})),'E_TYPE','noninteger/noncanonical coefficient'))
    for value in [2**63,-2**63]:badcases.append((req(virt({'W':value})),'E_BUDGET','input coefficient over budget'))
    badcases.append((req(virt({'A3':1})),'E_SCHEMA','unknown virtual label'))
    badcases.append((req(expr('W'),equals={'W':2**256}),'E_BUDGET','expected coefficient over budget'))
    for request,code,label in badcases:
        reject(lambda request=request:calculate(request),code,label+' producer')
        reject(lambda request=request:verify(request,certificate),code,label+' verifier')
    for n in [2**63-1,-(2**63-1)]:verify_value(virt({'1':n}),(n,)+(0,)*8,'input exact coefficient boundary')
    largest=binary('add',power_of_two(255),binary('subtract',power_of_two(255),expr('1')))
    verify_value(largest,(2**256-1,)+(0,)*8,'result exact bit boundary')
    over=req(binary('add',largest,expr('1')))
    reject(lambda:calculate(over),'E_BUDGET','producer result overflow')
    reject(lambda:verify(over,certificate),'E_BUDGET','verifier result overflow')
    verify_value(balanced([virt({}) for _ in range(64)]),(0,)*9,'127-node exact boundary')
    excessive=req(balanced([virt({}) for _ in range(65)]))
    reject(lambda:calculate(excessive),'E_BUDGET','129-node first representable overflow')
    reject(lambda:verify(excessive,certificate),'E_BUDGET','checker 129-node overflow')
    chain=virt({})
    for _ in range(15):chain=binary('add',chain,virt({}))
    verify_value(chain,(0,)*9,'16-depth exact boundary')
    excessive=req(binary('add',chain,virt({})))
    reject(lambda:calculate(excessive),'E_BUDGET','depth 17')
    reject(lambda:verify(excessive,certificate),'E_BUDGET','checker depth 17')
    for label,change in [
        ('changed request',lambda x:x['request']['expression'].update(label='Wp')),
        ('changed physical result',lambda x:x['result'].update(multiplicities=[0,0,0,0,0,0,0,1,0])),
        ('changed dimension',lambda x:x['result'].update(dimension=3)),
        ('bool multiplicity',lambda x:x['result']['multiplicities'].__setitem__(1,True)),
        ('changed catalog binding',lambda x:x.update(catalog_sha256='0'*64)),
        ('changed request hash',lambda x:x.update(request_sha256='0'*64)),
        ('changed scope',lambda x:x.update(scope='geometric_theorem')),
        ('added output',lambda x:x.update(extra=0)),
        ('noncanonical rational',lambda x:x['class_values'][0].__setitem__(slice(0,2),[4,2])),
        ('changed class value',lambda x:x['class_values'][2].__setitem__(0,1))]:
        x=deepcopy(certificate);change(x);reject(lambda x=x:verify(good,x),'E_CERTIFICATE','certificate '+label)
    other=req(expr('Wp'));other_cert=calculate(other)
    reject(lambda:verify(good,other_cert),'E_CERTIFICATE','valid certificate for another request')
    for key in ['labels','characters','fusion','mathematical_input']:
        modified=deepcopy(catalog)
        if key=='labels':modified[key][2],modified[key][8]=modified[key][8],modified[key][2]
        elif key=='characters':modified[key][2],modified[key][8]=modified[key][8],modified[key][2]
        elif key=='fusion':modified[key][0][0][0]=2
        else:modified[key]='proved by orthogonality'
        tampered=json.dumps(modified,indent=2,sort_keys=True).encode()+b'\n'
        reject(lambda tampered=tampered:check_catalog(tampered),'E_CATALOG','fixed catalog tamper '+key)
    for raw,code in [(b'{"x":1,"x":2}','E_JSON'),(b'1.0','E_TYPE'),(b'NaN','E_TYPE'),(b'Infinity','E_TYPE'),(b'\xff','E_JSON'),(b'{} garbage','E_JSON'),(b'1'*91,'E_BUDGET')]:reject(lambda raw=raw:load_json(raw,65536),code,'raw JSON negative')
    need(load_json(b'1'*90,65536)==int('1'*90),'JSON 90-digit exact boundary','boundary')
    request_wire=json.dumps(good).encode();certificate_wire=json.dumps(certificate).encode()
    need(load_json(request_wire+b' '*(65536-len(request_wire)),65536)==good,'raw request 64KiB exact boundary','boundary')
    reject(lambda:load_json(request_wire+b' '*(65537-len(request_wire)),65536),'E_BUDGET','raw request over 64KiB')
    need(load_json(certificate_wire+b' '*(262144-len(certificate_wire)),262144)==certificate,'raw certificate 256KiB exact boundary','boundary')
    reject(lambda:load_json(certificate_wire+b' '*(262145-len(certificate_wire)),262144),'E_BUDGET','raw certificate over 256KiB')
    with tempfile.TemporaryDirectory(prefix='isolated-',dir=ROOT/'review') as tmp:
        tmp=Path(tmp);(tmp/'request.json').write_bytes(request_wire);(tmp/'certificate.json').write_bytes(certificate_wire)
        for cwd in [ROOT,tmp]:
            for opt in [False,True]:
                p=cli(['calculate',str(tmp/'request.json')],cwd,opt)
                need(p.returncode==0 and json.loads(p.stdout)==certificate and not p.stderr,'CLI calculation cwd/optimization','cli')
                p=cli(['check',str(tmp/'request.json'),str(tmp/'certificate.json')],cwd,opt)
                need(p.returncode==0 and json.loads(p.stdout)['status']=='verified_arithmetic' and not p.stderr,'CLI verification cwd/optimization','cli')
                (tmp/'bad.json').write_text(json.dumps(req(expr('A'),equals={'V':1})))
                p=cli(['calculate',str(tmp/'bad.json')],cwd,opt)
                need(p.returncode==3 and not p.stdout and json.loads(p.stderr)['code']=='E_EXPECTATION','CLI expectation code','cli')
                (tmp/'bad.json').write_bytes(b'{"x":1,"x":2}')
                p=cli(['calculate',str(tmp/'bad.json')],cwd,opt)
                need(p.returncode==2 and not p.stdout and json.loads(p.stderr)['code']=='E_JSON','CLI malformed code','cli')
        p=cli([],tmp);need(p.returncode==2 and json.loads(p.stderr)['code']=='E_USAGE','CLI usage code','cli')
        p=cli(['calculate',str(tmp/'not-here.json')],tmp);need(p.returncode==2 and json.loads(p.stderr)['code']=='E_IO','CLI missing file code','cli')
    result={'status':'PASS','source_manifest_sha256':REVIEWED_SOURCE_MANIFEST,'counts':dict(COUNTS),'total_checks':sum(COUNTS.values()),'catalog_sha256':hashlib.sha256(catalog_path.read_bytes()).hexdigest(), 'oracle_method':'Exact class inner products; symmetric characters computed by direct binomial polynomials, independently of producer and verifier recurrences.', 'limits':['Identification of the marked table with G remains a pinned mathematical assumption.','Field-component cap is a conservative secondary cap; a separate exact 272-bit reachable boundary is not claimed.','Binary-expression node counts are odd, so 129 is the first structurally representable overflow above 127.']}
    print(json.dumps(result,sort_keys=True,indent=2))

if __name__=='__main__':main()
