# Independent review plan

This review concerns only universal representation arithmetic with the fixed physical labels `1,W,A,S4,D,T6,P,Wp,V`. It will not execute earlier geometric enumerations or instance calculations.

## Independent mathematical oracle

The oracle is separately authored in `independent_oracle.py`. It uses exact pairs of rational numbers in Q(sqrt(5)), the nine class sizes, and a direct binomial polynomial for symmetric characters. This avoids the author's implementation and avoids a shared symmetric-power or McKay recurrence. Basis products are reconstructed from exact class inner products. The identification of this table with the physical group and marking is an explicit pinned mathematical assumption, not proved by hashes, orthogonality, or software execution.

Physical marking follows the complete immutable [equivariant splitting source](https://github.com/Akilleez-QA/read-em-and-weep/blob/db51525015bb7c5e825833d550d08dedf6f6ea96/research/hm/order-four-quadratic-load/ACTUAL-EQUIVARIANT-SPLITTING-AND-GAUSS-PERSISTENCE.md). In particular A is Sym^2(W), V is the distinct even three-space, S4 is Sym^3(W), D is Sym^4(W), and T6 is Sym^5(W). The independent tensor identities are stated in the immutable [rank-two source](https://github.com/Akilleez-QA/read-em-and-weep/blob/db51525015bb7c5e825833d550d08dedf6f6ea96/research/hm/order-four-quadratic-load/RANK-TWO-GAUSS-PLATEAU-NECESSARY-BOUND.md).

## Planned checks

1. Authenticate every shipped complete source and fixed catalog against its literal pinned content; distinguish evidence integrity from mathematical truth.
2. Check the nine dimensions and central signs, all 81 basis inner products, all 81 tensor products, all supported Sym^d(W), and known physical identities. Check commutativity, associativity, distributivity, unit and zero behavior, signed subtraction, and exact dimension consistency.
3. Reject noninteger coefficients, bool-as-int, floats, coercible strings, wrong vector lengths, unknown labels, alternate markings, extra/missing request keys, duplicate JSON keys, non-finite JSON numbers, and non-data expression payloads. Inspect both direct API and CLI behavior.
4. Test every declared resource-budget endpoint exactly and one beyond it, including degree, coefficient size, operation count, expression depth, bytes, cumulative work and output bounds when applicable. Check preflight ordering and stable structured errors; no hidden acceptance under Python -O.
5. Bind requests and certificates to the exact fixed catalog and inputs. Attempt tampering with values, physical labels, metadata, hashes, request operations and outputs in disposable review copies. Recomputed hashes must not turn a modified catalog into the fixed catalog.
6. Reproduce from the package directory and alternate working directories, under normal Python and Python -O, with a standard-library-only environment. Compare canonical results, not incidental timestamps.
7. Inspect user-facing scope statements. No hash-based proof of group identification, Lean/kernel verification, geometric realization, actual-instance computation, theorem closure or unsupported exhaustive-domain claim.

Only review files will be changed. The author will receive exact failures and reproduction evidence before any final report.
