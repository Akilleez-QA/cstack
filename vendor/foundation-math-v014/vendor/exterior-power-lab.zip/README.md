# Foundation Math: exact exterior-power formal-domain lab

A standalone, local reusable calculator extension. This is **not a Foundation Math release**, not a new repository, and not an integration into its tool registry. The entire v0.13 tree and all sixteen existing tool contracts are retained unchanged.

The new obligation is to calculate exterior powers of supplied genuine representation classes and supplied equivariant split-bundle expressions exactly, then independently check the results. Actual injections imply necessary exterior-power H0 comparisons, but this calculator accepts **no actual map**, coefficients, parameters, selected points, matrices, or instance ranks. Passing comparisons never establishes a map or injection.

## Run locally

Python 3.10+ and its standard library are sufficient. No installation, network, models, provider calls, Lean install, or service credentials are used.

```sh
python -B -m exterior_power calculate examples/stronger-exterior-test.request.json > /tmp/exterior-certificate.json
python -B -m exterior_power check examples/stronger-exterior-test.request.json /tmp/exterior-certificate.json
python -B tools/validate.py
python -B tools/build_artifact.py --output /tmp/exterior-lab.zip
```

`validate.py` verifies the frozen source manifest and runs the complete suite and targeted source mutations under both normal and optimized Python. It writes nothing to the artifact tree. `--baseline /path/to/foundation-math-hypothesis-scope-v013` additionally checks every recorded original file and rejects added or missing files. The portable archive needs no original baseline to run its new domain tests. It does not pretend to rerun the baseline's historical tests.

## Three exact algorithms

1. Producer: fixed finite exterior polynomials of all nine irreps, integer-fusion multiplication, and exact line-degree convolution. A repeated summand contributes repeated lambda-polynomial factors.
2. Checker: independent Q(sqrt(5)) class arithmetic, exact class powers, Adams traces, graded Newton identities, and weighted-inner-product decomposition. It imports neither producer, fusion implementation, nor exterior seeds. It shares only the data-boundary contract and the explicit mathematical input catalog.
3. Test oracle: rational cyclotomic arithmetic, a separately written periodic class-power table, Fourier recovery of eigenvalue multiplicities, and the product of `(1 + t eigenvalue)` factors. It uses neither production algorithm.

The fixed catalog pin is `84ceb37bc32d10c4908e5b5f1f2f5994082074f2c2a9f36c846347750c79fa74`. Physical labels W/Wp and A/V remain distinct. Catalog-to-group identification is an assumption inherited from the pinned sources, not a consequence of hashes, orthogonality, or these tests.

## A useful new formal obstruction

Supply U = S4 tensor O(-1), and R = (W direct-sum Wp) tensor O(1). Thus R(-2) = (W direct-sum Wp) tensor O(-1). At twist 6, the first H0 representations agree. The second exterior comparison has target-minus-source `D - P - 1`, which has negative trivial and P multiplicities. The new formal test detects an obstruction missed by that first comparison.

These are freely supplied formal split objects, not claimed identifications of active research bundles. Nothing here repairs an actual geometric proof without separately proving its hypotheses.

## Finite supported domain

- Genuine input representations or split bundles of rank at most 24.
- Nine exact physical labels; no user-supplied or alternate catalog.
- At most 12 blocks, block line degrees in [-16,16], positive integral multiplicities, total rank <=24.
- Explicit distinct exterior orders in [0,25], including order zero and above-rank zero cases.
- For comparisons, 1..8 explicit distinct twists in [-16,16]. No implicit infinite twist scan.
- Exact line degrees up to absolute value 384; cohomology symmetric degree at most 400.
- Explicit byte, depth, value, integer, and intermediate-term budgets. Oversized requests or outputs fail closed, never return truncated answers.

See [the mathematical contract](docs/MATHEMATICS.md), [API and boundaries](docs/API.md), [validation scope](docs/VALIDATION.md), and [provenance](docs/PROVENANCE.md).

## What verification does not mean

A verified certificate is finite exact arithmetic conditional on fixed inputs. It is not a Lean proof, not runtime goal acceptance, not verification of a chosen map, not proof of a splitting, and not proof that a representation is realized by any research object. Full normal/-O tests, mutation detection, an independently authored review, and formal-kernel verification are separate evidence categories. The latter is not claimed here.
