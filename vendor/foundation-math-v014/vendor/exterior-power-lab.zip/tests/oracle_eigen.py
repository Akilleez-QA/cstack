"""Third algorithm: cyclotomic Fourier eigenmultiplicities and determinant product.

No exterior_power imports. Class powers are explicit periodic data, independent
of the W-trace recurrence. Arithmetic is Q[x]/Phi_n with n in {1,2,3,4,5,6,10}.
"""
from fractions import Fraction as F

PERIODS = ((0,), (0,1), (0,2,1,2), (0,3,4,1,4,3), (0,4,4),
           (0,5,8,7,6,1,6,7,8,5), (0,6,8,8,6),
           (0,7,6,5,8,1,8,5,6,7), (0,8,6,6,8))
PHI = {1:(-1,1), 2:(1,1), 3:(1,1,1), 4:(1,0,1), 5:(1,1,1,1,1),
       6:(1,-1,1), 10:(1,-1,1,-1,1)}

class Cyclo:
    def __init__(self,n): self.n=n;self.mod=PHI[n];self.degree=len(self.mod)-1
    def reduce(self,p):
        p=list(map(F,p))
        while len(p)>self.degree:
            lead=p.pop();shift=len(p)-self.degree
            for j,v in enumerate(self.mod[:-1]):p[shift+j]-=lead*v
        return tuple(p+[F(0)]*(self.degree-len(p)))
    def const(self,v):return self.reduce([v])
    def add(self,a,b):return tuple(x+y for x,y in zip(a,b))
    def scale(self,n,a):return tuple(n*x for x in a)
    def mul(self,a,b):
        p=[F(0)]*(2*self.degree-1)
        for i,x in enumerate(a):
            for j,y in enumerate(b):p[i+j]+=x*y
        return self.reduce(p)
    def root(self,k):return self.reduce([0]*(k%self.n)+[1])
    def field(self,v):
        a,b=F(v[0],v[1]),F(v[2],v[3])
        if not b:return self.const(a)
        if self.n not in (5,10):raise ValueError('Unexpected irrationality')
        step=self.n//5
        sqrt5=self.add(self.const(1),self.scale(2,self.add(self.root(step),self.root(4*step))))
        return self.add(self.const(a),self.scale(b,sqrt5))

def exterior_character(catalog,multiplicities,class_index):
    period=PERIODS[class_index]; n=len(period);r=Cyclo(n)
    traces=[]
    for j in range(n):
        value=r.const(0)
        for i,m in enumerate(multiplicities):
            value=r.add(value,r.scale(m,r.field(catalog['characters'][i][period[j]])))
        traces.append(value)
    eigen=[]
    for a in range(n):
        value=r.const(0)
        for j,p in enumerate(traces):value=r.add(value,r.mul(p,r.root(-a*j)))
        value=r.scale(F(1,n),value)
        if any(value[1:]) or value[0].denominator!=1 or value[0]<0:
            raise ValueError('Invalid Fourier eigenmultiplicity')
        eigen.append(int(value[0]))
    coefficients=[r.const(1)]
    for a,m in enumerate(eigen):
        for _ in range(m):
            nxt=coefficients+[r.const(0)]
            for k,value in enumerate(coefficients):nxt[k+1]=r.add(nxt[k+1],r.mul(value,r.root(a)))
            coefficients=nxt
    return r,coefficients,eigen
