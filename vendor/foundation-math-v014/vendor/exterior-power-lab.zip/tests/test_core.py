import copy
import itertools
import json
import math
from pathlib import Path
import unittest
from unittest import mock
from exterior_power import calculate,verify
from exterior_power.contract import DomainError,LABELS,DIMS,SIGNS,load_json,parse_request
from exterior_power import class_arithmetic as ca
from exterior_power import fusion
from tests.oracle_eigen import PERIODS,exterior_character

COUNTS={'exhaustive_representations_rank_le_6':0,'repeated_irrep_multisets_le_3':0,
        'two_block_degree_cases':0,'cyclotomic_cases':0}

def rep(m,orders=None):
    rank=sum(DIMS[i]*m.get(l,0) for i,l in enumerate(LABELS))
    return {'schema':'fm-exterior-request-v1','operation':'representation','representation':m,
            'orders':list(range(rank+2)) if orders is None else orders}

def bundle(blocks,orders):
    return {'schema':'fm-exterior-request-v1','operation':'bundle','bundle':blocks,'orders':orders}

def block(l,d,m=1):return {'irrep':l,'twist':d,'multiplicity':m}
def coeff(ch):return tuple(ch['multiplicities'].get(l,0) for l in LABELS)

def every_rep(bound,index=0):
    if index==len(LABELS):
        yield {}
        return
    for n in range(bound//DIMS[index]+1):
        for rest in every_rep(bound-n*DIMS[index],index+1):
            yield dict(rest,**{LABELS[index]:n}) if n else rest

class TestKnown(unittest.TestCase):
    def test_all_irreps(self):
        for i,l in enumerate(LABELS):
            q=rep({l:1});c=calculate(q);self.assertEqual(verify(q,c)['status'],'verified')
            p=c['result']['powers']
            self.assertEqual(p[0]['character']['multiplicities'],{'1':1})
            self.assertEqual(p[1]['character']['multiplicities'],{l:1})
            self.assertEqual(p[DIMS[i]]['character']['multiplicities'],{'1':1})
            for k,row in enumerate(p):
                ch=row['character']
                self.assertEqual(ch['dimension'],math.comb(DIMS[i],k) if k<=DIMS[i] else 0)
                if ch['dimension']:
                    self.assertEqual(ch['module_center_parity'],'odd' if SIGNS[i]<0 and k%2 else 'even')
                if k<=DIMS[i]:self.assertEqual(ch,p[DIMS[i]-k]['character'])
        self.assertNotEqual(calculate(rep({'W':1}))['result']['powers'][1]['character'],
                            calculate(rep({'Wp':1}))['result']['powers'][1]['character'])
        self.assertNotEqual(calculate(rep({'A':1}))['result']['powers'][1]['character'],
                            calculate(rep({'V':1}))['result']['powers'][1]['character'])
        self.assertEqual(calculate(rep({'P':1},[2]))['result']['powers'][0]['character']['multiplicities'],{'A':1,'V':1})
        self.assertEqual(calculate(rep({'T6':1},[3]))['result']['powers'][0]['character']['multiplicities'],{'S4':2,'T6':2})

    def test_bundle_known(self):
        q=bundle([block('W',-2),block('Wp',1),block('1',-1)],list(range(7)))
        c=calculate(q);verify(q,c)
        p=c['result']['powers'];r=5;degree=-3
        self.assertEqual(p[0]['bundle']['terms'][0]['line_degree'],0)
        self.assertEqual(p[r]['bundle']['terms'][0]['line_degree'],degree)
        for k,row in enumerate(p):
            v=row['bundle'];self.assertEqual(v['rank'],math.comb(r,k) if k<=r else 0)
            self.assertEqual(v['degree'],math.comb(r-1,k-1)*degree if 1<=k<=r else 0)
            self.assertEqual(v['determinant']['line_degree'],v['degree'])
        self.assertEqual(p[r]['bundle']['terms'][0]['character']['multiplicities'],{'1':1})
        self.assertEqual(p[1]['bundle']['bundle_center_parity'],'mixed')

    def test_empty_and_limits(self):
        for q in (rep({},[0,1,25]),rep({'1':24},[0,1,12,24,25]),rep({'W':12},[0,12,24,25]),
                  bundle([], [0,1,25]),bundle([block('1',16,24)],[0,12,24,25])):
            verify(q,calculate(q))
        c=calculate(bundle([block('1',16,24)],[24]))
        self.assertEqual(c['result']['powers'][0]['bundle']['terms'][0]['line_degree'],384)

    def test_power_cycles_and_adams(self):
        rows=ca.table();powers=ca.class_powers(rows,25)
        for c,period in enumerate(PERIODS):
            self.assertEqual(powers[c],tuple(period[k%len(period)] for k in range(26)))
        for ch in rows:
            for k in range(1,26):
                self.assertEqual(ca.adams(ch,k,powers),tuple(ch[p[k%len(p)]] for p in PERIODS))
        # Adams operations preserve sums and products and compose on the supported range.
        for k in range(1,6):
            a,b=rows[1],rows[7]
            ab=tuple(ca.mul(x,y) for x,y in zip(a,b))
            self.assertEqual(ca.adams(ab,k,powers),tuple(ca.mul(x,y) for x,y in zip(ca.adams(a,k,powers),ca.adams(b,k,powers))))
            for j in range(1,6):
                self.assertEqual(ca.adams(ca.adams(a,j,powers),k,powers),ca.adams(a,j*k,powers))

    def test_every_fusion_cell_against_classes(self):
        cat,_=fusion.load_inputs();rows=ca.table()
        for i in range(9):
            for j in range(9):
                ch=tuple(ca.mul(x,y) for x,y in zip(rows[i],rows[j]))
                self.assertEqual(ca.decompose(ch,rows),tuple(cat['fusion'][i][j]))

    def test_cyclotomic_independent_oracle(self):
        catalog,_=fusion.load_inputs()
        cases=[{l:1} for l in LABELS]+[{'W':2,'Wp':1},{'A':1,'V':1},{'T6':2},{'1':3,'P':2}]
        for m in cases:
            c=calculate(rep(m));multiplicities=[m.get(l,0) for l in LABELS]
            for j in range(9):
                ring,polynomial,eigen=exterior_character(catalog,multiplicities,j)
                self.assertEqual(sum(eigen),sum(DIMS[i]*multiplicities[i] for i in range(9)))
                for k,value in enumerate(polynomial):
                    self.assertEqual(value,ring.field(c['result']['powers'][k]['character']['class_values'][j]))
                COUNTS['cyclotomic_cases']+=1

class TestExhaustive(unittest.TestCase):
    def check_rep(self,m):
        q=rep(m);c=calculate(q);verify(q,c);p=c['result']['powers'];r=c['result']['input_dimension']
        self.assertEqual(p[0]['character']['multiplicities'],{'1':1})
        self.assertEqual(p[1]['character']['multiplicities'],m)
        for k in range(r+1):
            self.assertEqual(p[k]['character']['dimension'],math.comb(r,k))
            self.assertEqual(p[k]['character'],p[r-k]['character'])
        return c

    def test_exhaustive_rank_six(self):
        for m in every_rep(6):
            self.check_rep(m);COUNTS['exhaustive_representations_rank_le_6']+=1

    def test_repeated_sums(self):
        for n in range(1,4):
            for choices in itertools.combinations_with_replacement(LABELS,n):
                m={l:choices.count(l) for l in set(choices)}
                self.check_rep(m);COUNTS['repeated_irrep_multisets_le_3']+=1

    def test_direct_sum_identity(self):
        cat,seeds=fusion.load_inputs()
        for a,b in itertools.combinations_with_replacement(LABELS,2):
            caa=calculate(rep({a:1}));cbb=calculate(rep({b:1}))
            m={a:1};m[b]=m.get(b,0)+1;c=calculate(rep(m))
            for k,row in enumerate(c['result']['powers']):
                want=fusion.ZERO
                for i in range(k+1):
                    j=k-i
                    if i<len(caa['result']['powers']) and j<len(cbb['result']['powers']):
                        want=fusion.add(want,fusion.tensor(coeff(caa['result']['powers'][i]['character']),coeff(cbb['result']['powers'][j]['character']),cat))
                self.assertEqual(coeff(row['character']),want)

    def test_all_two_block_degrees(self):
        atoms=[block(l,d) for l in LABELS for d in (-1,0,1)]
        for a,b in itertools.combinations_with_replacement(atoms,2):
            blocks=[a,b];r=DIMS[LABELS.index(a['irrep'])]+DIMS[LABELS.index(b['irrep'])]
            q=bundle(blocks,list(range(r+2)));c=calculate(q);verify(q,c)
            degree=c['result']['input']['degree']
            dual=[dict(x,twist=-x['twist']) for x in blocks]
            dc=calculate(bundle(dual,list(range(r+1))))
            for k,row in enumerate(c['result']['powers']):
                v=row['bundle']
                self.assertEqual(v['rank'],math.comb(r,k) if k<=r else 0)
                self.assertEqual(v['degree'],math.comb(r-1,k-1)*degree if 1<=k<=r else 0)
                if k<=r:
                    # Lambda^(r-k) E = (Lambda^k E*) tensor det(E).
                    expected={t['line_degree']+degree:t['character']['multiplicities'] for t in dc['result']['powers'][k]['bundle']['terms']}
                    actual={t['line_degree']:t['character']['multiplicities'] for t in c['result']['powers'][r-k]['bundle']['terms']}
                    self.assertEqual(actual,expected)
            COUNTS['two_block_degree_cases']+=1

class TestBoundary(unittest.TestCase):
    def test_invalid_requests(self):
        cases=[]
        q=rep({'W':1},[0,1,2]);cases += [dict(q,extra=1),dict(q,schema='untrusted'),dict(q,orders=[True]),dict(q,orders=[1.0]),dict(q,orders=[1,1]),dict(q,orders=[26]),dict(q,orders=[])]
        for m in ({'X':1},{'W':-1},{'W':0},{'W':True},{'W':13},{'1':25}):cases.append(dict(q,representation=m))
        for d in (-17,17,True,0.5):cases.append(bundle([block('W',d)],[1]))
        cases.append(bundle([block('1',0)]*13,[1]));cases.append(bundle([block('W',0,13)],[1]))
        cases.append(bundle([dict(block('W',0),matrix=[])],[1]))
        for bad in cases:
            with self.subTest(bad=bad),self.assertRaises(DomainError):calculate(bad)
        cyc={};cyc['cycle']=cyc
        with self.assertRaises(DomainError):parse_request(cyc)
        with self.assertRaises(DomainError):parse_request({'x':'a'*257})
        with self.assertRaises(DomainError):parse_request({'x':10**156})

    def test_json_ingestion(self):
        for raw in (b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":1.0}',b'['*18+b']'*18,b'\xff',b'{'):
            with self.assertRaises(DomainError):load_json(raw,65536)
        with self.assertRaises(DomainError):load_json(b' '*65537,65536)

    def test_certificate_mutations(self):
        q=bundle([block('W',-2),block('Wp',1)],[0,1,2,4,5]);c=calculate(q)
        mutations=[]
        def mutant(path,value):
            x=copy.deepcopy(c);p=x
            for k in path[:-1]:p=p[k]
            p[path[-1]]=value;mutations.append(x)
        root=['result','powers',1,'bundle']
        mutant(root+['degree'],91)
        mutant(root+['rank'],99)
        mutant(root+['bundle_center_parity'],'even')
        mutant(root+['terms',0,'line_degree'],-1)
        mutant(root+['terms',0,'character','multiplicities'],{'Wp':1})
        mutant(root+['terms',0,'character','class_values',5,1],3)
        mutant(root+['terms',0,'character','class_values',5,2],-1)
        mutant(root+['determinant','module'],{'W':1})
        mutant(['catalog_sha256'],'0'*64)
        mutant(['scope'],'actual_injection_proved')
        mutant(['request','bundle',0,'irrep'],'Wp')
        for x in mutations:
            with self.assertRaises(DomainError):verify(q,x)
        changed=copy.deepcopy(q);changed['bundle'][0]['irrep']='Wp'
        with self.assertRaises(DomainError):verify(changed,c)

    def test_verifier_import_separation(self):
        import subprocess,sys
        code="from exterior_power.verifier import expected; import sys; bad=[x for x in ('exterior_power.producer','exterior_power.fusion') if x in sys.modules]; sys.exit(1 if bad else 0)"
        p=subprocess.run([sys.executable,'-B','-c',code],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)

    def test_unknown_catalog_and_seed_fail_closed(self):
        original=Path.read_bytes
        for name in ('catalog.json','seeds.json'):
            def corrupt(p):return b'{}' if p.name==name else original(p)
            with mock.patch.object(Path,'read_bytes',corrupt),self.assertRaises(DomainError):calculate(rep({'W':1}))

    def test_exterior_adds_formal_necessary_test(self):
        q={'schema':'fm-exterior-request-v1','operation':'wedge_h0_comparison',
           'source':[block('S4',-1)],'target':[block('W',-1),block('Wp',-1)],
           'orders':[1,2,3,4],'twists':[6]}
        c=calculate(q);verify(q,c);rows=c['result']['comparisons']
        self.assertEqual(rows[0]['target_minus_source'],{})
        self.assertEqual(rows[0]['multiplicity_test'],'passes')
        self.assertEqual(rows[1]['target_minus_source'],{'1':-1,'D':1,'P':-1})
        self.assertEqual(rows[1]['multiplicity_test'],'obstructed')

    def test_h0_scope_and_label_obstructions(self):
        q={'schema':'fm-exterior-request-v1','operation':'wedge_h0_comparison',
           'source':[block('W',-2)],'target':[block('Wp',-2)],'orders':[0,1,2,3],'twists':[0,2,3]}
        c=calculate(q);v=verify(q,c)
        self.assertFalse(v['map_existence_or_injectivity']);self.assertFalse(v['lean_proof'])
        by={(x['order'],x['twist']):x for x in c['result']['comparisons']}
        self.assertEqual(by[1,2]['multiplicity_test'],'obstructed')
        self.assertEqual(by[1,0]['multiplicity_test'],'passes')
        self.assertEqual(by[2,2]['multiplicity_test'],'passes')
        self.assertEqual(by[1,2]['target_minus_source'],{'W':-1,'Wp':1})

if __name__=='__main__':unittest.main()
