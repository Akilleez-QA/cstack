"""Read-only complete baseline byte preservation and sixteen-tool inventory."""
import ast
import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]

def check(path):
    root=Path(path);before=json.loads((ROOT/'evidence/baseline-before.json').read_text())['files']
    now={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
         for p in sorted(root.rglob('*')) if p.is_file()}
    if now!=before:raise ValueError('Baseline full byte/file-set inventory changed')
    tree=ast.parse((root/'foundation_math_bridge/server.py').read_text())
    names=None
    for item in tree.body:
        if isinstance(item,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TOOL_NAMES' for t in item.targets):
            names=ast.literal_eval(item.value.args[0])
    if names is None or len(names)!=16 or len(set(names))!=16:raise ValueError('Expected original sixteen tools')
    return {'status':'preserved','regular_files':len(before),'bytes':sum(v['bytes'] for v in before.values()),
            'bridge_tools':list(names),'bridge_tool_count':16,'historical_baseline_tests':'not_rerun'}
if __name__=='__main__':print(json.dumps(check(sys.argv[1]),sort_keys=True))
