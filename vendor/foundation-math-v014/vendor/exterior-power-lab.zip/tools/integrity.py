"""Bounded source inventory and deterministic local ZIP helpers."""
import hashlib
import json
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parents[1]
SOURCE_DIRS=('exterior_power','tests','tools','docs','examples')
EVIDENCE=('evidence/baseline-before.json','evidence/baseline-preservation.json','evidence/author-validation.json')

def sha(raw):return hashlib.sha256(raw).hexdigest()
def selected(root=ROOT):
    out=['README.md']+list(EVIDENCE)
    for name in SOURCE_DIRS:
        out.extend(str(p.relative_to(root)) for p in (root/name).rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    return sorted(out)

def inventory(root=ROOT):
    return {n:{'bytes':(root/n).stat().st_size,'sha256':sha((root/n).read_bytes())} for n in selected(root)}

def freeze(root=ROOT):
    manifest={'schema':'fm-exterior-source-manifest-v1','files':inventory(root)}
    (root/'SOURCE-MANIFEST.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    return manifest

def verify(root=ROOT):
    path=root/'SOURCE-MANIFEST.json'
    raw=path.read_bytes()
    if len(raw)>262144:raise ValueError('Manifest byte bound exceeded')
    manifest=json.loads(raw)
    if manifest.get('schema')!='fm-exterior-source-manifest-v1':raise ValueError('Unknown source manifest')
    if manifest['files']!=inventory(root):raise ValueError('Source inventory differs from frozen manifest')
    return manifest

def build(path,root=ROOT):
    m=verify(root);names=sorted(list(m['files'])+['SOURCE-MANIFEST.json'])
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_STORED) as archive:
        for n in names:
            z=zipfile.ZipInfo(n,(2026,10,24,0,0,0));z.create_system=3;z.external_attr=0o100644<<16
            archive.writestr(z,(root/n).read_bytes())
    raw=Path(path).read_bytes()
    return {'schema':'fm-exterior-artifact-v1','archive_name':Path(path).name,'archive_bytes':len(raw),
            'archive_sha256':sha(raw),'source_manifest_sha256':sha((root/'SOURCE-MANIFEST.json').read_bytes()),
            'selected_files':len(names),'publication':'local_only_not_release'}
