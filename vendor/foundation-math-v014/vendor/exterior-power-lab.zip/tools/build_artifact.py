"""Author freeze and deterministic build. No network or publication."""
import argparse
import json
from integrity import ROOT,build,freeze
p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--freeze',action='store_true')
a=p.parse_args()
if a.freeze:freeze()
print(json.dumps(build(a.output),sort_keys=True))
