import json
from pathlib import Path
import sys
import time
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tests import test_core
start=time.monotonic()
suite=unittest.defaultTestLoader.loadTestsFromModule(test_core)
result=unittest.TextTestRunner(verbosity=1).run(suite)
print(json.dumps({'status':'passed' if result.wasSuccessful() else 'failed','tests':result.testsRun,
                 'failures':len(result.failures),'errors':len(result.errors),
                 'optimization':sys.flags.optimize,'case_counts':test_core.COUNTS,
                 'seconds':round(time.monotonic()-start,3)},sort_keys=True))
sys.exit(0 if result.wasSuccessful() else 1)
