"""Finite targeted source mutations. Success means every mutant was detected."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parents[1]
MUTATIONS=(
 ('newton_sign','class_arithmetic.py','sign = F(1 if k % 2 else -1, n)','sign = F(1, n)','test_all_irreps'),
 ('newton_denominator','class_arithmetic.py','sign = F(1 if k % 2 else -1, n)','sign = F(1 if k % 2 else -1, n+1)','test_all_irreps'),
 ('adams_is_not_ordinary_power','class_arithmetic.py','return tuple(ch[powers[c][k]] for c in range(9))','return tuple(__import__("functools").reduce(mul, [ch[c]]*k, ONE) for c in range(9))','test_all_irreps'),
 ('class_power_center','class_arithmetic.py','powers.append(tuple(traces.index(v) for v in seq))','powers.append(tuple(1 if traces.index(v) == 0 else traces.index(v) for v in seq))','test_all_irreps'),
 ('line_degree_adams','class_arithmetic.py','degree = d+k*a','degree = d+a','test_bundle_known'),
 ('module_parity','producer.py',"parity(SIGNS[i] for i,n in enumerate(m) if n)","parity(-SIGNS[i] for i,n in enumerate(m) if n)",'test_all_irreps'),
 ('bundle_parity','producer.py','SIGNS[i]*(-1 if d%2 else 1)','SIGNS[i]','test_bundle_known'),
 ('physical_module_swap','fusion.py',"factors = seeds[b['irrep']]","factors = seeds['W' if b['irrep'] == 'Wp' else b['irrep']]",'test_all_irreps'),
 ('repeat_copy_loss','fusion.py',"for _ in range(b['multiplicity']):",'for _ in range(1):','test_empty_and_limits'),
 ('fusion_cell','fusion.py',"ans[k] += x*y*n","ans[k] += x*y*n + (1 if i==1 and j==1 and k==2 else 0)",'test_empty_and_limits'),
)

def main():
    result=[]
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
    for name,file,old,new,test in MUTATIONS:
        with tempfile.TemporaryDirectory(prefix='fm-exterior-mutant-') as tmp:
            root=Path(tmp)
            shutil.copytree(ROOT/'exterior_power',root/'exterior_power')
            shutil.copytree(ROOT/'tests',root/'tests')
            p=root/'exterior_power'/file;s=p.read_text()
            if s.count(old)!=1:raise RuntimeError('Mutation target not unique: '+name)
            p.write_text(s.replace(old,new))
            command=[sys.executable,'-B']+(['-O']*sys.flags.optimize)+['-m','unittest','tests.test_core.TestKnown.'+test,'-q']
            run=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=120)
            if run.returncode==0:raise RuntimeError('Undetected mutation: '+name)
            if 'FAILED' not in run.stderr:raise RuntimeError('Mutation did not reach test failure: '+name+' '+run.stderr[-1000:])
            result.append({'mutation':name,'status':'detected','exit_code':run.returncode})
    print(json.dumps({'status':'passed','optimization':sys.flags.optimize,'mutations':result},sort_keys=True))
if __name__=='__main__':main()
