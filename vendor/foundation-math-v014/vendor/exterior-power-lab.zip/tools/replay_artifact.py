"""Clean portable normal/-O replay and byte-identical archive rebuild."""
import argparse
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import subprocess
import sys
import tempfile
import zipfile

def main():
    p=argparse.ArgumentParser();p.add_argument('archive');a=p.parse_args()
    source=Path(a.archive).resolve();raw=source.read_bytes()
    if len(raw)>16777216:raise ValueError('Archive byte budget exceeded')
    with tempfile.TemporaryDirectory(prefix='fm-exterior-portable-') as tmp:
        root=Path(tmp)/'extracted';root.mkdir()
        with zipfile.ZipFile(source) as archive:
            infos=archive.infolist();names=[i.filename for i in infos]
            if len(infos)>256 or len(names)!=len(set(names)) or sum(i.file_size for i in infos)>16777216:
                raise ValueError('Archive member budget/uniqueness failure')
            for i in infos:
                n=PurePosixPath(i.filename)
                if n.is_absolute() or '..' in n.parts or '\\' in i.filename or i.is_dir():raise ValueError('Unsafe archive path')
                if i.file_size>4194304:raise ValueError('Archive file byte budget exceeded')
                dest=root/i.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(archive.read(i))
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0')
        run=subprocess.run([sys.executable,'-B','tools/validate.py'],cwd=root,env=env,capture_output=True,text=True,timeout=1500)
        if run.returncode:raise RuntimeError(run.stdout+'\n'+run.stderr)
        validation=json.loads(run.stdout)
        rebuilt=Path(tmp)/'rebuilt.zip'
        b=subprocess.run([sys.executable,'-B','tools/build_artifact.py','--output',str(rebuilt)],cwd=root,env=env,capture_output=True,text=True,timeout=60)
        if b.returncode:raise RuntimeError(b.stdout+'\n'+b.stderr)
        if raw!=rebuilt.read_bytes():raise ValueError('Portable archive rebuild differs')
        print(json.dumps({'status':'passed','archive_sha256':hashlib.sha256(raw).hexdigest(),
                          'archive_bytes':len(raw),'byte_identical_rebuild':True,'validation':validation},sort_keys=True))
if __name__=='__main__':main()
