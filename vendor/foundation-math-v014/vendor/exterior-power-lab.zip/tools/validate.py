"""Read-only frozen-artifact aggregate: normal and -O plus mutations."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from integrity import ROOT,verify,sha
from check_baseline import check

def run(args):
    p=subprocess.run([sys.executable,'-B']+args,cwd=ROOT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0'),
                     capture_output=True,text=True,timeout=600)
    if p.returncode:raise RuntimeError('Validation failed: '+' '.join(args)+'\n'+p.stdout+'\n'+p.stderr)
    return json.loads(p.stdout)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--baseline');parser.add_argument('--author-before-freeze',action='store_true')
    args=parser.parse_args()
    # The author-only pre-freeze option produces evidence, never a frozen-artifact verdict.
    manifest=None if args.author_before_freeze else verify()
    reports=[]
    for opt in ([],['-O']):
        stage={'tests':run(opt+['tools/run_tests.py']),'mutations':run(opt+['tools/run_mutations.py'])}
        requested=1 if opt else 0
        if any(stage[k].get('optimization')!=requested or stage[k].get('status')!='passed' for k in ('tests','mutations')):
            raise RuntimeError('Validation subprocess did not establish the requested optimization mode')
        reports.append(stage)
    baseline=check(args.baseline) if args.baseline else {'status':'not_present_not_required_for_new_domain_replay'}
    if manifest is not None:verify()
    result={'status':'passed','scope':'local_exterior_domain_validation_only','launcher_optimization':sys.flags.optimize,'source_integrity':
            'author_pre_freeze' if manifest is None else 'frozen_verified',
            'source_manifest_sha256':None if manifest is None else sha((ROOT/'SOURCE-MANIFEST.json').read_bytes()),
            'normal_and_optimized':reports,'baseline':baseline,'lean':'not_run_not_installed'}
    print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
