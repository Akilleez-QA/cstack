"""A bounded local JSON-RPC math bridge, not an MCP server."""

__version__ = "0.8.0-dev"
