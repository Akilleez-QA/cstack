# Provenance and coverage

Foundation Math is newly authored project material derived from mathematical problem-solving experience. It is not a verbatim export of conversations or a claim to capture every lesson ever learned.

## Design reference

[Foundation Engine](https://github.com/Akilleez-QA/foundation-engine) supplies the sibling pattern of reusable core, optional capabilities, project contracts and scoped verification. Its runtime code and private development archive are not incorporated.

## Mathematical case study

The [read-em-and-weep proof-repair project](https://github.com/Akilleez-QA/read-em-and-weep) supplies examples of claim decomposition, dependency management, exact finite computation, corrected arguments, intrinsic-map checks and preservation of unresolved obligations. Method documents name the particular inspected sources and distinguish published inputs from unpublished checked developments.

The original proof-repair problem remains separate. This repository does not certify its completion, inherit its current branch counts as permanent facts, or claim every imported argument has been independently formalized.

## Software evidence

Local unit tests check the software behaviors they exercise. Stub verifier tests do not run a real proof kernel. A missing Lean installation remains an explicit verification gap. A model adapter interface is not evidence that a live model-powered attack was executed.

## Scope still to expand

The initial lessons are strongest in exact algebraic/geometric proof repair and reproducible computation. Analysis, numerical methods, probabilistic proofs, optimization, combinatorics and other mathematical domains need their own contracts and adversarial examples before broad capability claims are warranted.

## v0.7 local derivative

The new polynomial-witness package is copied byte-for-byte from its reviewed
standalone synthetic lab. The v0.6 baseline manifest and all six bridge tool
contracts are pinned. Frozen base and lab source trees are unchanged. New code
adds only an explicit bounded API/CLI wrapper and two append-only bridge tools;
the domain registry, work queue, original calculators and Lean adapter are not
changed. See POLYNOMIAL-WITNESS-VALIDATION.md for current replay evidence and the
remaining shared parser/arithmetic/runtime trust boundaries.

## v0.8 portable explicit-system derivative

The accepted exact-system lab is pinned by its full source manifest. All six
system and six matrix runtime modules are unchanged. The v0.7 portable base
manifest and entire eight-tool contract snapshot are pinned separately. Only
explicit integration surfaces and discovery/package tests change. The system
lab's one nonportable test dependency is replaced by shipped hash checks;
historical generated evidence is excluded, never claimed checked. The new
aggregate regenerates all required evidence from shipped source and fixtures.
See LINEAR-SYSTEMS-VALIDATION.md for the exact preservation/reproduction scope.
